"""Las cámaras del equipo y cuál eligió el usuario para Kat Rostro.

La elegida se guarda en ~/.config/katos/katlock/camara.json para que la
pantalla de bloqueo (kat-rostro-verificar) use la misma.
"""

import glob
import json
import os

from katui import plataforma


def _leer(ruta):
    try:
        with open(ruta, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


def listar(sys_v4l="/sys/class/video4linux"):
    """[(número, nombre)] de las cámaras que hay."""
    if plataforma.ES_LINUX:
        camaras = []
        for carpeta in sorted(glob.glob(os.path.join(sys_v4l, "video*")),
                              key=lambda c: int(os.path.basename(c)[5:] or 0)):
            # Cada webcam crea varios /dev/videoN; el de imagen es el de index 0.
            if _leer(os.path.join(carpeta, "index")) not in ("", "0"):
                continue
            n = int(os.path.basename(carpeta)[5:])
            camaras.append((n, _leer(os.path.join(carpeta, "name")) or "Cámara %d" % n))
        return camaras
    return _listar_windows()


def _listar_windows():
    """Vista previa en Windows: los nombres en el orden de DirectShow (el mismo que usa OpenCV)."""
    import re
    import shutil
    import subprocess
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        try:
            r = subprocess.run([ffmpeg, "-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
                               capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=10,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            nombres = re.findall(r'"([^"]+)" \(video\)', r.stderr)
            if nombres:
                return list(enumerate(nombres))
        except (OSError, subprocess.TimeoutExpired):
            pass
    hay = []                               # sin ffmpeg: probar las primeras una por una
    for n in range(5):
        cam = abrir(n)
        if cam is not None:
            cam.release()
            hay.append((n, "Cámara %d" % (n + 1)))
    return hay or [(0, "Cámara 1")]


def archivo(carpeta=None):
    return os.path.join(carpeta or plataforma.carpeta_config("katlock"), "camara.json")


def elegida(ruta=None):
    """El número de la cámara elegida (0 si no se eligió ninguna)."""
    try:
        with open(ruta or archivo(), encoding="utf-8") as f:
            return int(json.load(f)["camara"])
    except (OSError, ValueError, KeyError, TypeError):
        return 0


def elegir(numero, nombre="", ruta=None):
    ruta = ruta or archivo()
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump({"camara": int(numero), "nombre": nombre}, f, ensure_ascii=False)


def abrir(numero=0):
    """La cámara abierta con OpenCV, o None si no se puede."""
    try:
        import cv2
    except ImportError:
        return None
    extra = [cv2.CAP_DSHOW] if os.name == "nt" else []
    cam = cv2.VideoCapture(int(numero), *extra)
    if not cam.isOpened():
        cam.release()
        return None
    cam.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cam.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    return cam
