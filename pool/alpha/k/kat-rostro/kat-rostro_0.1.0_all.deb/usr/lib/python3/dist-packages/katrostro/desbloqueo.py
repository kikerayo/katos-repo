"""La decisión de desbloquear con la cara (la usa kat-rostro-verificar desde PAM)."""

import time

from . import datos

SEGUNDOS = 3.0          # cuánto mira la cámara como mucho
SEGUIDAS = 3            # imágenes seguidas que deben coincidir


def comprobar(huellas_guardadas, leer_imagen, mot, segundos=SEGUNDOS, reloj=time.monotonic):
    """True si en 'segundos' ve SEGUIDAS imágenes seguidas con tu cara, y solo la tuya."""
    if not huellas_guardadas:
        return False
    fin, seguidas = reloj() + segundos, 0
    while reloj() < fin:
        imagen = leer_imagen()
        if imagen is None:
            return False
        estado, huella = mot.analizar(imagen)
        if estado == "ok" and datos.coincide(huella, guardadas=huellas_guardadas):
            seguidas += 1
            if seguidas >= SEGUIDAS:
                return True
        else:
            seguidas = 0
    return False
