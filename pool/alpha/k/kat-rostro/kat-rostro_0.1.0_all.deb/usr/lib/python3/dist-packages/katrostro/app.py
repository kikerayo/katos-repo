"""Punto de entrada de Kat Rostro.  Uso: kat-rostro [--version]"""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Rostro")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    from .ventana import VentanaRostro
    v = VentanaRostro()
    v.show()
    return app.exec()
