"""Motor de Kat Rostro: encontrar la cara (YuNet), sacar su huella (SFace) y comparar."""

import os

MODELO_DETECTOR = "face_detection_yunet_2023mar.onnx"
MODELO_HUELLA = "face_recognition_sface_2021dec.onnx"
SHA256 = {
    MODELO_DETECTOR: "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4",
    MODELO_HUELLA: "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79",
}
# SFace recomienda 0.363 (similitud coseno) para decir "es la misma persona".
# Para DESBLOQUEAR Kat usa un umbral más exigente: menos falsos aciertos.
UMBRAL = 0.50
TAM_MIN = 0.16          # la cara debe ocupar al menos el 16 % del ancho de la imagen (estar cerca)


class SinModelos(RuntimeError):
    pass


def carpetas_modelos():
    rutas = [os.environ.get("KAT_MODELOS", ""), "/usr/share/katos/modelos",
             os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "modelos"),
             r"D:\KatOS\apps-windows\modelos"]
    return [r for r in rutas if r]


def buscar_modelo(nombre):
    for c in carpetas_modelos():
        ruta = os.path.join(c, nombre)
        if os.path.isfile(ruta):
            return ruta
    return None


class Motor:
    def __init__(self):
        import cv2
        self.cv2 = cv2
        det, rec = buscar_modelo(MODELO_DETECTOR), buscar_modelo(MODELO_HUELLA)
        if not det or not rec:
            raise SinModelos("Faltan los modelos de cara (%s, %s)" % (MODELO_DETECTOR, MODELO_HUELLA))
        self.detector = cv2.FaceDetectorYN.create(det, "", (320, 320), 0.85, 0.3, 5)
        self.reconocedor = cv2.FaceRecognizerSF.create(rec, "")

    def caras(self, imagen):
        """Caras encontradas en una imagen BGR: lista de filas [x, y, w, h, 10 puntos, confianza]."""
        alto, ancho = imagen.shape[:2]
        self.detector.setInputSize((ancho, alto))
        _, caras = self.detector.detect(imagen)
        return [] if caras is None else list(caras)

    def huella(self, imagen, cara):
        """Vector de 128 números que describe la cara (normalizado)."""
        import numpy as np
        recorte = self.reconocedor.alignCrop(imagen, cara)
        h = self.reconocedor.feature(recorte).flatten().astype("float32")
        return h / (np.linalg.norm(h) or 1.0)

    def analizar(self, imagen):
        """(estado, huella|None): 'ninguna', 'varias', 'lejos' u 'ok'."""
        caras = self.caras(imagen)
        if not caras:
            return "ninguna", None
        if len(caras) > 1:
            return "varias", None
        cara = caras[0]
        if cara[2] < imagen.shape[1] * TAM_MIN:
            return "lejos", None
        return "ok", self.huella(imagen, cara)


def similitud(a, b):
    import numpy as np
    a, b = np.asarray(a, dtype="float32"), np.asarray(b, dtype="float32")
    return float(np.dot(a, b) / ((np.linalg.norm(a) * np.linalg.norm(b)) or 1.0))


MENSAJES = {"ninguna": "No veo ninguna cara: ponte frente a la cámara",
            "varias": "Veo más de una cara: que solo estés tú",
            "lejos": "Acércate un poco a la cámara",
            "ok": "Te veo bien"}
