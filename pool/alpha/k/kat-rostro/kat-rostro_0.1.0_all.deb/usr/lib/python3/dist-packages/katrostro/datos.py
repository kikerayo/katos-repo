"""Tu cara registrada: solo las huellas numéricas (nunca fotos), solo para tu usuario.

Archivo: ~/.config/katos/katlock/rostro.json (permisos 0600).
"""

import json
import os

from katui import plataforma

from .motor import UMBRAL, similitud

MUESTRAS = 5


def archivo(carpeta=None):
    return os.path.join(carpeta or plataforma.carpeta_config("katlock"), "rostro.json")


def guardar(huellas, ruta=None):
    ruta = ruta or archivo()
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    temporal = ruta + ".tmp"
    with open(temporal, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "huellas": [[round(float(x), 6) for x in h] for h in huellas]}, f)
    try:
        os.chmod(temporal, 0o600)
    except OSError:
        pass
    os.replace(temporal, ruta)


def leer(ruta=None):
    try:
        with open(ruta or archivo(), encoding="utf-8") as f:
            return json.load(f).get("huellas") or []
    except (OSError, ValueError):
        return []


def registrado(ruta=None):
    return bool(leer(ruta))


def quitar(ruta=None):
    try:
        os.remove(ruta or archivo())
    except FileNotFoundError:
        pass


def parecido(huella, ruta=None, guardadas=None):
    """La mayor similitud con tus huellas guardadas (0 si no hay)."""
    guardadas = leer(ruta) if guardadas is None else guardadas
    return max((similitud(huella, g) for g in guardadas), default=0.0)


def coincide(huella, ruta=None, guardadas=None):
    return parecido(huella, ruta, guardadas) >= UMBRAL
