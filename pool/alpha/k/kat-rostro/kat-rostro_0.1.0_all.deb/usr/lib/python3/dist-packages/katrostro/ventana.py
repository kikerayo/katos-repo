"""Ventana de Kat Rostro: ver la cámara, registrar tu cara y probar si te reconoce."""

import time

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QComboBox, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton,
                               QVBoxLayout, QWidget)

from katui.estilo import COLORES, rol

from . import VERSION, camaras, datos, motor

AVISO = ("Con una cámara normal (sin sensor 3D), una foto nítida de tu cara podría engañar a Kat Rostro. "
         "Es una comodidad opcional: tu PIN y tu contraseña siguen funcionando siempre.")
ANCHO, ALTO = 560, 420
PAUSA_MUESTRA = 0.35        # segundos entre muestras al registrar (para que muevas un poco la cara)


class VentanaRostro(QWidget):
    def __init__(self, abrir=camaras.abrir, listar=camaras.listar):
        super().__init__()
        self.setWindowTitle("Kat Rostro")
        self.resize(640, 720)
        self.motor, self.camara, self._abrir = None, None, abrir
        self.modo, self.muestras, self._ultima = "ver", [], 0.0
        self._fin_prueba = 0.0

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 22)
        lay.setSpacing(10)
        lay.addWidget(rol(QLabel("Kat Rostro"), "titulo"))
        sub = rol(QLabel("Desbloquea la pantalla mirando a la cámara. Solo se guarda una huella numérica "
                         "de tu cara, nunca fotos, y nunca sale de este equipo."), "subtitulo")
        sub.setWordWrap(True)
        lay.addWidget(sub)
        aviso = rol(QLabel("⚠  " + AVISO), "aviso")
        aviso.setWordWrap(True)
        lay.addWidget(aviso)

        fila_cam = QHBoxLayout()
        fila_cam.addWidget(QLabel("Cámara:"))
        self.selector = QComboBox()
        for numero, nombre in listar():
            self.selector.addItem(nombre, numero)
        i = self.selector.findData(camaras.elegida())
        self.selector.setCurrentIndex(max(i, 0))
        self.selector.currentIndexChanged.connect(self._cambiar_camara)
        fila_cam.addWidget(self.selector, 1)
        lay.addLayout(fila_cam)

        self.vista = QLabel("Encendiendo la cámara…")
        self.vista.setFixedSize(ANCHO, ALTO)
        self.vista.setAlignment(Qt.AlignCenter)
        self.vista.setStyleSheet("background:#000; border-radius:14px; color:%s;" % COLORES["texto_suave"])
        lay.addWidget(self.vista, 0, Qt.AlignHCenter)

        self.estado = QLabel("")
        self.estado.setAlignment(Qt.AlignCenter)
        self.estado.setWordWrap(True)
        lay.addWidget(self.estado)
        self.barra = QProgressBar()
        self.barra.setRange(0, datos.MUESTRAS)
        self.barra.setTextVisible(False)
        self.barra.hide()
        lay.addWidget(self.barra)

        botones = QHBoxLayout()
        self.b_registrar = rol(QPushButton("Registrar mi cara"), "principal")
        self.b_probar = QPushButton("Probar")
        self.b_borrar = QPushButton("Borrar mi cara")
        self.b_registrar.clicked.connect(self.registrar)
        self.b_probar.clicked.connect(self.probar)
        self.b_borrar.clicked.connect(self.borrar)
        for b in (self.b_registrar, self.b_probar, self.b_borrar):
            botones.addWidget(b)
        lay.addLayout(botones)
        pie = rol(QLabel("Kat Rostro %s · OpenCV YuNet + SFace (Apache-2.0)" % VERSION), "subtitulo")
        pie.setAlignment(Qt.AlignCenter)
        lay.addWidget(pie)

        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self._cuadro)
        self._actualizar_botones()
        QTimer.singleShot(50, self.encender)

    # --- cámara ----------------------------------------------------------------
    def encender(self):
        try:
            self.motor = motor.Motor()
        except (ImportError, motor.SinModelos) as e:
            self._sin("Kat Rostro no está disponible aquí: %s" % e)
            return
        self._encender_camara()

    def _numero(self):
        n = self.selector.currentData()
        return 0 if n is None else n

    def _encender_camara(self):
        self.reloj.stop()
        if self.camara is not None:
            self.camara.release()
            self.camara = None
        self.camara = self._abrir(self._numero())
        if self.camara is None:
            self._sin("No pude abrir esta cámara. Elige otra arriba o conecta una webcam.")
            return
        self.vista.setText("")
        self.reloj.start(66)                     # unas 15 imágenes por segundo
        self._actualizar_botones()

    def _cambiar_camara(self):
        camaras.elegir(self._numero(), self.selector.currentText())   # la pantalla de bloqueo usará esta
        self.modo = "ver"
        self.barra.hide()
        if self.motor is not None:
            self.vista.setText("Cambiando de cámara…")
            self._encender_camara()

    def _sin(self, texto):
        self.vista.setText(texto)
        self.vista.setWordWrap(True)
        self.estado.setText("")
        self._actualizar_botones()

    def _actualizar_botones(self):
        listo = self.camara is not None and self.modo == "ver"
        self.selector.setEnabled(self.modo == "ver")
        hay = datos.registrado()
        self.b_registrar.setEnabled(listo)
        self.b_registrar.setText("Volver a registrar" if hay else "Registrar mi cara")
        self.b_probar.setEnabled(listo and hay)
        self.b_borrar.setEnabled(hay and self.modo == "ver")

    def _cuadro(self):
        ok, imagen = self.camara.read()
        if not ok or imagen is None:
            self.estado.setText("La cámara no está enviando imagen.")
            return
        imagen = imagen[:, ::-1].copy()          # como un espejo
        caras = self.motor.caras(imagen)
        estado, huella = self.motor.analizar(imagen) if len(caras) == 1 else (
            "ninguna" if not caras else "varias", None)
        self._dibujar(imagen, caras, estado)
        ahora = time.monotonic()
        if self.modo == "registrar":
            self._paso_registro(estado, huella, ahora)
        elif self.modo == "probar":
            self._paso_prueba(estado, huella, ahora)
        else:
            self.estado.setText(motor.MENSAJES[estado])

    def _dibujar(self, imagen, caras, estado):
        import cv2
        rgb = cv2.cvtColor(imagen, cv2.COLOR_BGR2RGB)
        alto, ancho = rgb.shape[:2]
        qimg = QImage(rgb.data, ancho, alto, 3 * ancho, QImage.Format_RGB888).copy()
        pix = QPixmap.fromImage(qimg).scaled(ANCHO, ALTO, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        escala = pix.width() / ancho
        p = QPainter(pix)
        p.setRenderHint(QPainter.Antialiasing)
        color = QColor(COLORES["ok"] if estado == "ok" else COLORES["aviso"])
        p.setPen(QPen(color, 3))
        for c in caras:
            x, y, w, h = (float(v) * escala for v in c[:4])
            p.drawRoundedRect(int(x), int(y), int(w), int(h), 14, 14)
        p.end()
        self.vista.setPixmap(pix)

    # --- registrar ---------------------------------------------------------------
    def registrar(self):
        self.modo, self.muestras, self._ultima = "registrar", [], 0.0
        self.barra.setValue(0)
        self.barra.show()
        self._actualizar_botones()

    def _paso_registro(self, estado, huella, ahora):
        if estado != "ok":
            self.estado.setText(motor.MENSAJES[estado])
            return
        if ahora - self._ultima >= PAUSA_MUESTRA:
            self.muestras.append(huella)
            self._ultima = ahora
            self.barra.setValue(len(self.muestras))
        self.estado.setText("Registrando… mueve la cabeza un poquito (%d de %d)"
                            % (len(self.muestras), datos.MUESTRAS))
        if len(self.muestras) >= datos.MUESTRAS:
            datos.guardar(self.muestras)
            self.modo = "ver"
            self.barra.hide()
            self.estado.setText("✔  Listo: tu cara quedó registrada. Pulsa «Probar» para comprobarlo.")
            self._actualizar_botones()

    # --- probar --------------------------------------------------------------------
    def probar(self):
        self.modo, self._fin_prueba = "probar", time.monotonic() + 5
        self._guardadas = datos.leer()
        self._actualizar_botones()

    def _paso_prueba(self, estado, huella, ahora):
        if estado == "ok":
            valor = datos.parecido(huella, guardadas=self._guardadas)
            if valor >= motor.UMBRAL:
                self.modo = "ver"
                self.estado.setText("✔  Te reconocí (parecido %d %%). Así se desbloqueará la pantalla."
                                    % round(valor * 100))
                self._actualizar_botones()
                return
            self.estado.setText("Comparando… (parecido %d %%)" % round(valor * 100))
        else:
            self.estado.setText(motor.MENSAJES[estado])
        if ahora > self._fin_prueba:
            self.modo = "ver"
            self.estado.setText("✖  No te reconocí. Prueba con más luz o vuelve a registrar tu cara.")
            self._actualizar_botones()

    # --- borrar --------------------------------------------------------------------
    def borrar(self):
        if QMessageBox.question(self, "Borrar mi cara",
                                "¿Borrar tu cara de Kat Rostro? Ya no podrás desbloquear con la cámara "
                                "(tu PIN y tu contraseña siguen igual).") != QMessageBox.Yes:
            return
        datos.quitar()
        self.estado.setText("Tu cara se borró de este equipo.")
        self._actualizar_botones()

    def closeEvent(self, evento):
        self.reloj.stop()
        if self.camara is not None:
            self.camara.release()
            self.camara = None
        super().closeEvent(evento)
