"""Kat Rostro: desbloquear la pantalla con tu cara (parte de KatLock). OPCIONAL.

Usa OpenCV con dos modelos oficiales (opencv_zoo, licencia Apache-2.0):
  YuNet  -> encuentra caras en la imagen
  SFace  -> saca una "huella" numérica de la cara para compararla
AVISO honesto: con una webcam normal (sin sensor infrarrojo 3D) una foto
nítida de tu cara podría engañarlo. Por eso es una comodidad opcional:
tu PIN y tu contraseña siguen funcionando siempre.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Rostro"
