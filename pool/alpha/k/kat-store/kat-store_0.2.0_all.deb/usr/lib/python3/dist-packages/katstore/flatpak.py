"""Apps instaladas con Flatpak: listar, instalar, quitar, actualizar, permisos y fuentes.

Instalar y quitar es para todo el sistema (--system), igual que hace Kat
Bienvenida; polkit permite hacerlo a los administradores sin contraseña.
"""

import re
import subprocess

from katui import acciones, plataforma

REMOTO = "flathub"
_ID = re.compile(r"^[A-Za-z0-9_.-]+$")


def disponible():
    return plataforma.tiene("flatpak")


def _correr(*args, tiempo=60):
    return subprocess.run(["flatpak"] + list(args), capture_output=True, text=True, timeout=tiempo,
                          encoding="utf-8", errors="replace")


def interpretar_tabla(texto, columnas):
    """Salida de 'flatpak ... --columns=a,b,c' (separada por tabuladores) -> lista de dicts."""
    filas = []
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        partes = linea.split("\t")
        partes += [""] * (len(columnas) - len(partes))
        filas.append(dict(zip(columnas, (p.strip() for p in partes))))
    return filas


def instaladas():
    """[{'id','nombre','version','tamano','origen'}] o None si aquí no hay Flatpak."""
    if not disponible():
        return None
    cols = ["id", "nombre", "version", "tamano", "origen"]
    r = _correr("list", "--app", "--columns=application,name,version,size,origin")
    return interpretar_tabla(r.stdout, cols) if r.returncode == 0 else []


def ids_instalados():
    lista = instaladas()
    return {a["id"] for a in lista} if lista else set()


def actualizaciones():
    """[{'id','version'}] de apps con versión nueva, o None si no hay Flatpak."""
    if not disponible():
        return None
    r = _correr("remote-ls", "--updates", "--app", "--columns=application,version", tiempo=120)
    return interpretar_tabla(r.stdout, ["id", "version"]) if r.returncode == 0 else []


def _validar(app_id):
    if not app_id or not _ID.match(app_id):
        return acciones.fallo("Nombre de app inválido")
    if not disponible():
        return acciones.no_disponible("Las apps se instalan en Kat OS")
    return None


_PASO = re.compile(r"(?<![\w./])(\d+)\s*/\s*(\d+)(?![\w./])")      # «2/3», no «x86_64/24.08»
_PORCIENTO = re.compile(r"(\d{1,3})\s*%")
_VELOCIDAD = re.compile(r"(\d+(?:[.,]\d+)?\s*[kKMG]i?B/s)")


def leer_progreso(linea):
    """Una línea de progreso de flatpak («Instalando 2/3… ████ 45%  1,2 MB/s  00:12»)
    -> (fracción total 0..1 o None, velocidad o ''). None si la línea no dice cuánto va."""
    pct = _PORCIENTO.findall(linea)
    if not pct:
        return None, ""
    p = min(100, int(pct[-1])) / 100
    paso = _PASO.search(linea)
    if paso:
        n, total = int(paso.group(1)), int(paso.group(2))
        if 0 < n <= total:
            p = (n - 1 + p) / total
    vel = _VELOCIDAD.search(linea)
    return p, (vel.group(1) if vel else "")


_COLOR = re.compile(rb"\x1b\[[0-9;]*[mK]|\x1b[()][0-9A-Za-z]|\x1b[=>]")   # colores y borrar: se quitan
_ESCAPE = re.compile(rb"\x1b\[[0-9;?]*[ -/]*[@-~]|\x1b[78]")               # mover el cursor: otra línea


class _Lector:
    """Junta los trozos de salida en líneas (flatpak redibuja con \\r y códigos de terminal)."""

    def __init__(self, progreso):
        self.progreso, self.actual, self.lineas = progreso, b"", []

    def comer(self, trozo):
        datos = self.actual + trozo
        if b"\x1b" in datos[-12:]:                            # código de terminal a medias: esperar al resto
            corte = datos.rfind(b"\x1b")
            datos, self.actual = datos[:corte], datos[corte:]
        else:
            self.actual = b""
        datos = _ESCAPE.sub(b"\n", _COLOR.sub(b"", datos))
        partes = re.split(rb"[\r\n]", datos)
        if self.actual:                                       # lo guardado va antes del resto que llegue
            partes[-1] += self.actual
        self.actual = partes.pop()
        for p in partes:
            self._linea(p)

    def fin(self):
        for p in re.split(rb"[\r\n]", _ESCAPE.sub(b"\n", _COLOR.sub(b"", self.actual))):
            self._linea(p)
        self.actual = b""

    def _linea(self, crudo):
        texto = crudo.decode("utf-8", "replace").strip()
        if not texto:
            return
        self.lineas.append(texto)
        del self.lineas[:-30]
        fraccion, vel = leer_progreso(texto)
        self.progreso(fraccion, vel)

    def error(self):
        """La última línea que parece un error (no la barra de progreso)."""
        for l in reversed(self.lineas):
            if leer_progreso(l)[0] is None:
                return l
        return ""


def _correr_con_progreso(cmd, progreso, tiempo):
    """Ejecuta flatpak leyendo su salida mientras avanza y llama a progreso(fraccion o None, velocidad).
    En Linux lo corre en una terminal falsa (pty): así flatpak pinta su barra con el porcentaje.
    Sin pantalla para preguntar nada (stdin vacío): si flatpak preguntara algo, falla en vez de colgarse."""
    import os
    import time
    lector = _Lector(progreso)
    maestro = None
    try:
        if plataforma.ES_LINUX:
            import fcntl
            import pty
            import struct
            import termios
            maestro, esclavo = pty.openpty()
            fcntl.ioctl(esclavo, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 160, 0, 0))   # 160 columnas
            p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=esclavo, stderr=esclavo,
                                 env=dict(os.environ, TERM="xterm"))
            os.close(esclavo)
        else:
            p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except FileNotFoundError:
        if maestro is not None:
            os.close(maestro)
        return acciones.no_disponible("Falta el programa '%s'" % cmd[0])
    limite = time.monotonic() + tiempo
    try:
        while True:
            try:
                trozo = os.read(maestro, 4096) if maestro is not None else p.stdout.read1(4096)
            except OSError:              # pty: el programa terminó (EIO)
                trozo = b""
            if not trozo:
                break
            lector.comer(trozo)
            if time.monotonic() > limite:
                p.kill()
                return acciones.fallo("'%s' tardó demasiado" % cmd[0])
    finally:
        if maestro is not None:
            os.close(maestro)
    lector.fin()
    if p.wait() == 0:
        return acciones.hecho("")
    return acciones.fallo(lector.error() or "'%s' terminó con código %d" % (cmd[0], p.returncode))


def instalar(app_id, progreso=None):
    error = _validar(app_id)
    if error:
        return error
    if progreso:      # sin --noninteractive: con él flatpak no muestra el porcentaje; -y responde que sí
        r = _correr_con_progreso(["flatpak", "install", "--system", "-y", REMOTO, app_id], progreso, 3600)
    else:
        r = acciones.ejecutar(["flatpak", "install", "--system", "--noninteractive", "-y", REMOTO, app_id], tiempo=3600)
    return acciones.hecho("instalada") if r.ok else r


def desinstalar(app_id):
    error = _validar(app_id)
    if error:
        return error
    r = acciones.ejecutar(["flatpak", "uninstall", "--system", "--noninteractive", "-y", app_id], tiempo=600)
    return acciones.hecho("desinstalada") if r.ok else r


def actualizar_todo(progreso=None):
    if not disponible():
        return acciones.no_disponible("Las apps se actualizan en Kat OS")
    if progreso:
        r = _correr_con_progreso(["flatpak", "update", "--system", "-y"], progreso, 3600)
    else:
        r = acciones.ejecutar(["flatpak", "update", "--system", "--noninteractive", "-y"], tiempo=3600)
    return acciones.hecho("apps actualizadas") if r.ok else r


def interpretar_permisos(texto):
    """'flatpak info --show-permissions' -> lista de frases entendibles."""
    explicaciones = {
        "network": "Usar internet",
        "x11": "Mostrar ventanas (X11)",
        "wayland": "Mostrar ventanas (Wayland)",
        "pulseaudio": "Reproducir y grabar sonido",
        "ipc": "Comunicarse con otros programas",
        "dri": "Usar la tarjeta gráfica",
        "all": "Acceso a TODOS los dispositivos (cámara, mandos, USB...)",
        "kvm": "Usar virtualización",
        "bluetooth": "Usar Bluetooth",
        "home": "Leer y escribir en tu carpeta personal",
        "host": "Leer y escribir en TODO el equipo",
        "host-os": "Ver los archivos del sistema",
        "xdg-download": "Tu carpeta Descargas",
        "xdg-documents": "Tu carpeta Documentos",
        "xdg-pictures": "Tu carpeta Imágenes",
        "xdg-music": "Tu carpeta Música",
        "xdg-videos": "Tu carpeta Videos",
        "xdg-desktop": "Tu Escritorio",
    }
    frases, seccion = [], ""
    for linea in texto.splitlines():
        linea = linea.strip()
        if linea.startswith("[") and linea.endswith("]"):
            seccion = linea[1:-1]
            continue
        if "=" not in linea or seccion != "Context":
            continue
        clave, valores = linea.split("=", 1)
        for v in filter(None, (x.strip() for x in valores.split(";"))):
            if v.startswith("!"):
                continue
            base = v.split(":")[0]
            texto_v = explicaciones.get(base)
            if texto_v is None and clave == "filesystems":
                texto_v = "Carpeta %s" % base
            if texto_v and texto_v not in frases:
                frases.append(texto_v + (" (solo lectura)" if v.endswith(":ro") else ""))
    return frases


def permisos(app_id):
    if _validar(app_id):
        return None
    r = _correr("info", "--system", "--show-permissions", app_id)
    return interpretar_permisos(r.stdout) if r.returncode == 0 else None


def fuentes():
    """[{'nombre','url'}] de los orígenes de apps configurados, o None."""
    if not disponible():
        return None
    r = _correr("remotes", "--columns=name,url")
    return interpretar_tabla(r.stdout, ["nombre", "url"]) if r.returncode == 0 else []


def abrir(app_id):
    error = _validar(app_id)
    if error:
        return error
    try:
        subprocess.Popen(["flatpak", "run", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError as e:
        return acciones.fallo("No se pudo abrir: %s" % e)
    return acciones.hecho("abriendo")
