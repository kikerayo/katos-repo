"""Ventana de Kat Store.

Regla: nada inventado. Todo lo que se ve sale del catálogo real de Flathub, de
las publicaciones reales de Kat Studios en GitHub (KatLauncher) o de lo que hay
instalado en este equipo. Si no hay internet, se dice.
"""

from PySide6.QtCore import QObject, QRunnable, QSize, Qt, QThread, QThreadPool, Signal
from PySide6.QtGui import QIcon, QImage, QPixmap
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QLineEdit, QListView, QListWidget, QListWidgetItem, QProgressBar, QPushButton,
    QScrollArea, QStackedWidget, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import plataforma, recursos
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import VERSION, flathub, flatpak, katstudios

TAM_ICONO = 64


def _icono_kat(nombre, tema="application-x-executable"):
    ruta = recursos.icono(nombre)
    return QIcon(ruta) if ruta else QIcon.fromTheme(tema)


# --- imágenes de internet en segundo plano --------------------------------------
class _Emisor(QObject):
    lista = Signal(str, QImage)


class _Bajar(QRunnable):
    def __init__(self, url, emisor):
        super().__init__()
        self.url, self.emisor = url, emisor

    def run(self):
        datos = flathub.imagen(self.url)
        img = QImage()
        if datos:
            img.loadFromData(datos)
        self.emisor.lista.emit(self.url, img)


class Imagenes(QObject):
    """Pide imágenes por URL y avisa a quien las pidió cuando llegan."""

    def __init__(self):
        super().__init__()
        self.pool = QThreadPool()
        self.pool.setMaxThreadCount(4)
        self.emisor = _Emisor()
        self.emisor.lista.connect(self._lista)
        self.esperando = {}
        self.cache = {}

    def pedir(self, url, cuando_llegue):
        if not url:
            return
        if url in self.cache:
            cuando_llegue(self.cache[url])
            return
        primeros = url not in self.esperando
        self.esperando.setdefault(url, []).append(cuando_llegue)
        if primeros:
            self.pool.start(_Bajar(url, self.emisor))

    def _lista(self, url, img):
        if img.isNull():
            self.esperando.pop(url, None)
            return
        self.cache[url] = img
        for f in self.esperando.pop(url, []):
            try:
                f(img)
            except RuntimeError:      # el widget ya no existe (cambiaste de página)
                pass

    def cerrar(self):
        self.pool.clear()
        self.pool.waitForDone(3000)


# --- descargas con barra de progreso -------------------------------------------------------
_tareas = set()      # tareas en marcha: que Python no las borre antes de terminar


class TareaConProgreso(QThread):
    """Ejecuta funcion(*args, progreso=...) en segundo plano. 'progreso(fraccion, detalle)' puede
    llamarse desde el hilo: llega a la ventana por una señal (fraccion None = no se sabe cuánto va)."""

    avance = Signal(object, str)
    listo = Signal(object)

    def __init__(self, funcion, *args):
        super().__init__()
        self.funcion, self.args = funcion, args
        self.finished.connect(lambda: _tareas.discard(self))

    def run(self):
        try:
            r = self.funcion(*self.args, progreso=lambda f, d="": self.avance.emit(f, d or ""))
        except Exception as e:   # el error se muestra, no se esconde
            r = res.fallo("error inesperado: %s" % e)
        self.listo.emit(r)


def con_progreso(funcion, *args, al_avanzar=None, al_terminar=None):
    t = TareaConProgreso(funcion, *args)
    if al_avanzar:
        t.avance.connect(al_avanzar)
    if al_terminar:
        t.listo.connect(al_terminar)
    _tareas.add(t)
    t.start()
    return t


def megas(n):
    return "%.0f MB" % (n / 1024 ** 2) if n >= 1024 ** 2 else "%.0f KB" % (n / 1024)


class BarraDescarga(QWidget):
    """Barra de progreso con texto debajo. Si aún no se sabe cuánto va, se mueve sola
    (así nunca parece que se quedó colgada)."""

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.setContentsMargins(0, 6, 0, 2)
        caja.setSpacing(4)
        self.barra = QProgressBar()
        self.barra.setTextVisible(False)
        self.barra.setFixedHeight(10)
        self.barra.setStyleSheet(
            "QProgressBar{background:%s;border:none;border-radius:5px;}"
            "QProgressBar::chunk{background:%s;border-radius:5px;}" % (COLORES["tarjeta"], COLORES["violeta_claro"]))
        self.texto = rol(QLabel(""), "subtitulo")
        caja.addWidget(self.barra)
        caja.addWidget(self.texto)
        self.maximo = 0.0
        self.hide()

    def empezar(self, texto):
        self.maximo = 0.0
        self.barra.setRange(0, 0)              # en movimiento hasta que llegue el primer porcentaje
        self.texto.setText(texto)
        self.show()

    def avanzar(self, fraccion, detalle=""):
        if fraccion is None:
            if detalle:
                self.texto.setText(detalle)
            return
        self.maximo = max(self.maximo, min(1.0, fraccion))   # nunca va hacia atrás
        if self.barra.maximum() == 0:
            self.barra.setRange(0, 1000)
        self.barra.setValue(int(self.maximo * 1000))
        if self.maximo >= 1:
            detalle = "descargado, terminando la instalación…"
        self.texto.setText("%d %%%s" % (round(self.maximo * 100), "  ·  " + detalle if detalle else ""))

    def terminar(self):
        self.hide()


# --- página: lista de apps (inicio, categorías, búsqueda) ------------------------------
class PaginaLista(QWidget):
    def __init__(self, tienda):
        super().__init__()
        self.tienda = tienda
        caja = QVBoxLayout(self)
        caja.setContentsMargins(24, 18, 24, 12)
        cabecera = QHBoxLayout()
        self.titulo = rol(QLabel(""), "titulo")
        cabecera.addWidget(self.titulo, 1)
        self.pestanas = {}
        for clave, texto in (("populares", "Populares"), ("tendencias", "Tendencias"), ("novedades", "Novedades")):
            b = QPushButton(texto)
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, c=clave: self.tienda.mostrar_coleccion(c))
            cabecera.addWidget(b)
            self.pestanas[clave] = b
        caja.addLayout(cabecera)
        self.estado = EtiquetaResultado()
        caja.addWidget(self.estado)
        self.lista = QListWidget()
        self.lista.setViewMode(QListView.IconMode)
        self.lista.setIconSize(QSize(TAM_ICONO, TAM_ICONO))
        self.lista.setGridSize(QSize(210, 150))
        self.lista.setResizeMode(QListView.Adjust)
        self.lista.setMovement(QListView.Static)
        self.lista.setWordWrap(True)
        self.lista.setUniformItemSizes(True)
        self.lista.itemClicked.connect(lambda it: self.tienda.abrir_ficha(it.data(Qt.UserRole)))
        caja.addWidget(self.lista, 1)

    def preparar(self, titulo, pestana=None):
        self.titulo.setText(titulo)
        for clave, b in self.pestanas.items():
            b.setVisible(pestana is not None)
            b.setChecked(clave == pestana)
        self.lista.clear()
        self.estado.trabajando("Cargando desde Flathub…")

    def mostrar(self, apps, instaladas):
        self.lista.clear()
        if isinstance(apps, res.Resultado):
            self.estado.mostrar(apps)
            return
        if not apps:
            self.estado.mostrar(res.fallo("No se encontró ninguna app"))
            return
        self.estado.mostrar(None)
        for a in apps:
            marca = "  ✔" if a.id in instaladas else ""
            resumen = a.resumen if len(a.resumen) <= 60 else a.resumen[:57] + "…"
            if getattr(a, "recomendada", False):
                resumen = "★ Recomendada · %s" % a.desarrollador
            item = QListWidgetItem(_icono_kat("kat-store"), "%s%s\n%s" % (a.nombre, marca, resumen))
            item.setData(Qt.UserRole, a)
            item.setToolTip("%s\n%s" % (a.nombre, a.resumen))
            self.lista.addItem(item)
            self.tienda.imagenes.pedir(a.icono, lambda img, it=item: it.setIcon(QIcon(QPixmap.fromImage(img))))


# --- página: ficha de una app ----------------------------------------------------------
class PaginaFicha(QWidget):
    def __init__(self, tienda):
        super().__init__()
        self.tienda = tienda
        self.app = None
        exterior = QVBoxLayout(self)
        exterior.setContentsMargins(0, 0, 0, 0)
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        interior = QWidget()
        caja = QVBoxLayout(interior)
        caja.setContentsMargins(28, 18, 28, 18)
        volver = QPushButton("← Volver")
        volver.clicked.connect(self.tienda.volver)
        caja.addWidget(volver, 0, Qt.AlignLeft)

        fila = QHBoxLayout()
        self.icono = QLabel()
        self.icono.setFixedSize(96, 96)
        fila.addWidget(self.icono)
        datos = QVBoxLayout()
        self.nombre = rol(QLabel(""), "titulo")
        self.nombre.setWordWrap(True)
        self.nombre.setMinimumWidth(200)
        self.desarrollador = rol(QLabel(""), "subtitulo")
        self.resumen = QLabel("")
        self.resumen.setWordWrap(True)
        datos.addWidget(self.nombre)
        datos.addWidget(self.desarrollador)
        datos.addWidget(self.resumen)
        fila.addLayout(datos, 1)
        botones = QVBoxLayout()
        self.b_instalar = rol(QPushButton("Instalar"), "principal")
        self.b_abrir = rol(QPushButton("Abrir"), "principal")
        self.b_quitar = QPushButton("Desinstalar")
        self.b_instalar.clicked.connect(self._instalar)
        self.b_abrir.clicked.connect(self._abrir)
        self.b_quitar.clicked.connect(self._quitar)
        for b in (self.b_instalar, self.b_abrir, self.b_quitar):
            b.setMinimumWidth(150)
            botones.addWidget(b)
        botones.addStretch(1)
        fila.addLayout(botones)
        caja.addLayout(fila)
        self.estado = EtiquetaResultado()
        caja.addWidget(self.estado)
        self.barra = BarraDescarga()
        caja.addWidget(self.barra)

        self.datos = rol(QLabel(""), "subtitulo")
        self.datos.setWordWrap(True)
        self.datos.setTextFormat(Qt.RichText)
        self.datos.setOpenExternalLinks(True)
        caja.addWidget(self.datos)
        self.capturas = QHBoxLayout()
        caja.addLayout(self.capturas)
        self.descripcion = QLabel("")
        self.descripcion.setWordWrap(True)
        self.descripcion.setTextInteractionFlags(Qt.TextSelectableByMouse)
        caja.addWidget(self.descripcion)
        self.permisos_t = QLabel("Permisos de la app")
        self.permisos_t.setStyleSheet("font-weight:600;margin-top:10px;")
        self.permisos = QLabel("")
        self.permisos.setWordWrap(True)
        caja.addWidget(self.permisos_t)
        caja.addWidget(self.permisos)
        caja.addStretch(1)
        area.setWidget(interior)
        exterior.addWidget(area)

    def _es_kat(self):
        return isinstance(self.app, katstudios.AppKat)

    def _abrir(self):
        self.estado.mostrar(katstudios.abrir() if self._es_kat() else flatpak.abrir(self.app.id))

    def cargar(self, app):
        self.app = app
        self.nombre.setText(app.nombre)
        self.desarrollador.setText(app.desarrollador or app.id)
        self.resumen.setText(app.resumen)
        self.icono.setPixmap(_icono_kat("kat-store").pixmap(96, 96))
        self.barra.terminar()
        self.tienda.imagenes.pedir(app.icono, self._poner_icono)
        self.descripcion.setText("")
        self.datos.setText("")
        self._limpiar_capturas()
        self._botones()
        if self._es_kat():                              # app de Kat Studios: datos de su GitHub
            self.descripcion.setText(app.descripcion)
            self.estado.trabajando("Consultando la última versión en GitHub…")
            en_segundo_plano(self._leer_kat, al_terminar=self._kat_lista)
            return
        self.estado.trabajando("Cargando la ficha desde Flathub…")
        en_segundo_plano(self._leer_ficha, app.id, al_terminar=self._ficha_lista)

    @staticmethod
    def _leer_kat():
        try:
            return katstudios.ultima_version()
        except (flathub.ErrorRed, ValueError) as e:
            return res.fallo(str(e))

    def _kat_lista(self, info):
        if not self._es_kat():
            return
        partes = []
        if isinstance(info, res.Resultado):
            self.estado.mostrar(info)
        else:
            self.estado.mostrar(None)
            partes.append("Versión %s" % info["version"])
            partes.append("%.0f MB" % (info["tamano"] / 1024 ** 2))
            partes.append("Verificada con SHA-256")
            instalada = katstudios.version_instalada()
            if instalada and instalada != info["version"]:
                partes.append("Tienes la %s: el launcher se actualiza solo" % instalada)
        partes.append("Fuente: Kat Studios (GitHub)")
        partes.append('<a href="%s" style="color:%s">Sitio web</a>' % (self.app.web, COLORES["violeta_claro"]))
        self.datos.setText("  ·  ".join(partes))

    @staticmethod
    def _leer_ficha(app_id):
        try:
            return flathub.ficha(app_id)
        except (flathub.ErrorRed, ValueError) as e:
            return res.fallo(str(e))

    def _poner_icono(self, img):
        self.icono.setPixmap(QPixmap.fromImage(img).scaled(96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _limpiar_capturas(self):
        while self.capturas.count():
            w = self.capturas.takeAt(0).widget()
            if w:
                w.deleteLater()

    def _ficha_lista(self, f):
        if isinstance(f, res.Resultado):
            self.estado.mostrar(f)
            return
        if self.app is None or f.id != self.app.id:
            return                                   # el usuario ya abrió otra
        self.estado.mostrar(None)
        if f.nombre:
            self.nombre.setText(f.nombre)
        if f.desarrollador:
            self.desarrollador.setText(f.desarrollador)
        partes = []
        if f.version:
            partes.append("Versión %s" % f.version)
        if f.licencia:
            partes.append("Licencia %s" % f.licencia)
        partes.append("Fuente: Flathub")
        if f.web:
            partes.append('<a href="%s" style="color:%s">Sitio web</a>' % (f.web, COLORES["violeta_claro"]))
        self.datos.setText("  ·  ".join(partes))
        self.descripcion.setText(f.descripcion or f.resumen)
        for url in f.capturas[:2]:
            l = QLabel("…")
            l.setFixedSize(300, 190)
            l.setAlignment(Qt.AlignCenter)
            l.setStyleSheet("background:%s;border-radius:8px;" % COLORES["tarjeta"])
            self.capturas.addWidget(l)
            self.tienda.imagenes.pedir(url, lambda img, lab=l: lab.setPixmap(
                QPixmap.fromImage(img).scaled(300, 190, Qt.KeepAspectRatio, Qt.SmoothTransformation)))
        self.capturas.addStretch(1)

    def _botones(self):
        instalada = self.app.id in self.tienda.instaladas
        self.b_instalar.setVisible(not instalada)
        self.b_abrir.setVisible(instalada)
        self.b_quitar.setVisible(instalada)
        for b in (self.b_instalar, self.b_abrir, self.b_quitar):
            b.setEnabled(True)
        if self._es_kat():
            self.permisos.setText("Programa normal (no Flatpak): se instala solo para tu usuario en "
                                  "~/.local/share/KatLauncher, sin contraseña de administrador. Tus perfiles y "
                                  "mundos quedan en ~/.katlauncher.")
        elif instalada:
            p = flatpak.permisos(self.app.id)
            self.permisos.setText("\n".join("• " + x for x in p) if p else "Sin permisos especiales")
        else:
            self.permisos.setText("Se muestran cuando la app está instalada.")

    def _accion(self, funcion, texto, barra=False):
        """barra=True: funcion(app_id, progreso=...) avisa de cuánto va y se ve en la barra."""
        for b in (self.b_instalar, self.b_abrir, self.b_quitar):
            b.setEnabled(False)
        self.estado.trabajando(texto)
        app_id = self.app.id
        ficha = self.app

        def fin(r):
            if self.app is ficha:
                self.barra.terminar()
            self.estado.mostrar(r)
            self.tienda.refrescar_instaladas()
            if self.app and self.app.id == app_id:
                self._botones()
        if not barra:
            en_segundo_plano(funcion, app_id, al_terminar=fin)
            return
        self.barra.empezar("Preparando la descarga…")

        def avanzar(fraccion, detalle):
            if self.app is ficha:                    # el usuario puede estar mirando otra app
                self.barra.avanzar(fraccion, detalle)
        con_progreso(funcion, app_id, al_avanzar=avanzar, al_terminar=fin)

    def _instalar(self):
        aviso = " (estás en modo live: se guarda en la RAM)" if self.tienda.en_live else ""
        if self._es_kat():
            def bajar(_id, progreso):
                return katstudios.instalar(progreso=lambda hecho, total: progreso(
                    hecho / total if total else None,
                    "%s de %s" % (megas(hecho), megas(total)) if total else megas(hecho)))
            self._accion(bajar, "Descargando y comprobando %s…%s" % (self.app.nombre, aviso), barra=True)
            return
        self._accion(flatpak.instalar, "Instalando %s…%s" % (self.app.nombre, aviso), barra=True)

    def _quitar(self):
        if self._es_kat():
            self._accion(lambda _id: katstudios.desinstalar(), "Desinstalando %s…" % self.app.nombre)
            return
        self._accion(flatpak.desinstalar, "Desinstalando %s…" % self.app.nombre)


# --- página: instaladas / actualizaciones / fuentes ----------------------------------
class PaginaGestion(QWidget):
    def __init__(self, tienda):
        super().__init__()
        self.tienda = tienda
        caja = QVBoxLayout(self)
        caja.setContentsMargins(24, 18, 24, 12)
        self.titulo = rol(QLabel(""), "titulo")
        caja.addWidget(self.titulo)
        self.explicacion = rol(QLabel(""), "subtitulo")
        self.explicacion.setWordWrap(True)
        caja.addWidget(self.explicacion)
        self.estado = EtiquetaResultado()
        caja.addWidget(self.estado)
        self.barra = BarraDescarga()
        caja.addWidget(self.barra)
        self.lista = QListWidget()
        self.lista.setIconSize(QSize(32, 32))
        self.lista.itemClicked.connect(self._clic)
        caja.addWidget(self.lista, 1)
        fila = QHBoxLayout()
        fila.addStretch(1)
        self.boton = rol(QPushButton(""), "principal")
        self.boton.clicked.connect(self._boton)
        fila.addWidget(self.boton)
        caja.addLayout(fila)
        self.modo = None

    def cargar(self, modo):
        self.modo = modo
        self.lista.clear()
        self.boton.hide()
        titulos = {"instaladas": "Instaladas", "actualizaciones": "Actualizaciones", "fuentes": "Fuentes verificadas"}
        self.titulo.setText(titulos[modo])
        if not flatpak.disponible():
            self.explicacion.setText("")
            self.estado.mostrar(res.no_disponible("Esta sección muestra lo instalado en Kat OS. "
                                                  "En %s solo puedes explorar el catálogo." % plataforma.nombre()))
            return
        self.estado.trabajando("Consultando…")
        if modo == "instaladas":
            self.explicacion.setText("Apps instaladas desde Kat Store (Flatpak). Haz clic en una para abrirla o quitarla.")
            en_segundo_plano(flatpak.instaladas, al_terminar=self._instaladas)
        elif modo == "actualizaciones":
            self.explicacion.setText("Versiones nuevas de tus apps. Las actualizaciones del sistema las "
                                     "gestionará Kat Update Center.")
            en_segundo_plano(flatpak.actualizaciones, al_terminar=self._actualizaciones)
        else:
            self.explicacion.setText("Kat Store solo instala desde fuentes verificadas.")
            en_segundo_plano(flatpak.fuentes, al_terminar=self._fuentes)

    def _instaladas(self, lista):
        if isinstance(lista, res.Resultado):
            self.estado.mostrar(lista)
            return
        lista = list(lista or [])
        if katstudios.instalado():
            lista.insert(0, {"id": katstudios.ID_LAUNCHER, "nombre": "KatLauncher (Kat Studios)",
                             "version": katstudios.version_instalada(), "tamano": "~/.local/share"})
        self.estado.mostrar(res.hecho("%d apps instaladas" % len(lista)))
        for a in lista:
            item = QListWidgetItem(_icono_kat("kat-store"), "%s   ·   %s   ·   %s" % (a["nombre"], a["version"] or "—",
                                                                                     a["tamano"]))
            item.setData(Qt.UserRole, katstudios.katlauncher() if a["id"] == katstudios.ID_LAUNCHER
                         else flathub.App(a["id"], a["nombre"]))
            self.lista.addItem(item)

    def _actualizaciones(self, lista):
        if isinstance(lista, res.Resultado):
            self.estado.mostrar(lista)
            return
        lista = lista or []
        if not lista:
            self.estado.mostrar(res.hecho("Todas tus apps están al día"))
            return
        self.estado.mostrar(res.hecho("%d actualización%s disponible%s" % (len(lista), "" if len(lista) == 1 else "es",
                                                                          "" if len(lista) == 1 else "s")))
        for a in lista:
            self.lista.addItem("%s   →   %s" % (a["id"], a["version"] or "nueva versión"))
        self.boton.setText("Actualizar todo")
        self.boton.show()

    def _fuentes(self, lista):
        if isinstance(lista, res.Resultado):
            self.estado.mostrar(lista)
            return
        self.estado.mostrar(None)
        for f in lista or []:
            verificada = "  ✔ verificada" if f["nombre"] == flatpak.REMOTO else ""
            self.lista.addItem("%s   ·   %s%s" % (f["nombre"], f["url"], verificada))
        self.lista.addItem("Kat Studios   ·   github.com/%s   ✔ verificada (SHA-256)" % katstudios.REPO)

    def _clic(self, item):
        app = item.data(Qt.UserRole)
        if isinstance(app, flathub.App):
            self.tienda.abrir_ficha(app)

    def _boton(self):
        if self.modo == "actualizaciones":
            self.boton.setEnabled(False)
            self.estado.trabajando("Actualizando apps…")
            self.barra.empezar("Preparando las actualizaciones…")

            def fin(r):
                self.barra.terminar()
                self.boton.setEnabled(True)
                self.estado.mostrar(r)
                if r.ok:
                    self.cargar("actualizaciones")
            con_progreso(flatpak.actualizar_todo, al_avanzar=self.barra.avanzar, al_terminar=fin)


def buscar_con_recomendacion(texto):
    """Resultados de Flathub con KatLauncher primero si encaja (sin quitar ninguno).
    Si Flathub no responde pero encaja, al menos se recomienda KatLauncher."""
    try:
        return katstudios.con_recomendacion(texto, flathub.buscar(texto))
    except flathub.ErrorRed:
        if katstudios.recomendar(texto):
            return [katstudios.katlauncher(recomendada=True)]
        raise


# --- ventana -----------------------------------------------------------------------
class VentanaStore(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kat Store")
        self.setWindowIcon(_icono_kat("kat-store"))
        self.resize(1120, 720)
        self.imagenes = Imagenes()
        self.instaladas = set()
        from katui import sistema
        self.en_live = sistema.en_modo_live()
        self._anterior = 0

        raiz = QHBoxLayout(self)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)
        lateral = rol(QFrame(), "lateral")
        lateral.setFixedWidth(230)
        lat = QVBoxLayout(lateral)
        lat.setContentsMargins(14, 18, 14, 14)
        marca = QLabel("Kat Store")
        marca.setStyleSheet("font-size:15pt;font-weight:700;color:%s;padding-left:6px;" % COLORES["violeta_claro"])
        lat.addWidget(marca)
        self.buscador = QLineEdit()
        self.buscador.setPlaceholderText("Buscar apps y juegos…")
        self.buscador.setClearButtonEnabled(True)
        self.buscador.returnPressed.connect(self.buscar)
        lat.addWidget(self.buscador)
        self.menu = QListWidget()
        self.menu.setIconSize(QSize(20, 20))
        self.menu.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.menu.setTextElideMode(Qt.ElideRight)
        self.menu.itemClicked.connect(self._menu)
        lat.addWidget(self.menu, 1)
        if self.en_live:
            v = rol(QLabel("Modo live: lo que instales se guarda en la RAM y se borra al apagar."), "aviso")
            v.setWordWrap(True)
            lat.addWidget(v)
        if plataforma.VISTA_PREVIA:
            v = rol(QLabel("Vista previa en %s: puedes explorar el catálogo real; instalar es en Kat OS."
                           % plataforma.nombre()), "aviso")
            v.setWordWrap(True)
            lat.addWidget(v)
        raiz.addWidget(lateral)

        self.pila = QStackedWidget()
        self.p_lista = PaginaLista(self)
        self.p_ficha = PaginaFicha(self)
        self.p_gestion = PaginaGestion(self)
        for p in (self.p_lista, self.p_ficha, self.p_gestion):
            self.pila.addWidget(p)
        raiz.addWidget(self.pila, 1)
        self._llenar_menu()
        self.refrescar_instaladas()
        self.mostrar_coleccion("populares")

    def _seccion(self, texto):
        item = QListWidgetItem(texto.upper())
        item.setFlags(Qt.NoItemFlags)
        item.setForeground(Qt.gray)
        self.menu.addItem(item)

    def _llenar_menu(self):
        def agregar(texto, dato, icono="kat-store"):
            item = QListWidgetItem(_icono_kat(icono), texto)
            item.setData(Qt.UserRole, dato)
            self.menu.addItem(item)
        agregar("Inicio", ("coleccion", "populares"))
        self._seccion("Categorías")
        for cat_id, nombre in flathub.CATEGORIAS:
            agregar(nombre, ("categoria", cat_id))
        self._seccion("Tus apps")
        agregar("Instaladas", ("gestion", "instaladas"), "kat-files")
        agregar("Actualizaciones", ("gestion", "actualizaciones"), "kat-update")
        agregar("Fuentes verificadas", ("gestion", "fuentes"), "kat-security")

    def _menu(self, item):
        dato = item.data(Qt.UserRole)
        if not dato:
            return
        tipo, valor = dato
        if tipo == "coleccion":
            self.mostrar_coleccion(valor)
        elif tipo == "categoria":
            self.mostrar_categoria(valor)
        else:
            self.pila.setCurrentWidget(self.p_gestion)
            self.p_gestion.cargar(valor)

    # --- cargar listas desde Flathub ---------------------------------------
    def _cargar_lista(self, titulo, funcion, *args, pestana=None):
        self.pila.setCurrentWidget(self.p_lista)
        self.p_lista.preparar(titulo, pestana)

        def consulta():
            try:
                return funcion(*args)
            except flathub.ErrorRed as e:
                return res.fallo(str(e))
        en_segundo_plano(consulta, al_terminar=lambda apps: self.p_lista.mostrar(apps, self.instaladas))

    def mostrar_coleccion(self, clave):
        funciones = {"populares": flathub.populares, "tendencias": flathub.tendencias, "novedades": flathub.novedades}
        funcion = funciones[clave]
        if clave == "populares":                   # en Inicio, KatLauncher destacada
            def funcion(f=funciones[clave]):
                return katstudios.con_destacada(f())
        self._cargar_lista("Descubre", funcion, pestana=clave)

    def mostrar_categoria(self, cat_id):
        if cat_id == "Game":
            self._cargar_lista(dict(flathub.CATEGORIAS)[cat_id],
                               lambda: katstudios.con_destacada(flathub.categoria(cat_id)))
            return
        self._cargar_lista(dict(flathub.CATEGORIAS)[cat_id], flathub.categoria, cat_id)

    def buscar(self):
        texto = self.buscador.text().strip()
        if texto:
            self._cargar_lista("Resultados para «%s»" % texto, buscar_con_recomendacion, texto)

    # --- ficha ------------------------------------------------------------------
    def abrir_ficha(self, app):
        if not isinstance(app, flathub.App):
            return
        self._anterior = self.pila.currentIndex()
        self.pila.setCurrentWidget(self.p_ficha)
        self.p_ficha.cargar(app)

    def volver(self):
        self.pila.setCurrentIndex(self._anterior if self._anterior != self.pila.indexOf(self.p_ficha) else 0)

    def refrescar_instaladas(self):
        self.instaladas = set(flatpak.ids_instalados())
        if katstudios.instalado():
            self.instaladas.add(katstudios.ID_LAUNCHER)

    def closeEvent(self, evento):
        self.imagenes.cerrar()
        super().closeEvent(evento)
