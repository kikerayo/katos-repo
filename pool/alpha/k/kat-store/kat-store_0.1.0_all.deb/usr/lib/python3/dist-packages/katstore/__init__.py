"""Kat Store: la tienda de apps de Kat OS.

- flathub.py: catálogo público de Flathub (buscar, populares, categorías, fichas).
  Funciona en cualquier sistema con internet (también en Windows, para mirar).
- flatpak.py: instalar, quitar, actualizar, permisos y fuentes (solo Kat OS).
- ventana.py: la interfaz.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Store"
