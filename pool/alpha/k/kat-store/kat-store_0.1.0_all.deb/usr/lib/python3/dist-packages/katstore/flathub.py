"""Catálogo de Flathub (API pública v2: https://flathub.org/api/v2).

Solo se leen datos públicos de las apps. No se envía nada del usuario salvo
lo que escribe en el buscador.
"""

import hashlib
import html
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request

API = "https://flathub.org/api/v2"
AGENTE = "KatStore/0.1 (Kat OS)"
TIEMPO = 20

CATEGORIAS = [
    # (id de Flathub, nombre en español)
    ("Game", "Juegos"),
    ("AudioVideo", "Audio y video"),
    ("Graphics", "Gráficos y fotos"),
    ("Office", "Oficina"),
    ("Network", "Internet y redes"),
    ("Development", "Programación"),
    ("Education", "Educación"),
    ("Utility", "Utilidades"),
    ("System", "Sistema"),
    ("Science", "Ciencia"),
]


class ErrorRed(RuntimeError):
    """No se pudo hablar con Flathub (sin internet, Flathub caído...)."""


class App:
    def __init__(self, app_id, nombre, resumen="", icono="", instalaciones=0, desarrollador=""):
        self.id = app_id
        self.nombre = nombre or app_id
        self.resumen = resumen or ""
        self.icono = icono or ""
        self.instalaciones = instalaciones or 0
        self.desarrollador = desarrollador or ""

    def __repr__(self):
        return "App(%s)" % self.id


class Ficha(App):
    """Detalle completo de una app."""

    def __init__(self, app_id, nombre, resumen, icono, desarrollador, descripcion, capturas, version, licencia,
                 web):
        super().__init__(app_id, nombre, resumen, icono, 0, desarrollador)
        self.descripcion = descripcion
        self.capturas = capturas
        self.version = version
        self.licencia = licencia
        self.web = web


def _pedir(ruta, datos=None):
    url = API + ruta
    cuerpo = json.dumps(datos).encode("utf-8") if datos is not None else None
    peticion = urllib.request.Request(url, data=cuerpo, headers={"User-Agent": AGENTE, "Accept": "application/json"})
    if cuerpo is not None:
        peticion.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(peticion, timeout=TIEMPO) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ErrorRed("Flathub no tiene esa app") from e
        raise ErrorRed("Flathub respondió con error %d" % e.code) from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ErrorRed("Sin conexión con Flathub. Revisa tu internet.") from e
    except ValueError as e:
        raise ErrorRed("Flathub envió una respuesta que no se entiende") from e


def apps_de(respuesta):
    """Convierte los 'hits' de una respuesta de colección o búsqueda en una lista de App."""
    salida = []
    for h in respuesta.get("hits", []):
        app_id = h.get("app_id") or h.get("id")
        if not app_id:
            continue
        salida.append(App(app_id, h.get("name"), h.get("summary"), h.get("icon"),
                          h.get("installs_last_month"), h.get("developer_name")))
    return salida


def populares(n=30):
    return apps_de(_pedir("/collection/popular?page=1&per_page=%d" % n))


def tendencias(n=30):
    return apps_de(_pedir("/collection/trending?page=1&per_page=%d" % n))


def novedades(n=30):
    return apps_de(_pedir("/collection/recently-updated?page=1&per_page=%d" % n))


def categoria(cat_id, n=60):
    if cat_id not in dict(CATEGORIAS):
        raise ValueError("categoría desconocida: %s" % cat_id)
    return apps_de(_pedir("/collection/category/%s?page=1&per_page=%d" % (cat_id, n)))


def buscar(texto):
    texto = (texto or "").strip()
    if not texto:
        return []
    return apps_de(_pedir("/search", {"query": texto}))


def texto_plano(descripcion_html):
    """La descripción de Flathub viene en HTML sencillo (<p>, <ul><li>): pasarla a texto legible."""
    t = descripcion_html or ""
    t = re.sub(r"<li>\s*", "• ", t)
    t = re.sub(r"</(p|li|ul|ol)>", "\n", t)
    t = re.sub(r"<[^>]+>", "", t)
    t = html.unescape(t)
    t = re.sub(r"[ \t]+", " ", t)
    return re.sub(r"\n\s*\n+", "\n\n", t).strip()


def ficha_de(datos, app_id):
    capturas = []
    for c in datos.get("screenshots") or []:
        tam = c.get("sizes") or []
        # la más cercana a ~800 px de ancho
        tam = sorted(tam, key=lambda s: abs(int(s.get("width") or 0) - 800))
        if tam:
            capturas.append(tam[0]["src"])
    versiones = datos.get("releases") or []
    urls = datos.get("urls") or {}
    return Ficha(app_id, datos.get("name"), datos.get("summary"), datos.get("icon"),
                 datos.get("developer_name"), texto_plano(datos.get("description")), capturas[:4],
                 versiones[0].get("version", "") if versiones else "", datos.get("project_license") or "",
                 urls.get("homepage", ""))


def ficha(app_id):
    if not re.match(r"^[A-Za-z0-9_.-]+$", app_id or ""):
        raise ValueError("id de app inválido")
    return ficha_de(_pedir("/appstream/%s?locale=es" % urllib.parse.quote(app_id)), app_id)


# --- imágenes (iconos y capturas) con caché en disco ---------------------
def carpeta_cache():
    if os.name == "nt":
        base = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "KatOS", "cache")
    else:
        base = os.environ.get("XDG_CACHE_HOME") or os.path.join(os.path.expanduser("~"), ".cache")
        base = os.path.join(base, "katos")
    ruta = os.path.join(base, "store")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def imagen(url):
    """Descarga (o lee de la caché) una imagen de Flathub. Devuelve los bytes o None."""
    if not url or not url.startswith("https://"):
        return None
    nombre = hashlib.sha1(url.encode("utf-8")).hexdigest() + os.path.splitext(urllib.parse.urlparse(url).path)[1]
    ruta = os.path.join(carpeta_cache(), nombre)
    if os.path.exists(ruta):
        with open(ruta, "rb") as f:
            return f.read()
    try:
        peticion = urllib.request.Request(url, headers={"User-Agent": AGENTE})
        with urllib.request.urlopen(peticion, timeout=TIEMPO) as r:
            datos = r.read(8 * 1024 * 1024)
    except (urllib.error.URLError, TimeoutError, OSError):
        return None
    with open(ruta, "wb") as f:
        f.write(datos)
    return datos
