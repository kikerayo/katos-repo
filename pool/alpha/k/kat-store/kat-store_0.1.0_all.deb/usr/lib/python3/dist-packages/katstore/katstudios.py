"""Kat Studios: apps del propio estudio de Kat OS en Kat Store (además de Flathub).

Por ahora: KatLauncher, el launcher de Minecraft Java de Kat Studios.
- Todo es real: la versión, la descarga y su huella SHA-256 salen de las
  publicaciones (releases) de GitHub del proyecto. Nada inventado.
- Instalar: baja el paquete para Linux, comprueba la huella SHA-256, lo
  descomprime de forma segura y ejecuta su propio install.sh (sin sudo:
  queda en ~/.local/share/KatLauncher, solo para tu usuario).
- Al buscar "launcher", "minecraft", "mods"... se RECOMIENDA KatLauncher
  primero, pero los demás resultados de Flathub siguen ahí: no se oculta nada.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import tarfile
import tempfile
import unicodedata
import urllib.error
import urllib.request

from katui import acciones as res
from katui import plataforma

from .flathub import AGENTE, App, ErrorRed, carpeta_cache

REPO = "FerCT-oct/losctstudios-katstudios"
API_ULTIMA = "https://api.github.com/repos/%s/releases/latest" % REPO
WEB = "https://ferct-oct.github.io/losctstudios-katstudios/"
FUENTE = "Kat Studios"
ID_LAUNCHER = "net.katlauncher.KatLauncher"
PATRON_LINUX = re.compile(r"^KatLauncher-[\w.]+-linux-x86_64\.tar\.gz$")
TAMANO_MAX = 2 * 1024 ** 3                  # 2 GB: por si algo raro, no llenar el disco

# Palabras que hacen que Kat Store recomiende KatLauncher (sin acentos, en minúscula).
PALABRAS = {"launcher", "launchers", "lanzador", "minecraft", "mods", "mod", "modpack", "modpacks",
            "fabric", "forge", "neoforge", "quilt", "katlauncher", "skins", "mincraft", "maicra"}

DESCRIPCION = (
    "Un launcher de Minecraft Java con perfiles offline, mods y modpacks en un clic, skins, amigos y salas "
    "para jugar juntos. Gratis y sin cuenta obligatoria.\n\n"
    "• Perfiles aislados: cada uno guarda su versión, loader, mods, mundos, RAM y resolución.\n"
    "• Mods y modpacks de Modrinth y CurseForge con dependencias; importa archivos .mrpack.\n"
    "• Vanilla, Fabric, Forge, NeoForge y Quilt, con descarga y reparación automática.\n"
    "• Skins con vista 3D, Kat Social (amigos y chat), salas con KatCraft, KaBackup y trofeos.\n"
    "• Cuatro interfaces: Kat Cosmic, XMBKat, Kat Epic y Kat Classic (la más ligera).\n\n"
    "Para jugar en servidores premium necesitas una copia de Minecraft. Los perfiles offline funcionan "
    "sin cuenta de Microsoft ni de Google.")


class AppKat(App):
    """App de Kat Studios (no viene de Flathub)."""

    fuente = FUENTE

    def __init__(self, app_id, nombre, resumen, icono, desarrollador, web, descripcion):
        super().__init__(app_id, nombre, resumen, icono, 0, desarrollador)
        self.web = web
        self.descripcion = descripcion
        self.recomendada = False

    def __repr__(self):
        return "AppKat(%s)" % self.id


def katlauncher(recomendada=False):
    a = AppKat(ID_LAUNCHER, "KatLauncher",
               "Tu Minecraft, a tu manera: perfiles, mods, modpacks, skins y amigos",
               WEB + "assets/kat-launcher-logo.png", "Kat Studios", WEB, DESCRIPCION)
    a.recomendada = recomendada
    return a


def _palabras(texto):
    t = unicodedata.normalize("NFD", (texto or "").lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return set(re.findall(r"[a-z0-9]+", t))


def recomendar(texto):
    """True si al buscar 'texto' conviene recomendar KatLauncher."""
    return bool(_palabras(texto) & PALABRAS)


def con_recomendacion(texto, apps):
    """Los resultados de Flathub con KatLauncher primero si encaja. No se quita ninguno."""
    apps = list(apps or [])
    if not recomendar(texto):
        return apps
    return [katlauncher(recomendada=True)] + [a for a in apps if a.id != ID_LAUNCHER]


def con_destacada(apps):
    """Para Inicio y Juegos: KatLauncher destacada al principio."""
    return [katlauncher(recomendada=True)] + [a for a in list(apps or []) if a.id != ID_LAUNCHER]


# --- la versión publicada (GitHub) ---------------------------------------------
def leer_publicacion(datos):
    """De la respuesta de la API de GitHub saca lo necesario para Linux."""
    for a in datos.get("assets") or []:
        if PATRON_LINUX.match(a.get("name", "")):
            digest = a.get("digest") or ""
            return {
                "version": (datos.get("tag_name") or "").lstrip("v"),
                "nombre": datos.get("name") or "",
                "notas": datos.get("body") or "",
                "archivo": a["name"],
                "url": a.get("browser_download_url", ""),
                "tamano": int(a.get("size") or 0),
                "sha256": digest.split(":", 1)[1].lower() if digest.startswith("sha256:") else "",
            }
    raise ValueError("La publicación no trae paquete para Linux")


def ultima_version(abrir=urllib.request.urlopen):
    peticion = urllib.request.Request(API_ULTIMA, headers={"User-Agent": AGENTE,
                                                           "Accept": "application/vnd.github+json"})
    try:
        with abrir(peticion, timeout=20) as r:
            datos = json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ErrorRed("Sin conexión con GitHub (Kat Studios)") from e
    except ValueError as e:
        raise ErrorRed("Respuesta rara de GitHub") from e
    info = leer_publicacion(datos)
    if not info["url"].startswith("https://github.com/%s/releases/download/" % REPO):
        raise ValueError("Descarga fuera del proyecto de Kat Studios")
    return info


# --- instalado o no ----------------------------------------------------------------
def _datos():
    return os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")


def carpeta_instalacion():
    return os.path.join(_datos(), "KatLauncher")


def _registro():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    ruta = os.path.join(base, "katos", "store")
    os.makedirs(ruta, exist_ok=True)
    return ruta


def instalado():
    return plataforma.ES_LINUX and os.path.isfile(os.path.join(carpeta_instalacion(), "KatLauncher"))


def version_instalada():
    try:
        with open(os.path.join(_registro(), "katlauncher.json"), encoding="utf-8") as f:
            return json.load(f).get("version", "")
    except (OSError, ValueError):
        return ""


# --- instalar, abrir, desinstalar ---------------------------------------------------
def descargar(info, destino, abrir=urllib.request.urlopen, progreso=None):
    """Baja el paquete comprobando la huella SHA-256 mientras llega. Devuelve la ruta."""
    if not info.get("sha256"):
        raise ValueError("La publicación no trae huella SHA-256: no se instala sin poder comprobarla")
    if info.get("tamano", 0) > TAMANO_MAX:
        raise ValueError("El paquete es demasiado grande")
    ruta = os.path.join(destino, info["archivo"])
    h = hashlib.sha256()
    hecho = 0
    peticion = urllib.request.Request(info["url"], headers={"User-Agent": AGENTE})
    try:
        with abrir(peticion, timeout=60) as r, open(ruta, "wb") as f:
            while True:
                trozo = r.read(1024 * 1024)
                if not trozo:
                    break
                hecho += len(trozo)
                if hecho > TAMANO_MAX:
                    raise ValueError("La descarga es más grande de lo esperado")
                h.update(trozo)
                f.write(trozo)
                if progreso:
                    progreso(hecho, info.get("tamano") or 0)
    except (urllib.error.URLError, TimeoutError) as e:
        raise ErrorRed("Se cortó la descarga de KatLauncher") from e
    if h.hexdigest() != info["sha256"]:
        os.remove(ruta)
        raise ValueError("La descarga no coincide con su huella SHA-256: se borró y no se instaló")
    return ruta


def descomprimir(ruta, destino):
    """Descomprime el .tar.gz sin dejar que nada se escriba fuera de 'destino'. Devuelve la carpeta."""
    with tarfile.open(ruta, "r:gz") as t:
        nombres = t.getnames()
        if hasattr(tarfile, "data_filter"):
            t.extractall(destino, filter="data")             # sin rutas absolutas ni ".." ni enlaces fuera
        else:                                                 # Python viejo: comprobar a mano
            for m in t.getmembers():
                final = os.path.realpath(os.path.join(destino, m.name))
                if not final.startswith(os.path.realpath(destino) + os.sep) or m.isdev():
                    raise ValueError("El paquete trae rutas peligrosas")
            t.extractall(destino)
    raiz = {n.split("/", 1)[0] for n in nombres}
    carpeta = os.path.join(destino, raiz.pop()) if len(raiz) == 1 else destino
    if not os.path.isfile(os.path.join(carpeta, "install.sh")):
        raise ValueError("El paquete no trae install.sh")
    return carpeta


def instalar(abrir=urllib.request.urlopen, progreso=None, ejecutar=subprocess.run):
    if not plataforma.ES_LINUX:
        return res.no_disponible("KatLauncher se instala desde Kat Store en Kat OS. En Windows usa su "
                                 "instalador de la web.")
    try:
        info = ultima_version(abrir)
        with tempfile.TemporaryDirectory(dir=carpeta_cache()) as tmp:
            paquete = descargar(info, tmp, abrir, progreso)
            carpeta = descomprimir(paquete, tmp)
            os.remove(paquete)                                # libera espacio antes de copiar
            r = ejecutar(["sh", "install.sh"], cwd=carpeta, capture_output=True, text=True, timeout=600)
            if r.returncode != 0:
                return res.fallo("El instalador de KatLauncher falló: %s" % (r.stderr or r.stdout).strip()[-300:])
            shutil.copy(os.path.join(carpeta, "install.sh"), os.path.join(_registro(), "katlauncher-install.sh"))
        with open(os.path.join(_registro(), "katlauncher.json"), "w", encoding="utf-8") as f:
            json.dump({"version": info["version"], "sha256": info["sha256"]}, f)
    except (ErrorRed, ValueError, OSError, tarfile.TarError, subprocess.TimeoutExpired) as e:
        return res.fallo(str(e))
    return res.hecho("KatLauncher %s instalado y comprobado con SHA-256" % info["version"])


def abrir():
    binario = os.path.join(carpeta_instalacion(), "KatLauncher")
    if not os.path.isfile(binario):
        return res.no_disponible("KatLauncher no está instalado")
    try:
        subprocess.Popen([binario], cwd=carpeta_instalacion(), stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as e:
        return res.fallo("No se pudo abrir: %s" % e)
    return res.hecho("Abriendo KatLauncher")


def desinstalar(ejecutar=subprocess.run):
    script = os.path.join(_registro(), "katlauncher-install.sh")
    if not os.path.isfile(script):
        return res.fallo("No encuentro el desinstalador de KatLauncher (¿se instaló desde Kat Store?)")
    r = ejecutar(["sh", script, "--uninstall"], capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        return res.fallo((r.stderr or r.stdout).strip()[-300:] or "falló el desinstalador")
    try:
        os.remove(os.path.join(_registro(), "katlauncher.json"))
    except OSError:
        pass
    return res.hecho("KatLauncher desinstalado. Tus perfiles y mundos siguen en ~/.katlauncher")
