"""Punto de entrada de Kat Store.  Uso: kat-store [--buscar texto]"""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaStore

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Store")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaStore()
    if "--buscar" in argv and argv.index("--buscar") + 1 < len(argv):
        v.buscador.setText(argv[argv.index("--buscar") + 1])
        v.buscar()
    v.show()
    try:
        from katcore.cliente import KatCoreCliente
        KatCoreCliente().registrar_app(APP_ID, VERSION)
    except Exception:
        pass
    codigo = app.exec()
    v.imagenes.cerrar()
    del v
    return codigo
