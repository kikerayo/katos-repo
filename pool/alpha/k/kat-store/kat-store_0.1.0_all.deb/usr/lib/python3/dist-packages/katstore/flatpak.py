"""Apps instaladas con Flatpak: listar, instalar, quitar, actualizar, permisos y fuentes.

Instalar y quitar es para todo el sistema (--system), igual que hace Kat
Bienvenida; polkit permite hacerlo a los administradores sin contraseña.
"""

import re
import subprocess

from katui import acciones, plataforma

REMOTO = "flathub"
_ID = re.compile(r"^[A-Za-z0-9_.-]+$")


def disponible():
    return plataforma.tiene("flatpak")


def _correr(*args, tiempo=60):
    return subprocess.run(["flatpak"] + list(args), capture_output=True, text=True, timeout=tiempo,
                          encoding="utf-8", errors="replace")


def interpretar_tabla(texto, columnas):
    """Salida de 'flatpak ... --columns=a,b,c' (separada por tabuladores) -> lista de dicts."""
    filas = []
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        partes = linea.split("\t")
        partes += [""] * (len(columnas) - len(partes))
        filas.append(dict(zip(columnas, (p.strip() for p in partes))))
    return filas


def instaladas():
    """[{'id','nombre','version','tamano','origen'}] o None si aquí no hay Flatpak."""
    if not disponible():
        return None
    cols = ["id", "nombre", "version", "tamano", "origen"]
    r = _correr("list", "--app", "--columns=application,name,version,size,origin")
    return interpretar_tabla(r.stdout, cols) if r.returncode == 0 else []


def ids_instalados():
    lista = instaladas()
    return {a["id"] for a in lista} if lista else set()


def actualizaciones():
    """[{'id','version'}] de apps con versión nueva, o None si no hay Flatpak."""
    if not disponible():
        return None
    r = _correr("remote-ls", "--updates", "--app", "--columns=application,version", tiempo=120)
    return interpretar_tabla(r.stdout, ["id", "version"]) if r.returncode == 0 else []


def _validar(app_id):
    if not app_id or not _ID.match(app_id):
        return acciones.fallo("Nombre de app inválido")
    if not disponible():
        return acciones.no_disponible("Las apps se instalan en Kat OS")
    return None


def instalar(app_id):
    error = _validar(app_id)
    if error:
        return error
    r = acciones.ejecutar(["flatpak", "install", "--system", "--noninteractive", "-y", REMOTO, app_id], tiempo=3600)
    return acciones.hecho("instalada") if r.ok else r


def desinstalar(app_id):
    error = _validar(app_id)
    if error:
        return error
    r = acciones.ejecutar(["flatpak", "uninstall", "--system", "--noninteractive", "-y", app_id], tiempo=600)
    return acciones.hecho("desinstalada") if r.ok else r


def actualizar_todo():
    if not disponible():
        return acciones.no_disponible("Las apps se actualizan en Kat OS")
    r = acciones.ejecutar(["flatpak", "update", "--system", "--noninteractive", "-y"], tiempo=3600)
    return acciones.hecho("apps actualizadas") if r.ok else r


def interpretar_permisos(texto):
    """'flatpak info --show-permissions' -> lista de frases entendibles."""
    explicaciones = {
        "network": "Usar internet",
        "x11": "Mostrar ventanas (X11)",
        "wayland": "Mostrar ventanas (Wayland)",
        "pulseaudio": "Reproducir y grabar sonido",
        "ipc": "Comunicarse con otros programas",
        "dri": "Usar la tarjeta gráfica",
        "all": "Acceso a TODOS los dispositivos (cámara, mandos, USB...)",
        "kvm": "Usar virtualización",
        "bluetooth": "Usar Bluetooth",
        "home": "Leer y escribir en tu carpeta personal",
        "host": "Leer y escribir en TODO el equipo",
        "host-os": "Ver los archivos del sistema",
        "xdg-download": "Tu carpeta Descargas",
        "xdg-documents": "Tu carpeta Documentos",
        "xdg-pictures": "Tu carpeta Imágenes",
        "xdg-music": "Tu carpeta Música",
        "xdg-videos": "Tu carpeta Videos",
        "xdg-desktop": "Tu Escritorio",
    }
    frases, seccion = [], ""
    for linea in texto.splitlines():
        linea = linea.strip()
        if linea.startswith("[") and linea.endswith("]"):
            seccion = linea[1:-1]
            continue
        if "=" not in linea or seccion != "Context":
            continue
        clave, valores = linea.split("=", 1)
        for v in filter(None, (x.strip() for x in valores.split(";"))):
            if v.startswith("!"):
                continue
            base = v.split(":")[0]
            texto_v = explicaciones.get(base)
            if texto_v is None and clave == "filesystems":
                texto_v = "Carpeta %s" % base
            if texto_v and texto_v not in frases:
                frases.append(texto_v + (" (solo lectura)" if v.endswith(":ro") else ""))
    return frases


def permisos(app_id):
    if _validar(app_id):
        return None
    r = _correr("info", "--system", "--show-permissions", app_id)
    return interpretar_permisos(r.stdout) if r.returncode == 0 else None


def fuentes():
    """[{'nombre','url'}] de los orígenes de apps configurados, o None."""
    if not disponible():
        return None
    r = _correr("remotes", "--columns=name,url")
    return interpretar_tabla(r.stdout, ["nombre", "url"]) if r.returncode == 0 else []


def abrir(app_id):
    error = _validar(app_id)
    if error:
        return error
    try:
        subprocess.Popen(["flatpak", "run", app_id], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError as e:
        return acciones.fallo("No se pudo abrir: %s" % e)
    return acciones.hecho("abriendo")
