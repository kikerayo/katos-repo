"""KatTest Alerts: alertas de PRUEBA.

Reglas de la lista oficial: las simulaciones se identifican claramente y las
alertas de prueba NUNCA contactan servicios reales. Esta ventana solo se
muestra en pantalla y suena un aviso local: no envía nada a nadie.
"""

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QApplication, QLabel, QPushButton, QVBoxLayout, QWidget

TIPOS = {
    "sismo": ("🌎", "Sismo", "Agáchate, cúbrete y sujétate. Aléjate de ventanas."),
    "huracan": ("🌀", "Huracán", "Quédate en un lugar seguro, lejos de ventanas y zonas que se inunden."),
    "inundacion": ("🌊", "Inundación", "Sube a un lugar alto. No cruces calles con agua."),
    "incendio": ("🔥", "Incendio", "Sal del lugar por la ruta más segura. No uses ascensores."),
}
COLORES = {"rojo": "#b91c1c", "naranja": "#c2410c"}


class AlertaDePrueba(QWidget):
    """Ventana de alerta de prueba, encima de todo, con el aviso de SIMULACIÓN bien visible."""

    def __init__(self, tipo="sismo", nivel="rojo", segundos=30):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        icono, nombre, consejo = TIPOS.get(tipo, TIPOS["sismo"])
        self.color = QColor(COLORES.get(nivel, COLORES["rojo"]))
        self.setWindowTitle("PRUEBA — alerta simulada")
        caja = QVBoxLayout(self)
        caja.setContentsMargins(40, 30, 40, 30)
        aviso = QLabel("⚠  PRUEBA — ESTO ES UNA SIMULACIÓN  ⚠\nNo es una emergencia real y no se avisó a nadie.")
        aviso.setAlignment(Qt.AlignCenter)
        aviso.setStyleSheet("background:#fde047;color:#111;font-size:15pt;font-weight:800;border-radius:10px;"
                            "padding:10px;")
        caja.addWidget(aviso)
        caja.addStretch(1)
        titulo = QLabel("%s  Alerta de %s (prueba)" % (icono, nombre))
        titulo.setAlignment(Qt.AlignCenter)
        titulo.setStyleSheet("color:white;font-size:30pt;font-weight:800;background:transparent;")
        caja.addWidget(titulo)
        texto = QLabel(consejo)
        texto.setAlignment(Qt.AlignCenter)
        texto.setWordWrap(True)
        texto.setStyleSheet("color:white;font-size:16pt;background:transparent;")
        caja.addWidget(texto)
        caja.addStretch(1)
        self.cuenta = QLabel("")
        self.cuenta.setAlignment(Qt.AlignCenter)
        self.cuenta.setStyleSheet("color:#fecaca;font-size:11pt;background:transparent;")
        caja.addWidget(self.cuenta)
        cerrar = QPushButton("Entendido, cerrar la prueba")
        cerrar.setStyleSheet("QPushButton{background:white;color:#111;font-size:14pt;font-weight:700;"
                             "border-radius:12px;padding:12px 30px;}")
        cerrar.clicked.connect(self.close)
        caja.addWidget(cerrar, 0, Qt.AlignCenter)
        self.restante = segundos
        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self._tic)
        self.reloj.start(1000)
        self._tic(primero=True)

    def _tic(self, primero=False):
        if not primero:
            self.restante -= 1
        if self.restante <= 0:
            self.close()
            return
        self.cuenta.setText("Se cierra sola en %d s" % self.restante)
        if self.restante % 5 == 0:
            QApplication.beep()

    def paintEvent(self, _):
        p = QPainter(self)
        p.fillRect(self.rect(), self.color)

    def mostrar(self):
        pantalla = QApplication.primaryScreen().availableGeometry()
        self.setGeometry(pantalla.adjusted(pantalla.width() // 8, pantalla.height() // 8,
                                           -pantalla.width() // 8, -pantalla.height() // 8))
        self.show()
        self.raise_()
        self.activateWindow()
