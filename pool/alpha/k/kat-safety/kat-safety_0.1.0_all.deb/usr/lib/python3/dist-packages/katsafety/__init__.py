"""KatSafety: seguridad de las personas (bloque 3 de la lista oficial).

Versión 0.1 (todo real):
  alertas.py   KatDisaster Alert: sismos cercanos (USGS) y alertas de desastres (GDACS)
  prueba.py    KatTest Alerts: alertas de prueba, marcadas como simulación, sin contactar a nadie
  energia.py   Kat Emergency Power y Kat EcoSafety: modos de ahorro de energía (en Kat OS)
KatCrashDetect y KatSafeWalk necesitan sensores; KatSafe Route, KatFamily y
Katy llegarán después (ver docs/07-estado-funciones.md). No aparecen en la
interfaz hasta que funcionen.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Safety"
