"""KatDisaster Alert: alertas reales y públicas, sin cuenta ni clave.

- Sismos: USGS (Servicio Geológico de EE. UU.), última semana, magnitud 2.5+.
- Desastres: GDACS (Sistema Global de Alertas de Desastres, ONU y Comisión Europea):
  sismos fuertes, ciclones, inundaciones, volcanes, sequías e incendios.
Solo se descargan las listas públicas; la ubicación del usuario no sale del equipo
(el filtro por distancia se calcula aquí).
"""

import datetime
import json
import math
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

USGS = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_week.geojson"
GDACS = "https://www.gdacs.org/xml/rss.xml"
GEO = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=es&name="
NS = {"geo": "http://www.w3.org/2003/01/geo/wgs84_pos#", "gdacs": "http://www.gdacs.org"}

TIPOS = {"EQ": "Sismo", "TC": "Ciclón tropical", "FL": "Inundación", "VO": "Volcán", "DR": "Sequía",
         "WF": "Incendio forestal"}
NIVELES = {"green": "verde", "orange": "naranja", "red": "rojo"}


class SinConexion(RuntimeError):
    pass


class Alerta:
    def __init__(self, tipo, titulo, nivel, distancia_km, fecha, enlace, magnitud=None):
        self.tipo, self.titulo, self.nivel = tipo, titulo, nivel          # nivel: verde/naranja/rojo
        self.distancia_km, self.fecha, self.enlace, self.magnitud = distancia_km, fecha, enlace, magnitud

    def __repr__(self):
        return "Alerta(%s %s %.0f km)" % (self.tipo, self.nivel, self.distancia_km)


def distancia_km(lat1, lon1, lat2, lon2):
    """Distancia en línea recta sobre la Tierra (fórmula del semiverseno)."""
    r = 6371.0
    f1, f2 = math.radians(lat1), math.radians(lat2)
    df, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(df / 2) ** 2 + math.cos(f1) * math.cos(f2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _bajar(url):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "KatOS/0.1"}),
                                    timeout=30) as r:
            return r.read()
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise SinConexion("no pude descargar las alertas; revisa tu internet") from e


def nivel_sismo(magnitud):
    if magnitud >= 6.0:
        return "rojo"
    if magnitud >= 4.5:
        return "naranja"
    return "verde"


def interpretar_usgs(datos, lat, lon, radio_km):
    salida = []
    for f in datos.get("features", []):
        p, g = f.get("properties", {}), f.get("geometry", {})
        try:
            lon2, lat2 = g["coordinates"][0], g["coordinates"][1]
            mag = float(p["mag"])
        except (KeyError, TypeError, IndexError, ValueError):
            continue
        d = distancia_km(lat, lon, lat2, lon2)
        if d > radio_km:
            continue
        fecha = datetime.datetime.fromtimestamp(p.get("time", 0) / 1000)
        lugar = p.get("place") or "lugar desconocido"
        salida.append(Alerta("Sismo", "Sismo de magnitud %.1f — %s" % (mag, lugar), nivel_sismo(mag), d, fecha,
                             p.get("url", ""), mag))
    salida.sort(key=lambda a: a.fecha, reverse=True)
    return salida


def interpretar_gdacs(xml_bytes, lat, lon, radio_km):
    raiz = ET.fromstring(xml_bytes.lstrip(b"\xef\xbb\xbf"))
    salida = []
    for item in raiz.iter("item"):
        try:
            lat2 = float(item.findtext("geo:Point/geo:lat", namespaces=NS))
            lon2 = float(item.findtext("geo:Point/geo:long", namespaces=NS))
        except (TypeError, ValueError):
            continue
        d = distancia_km(lat, lon, lat2, lon2)
        if d > radio_km:
            continue
        if (item.findtext("gdacs:iscurrent", namespaces=NS) or "true").lower() != "true":
            continue
        codigo = item.findtext("gdacs:eventtype", namespaces=NS) or ""
        tipo = TIPOS.get(codigo, codigo or "Desastre")
        nivel = NIVELES.get((item.findtext("gdacs:alertlevel", namespaces=NS) or "").lower(), "verde")
        pais = item.findtext("gdacs:country", namespaces=NS) or "zona sin país"
        gravedad = (item.findtext("gdacs:severity", namespaces=NS) or "").strip()
        if "magnitude 0" in gravedad.lower() or gravedad.lower().startswith("magnitude 0"):
            gravedad = ""                       # GDACS pone "Magnitude 0" en inundaciones: no informa nada
        try:
            fecha = datetime.datetime.strptime(item.findtext("pubDate").strip()[:25], "%a, %d %b %Y %H:%M:%S")
        except (AttributeError, ValueError):
            fecha = datetime.datetime.now()
        titulo = "%s en %s%s" % (tipo, pais, (" (%s)" % gravedad) if gravedad else "")
        salida.append(Alerta(tipo, titulo, nivel, d, fecha, item.findtext("link") or ""))
    orden = {"rojo": 0, "naranja": 1, "verde": 2}
    salida.sort(key=lambda a: (orden[a.nivel], a.distancia_km))
    return salida


def buscar(lat, lon, radio_sismos=500, radio_desastres=2000):
    """Alertas reales cerca de (lat, lon): primero desastres GDACS, luego sismos USGS."""
    sismos = interpretar_usgs(json.loads(_bajar(USGS).decode("utf-8")), lat, lon, radio_sismos)
    desastres = interpretar_gdacs(_bajar(GDACS), lat, lon, radio_desastres)
    return desastres + sismos


def ubicar(ciudad):
    """(nombre, lat, lon) de una ciudad con Open-Meteo, o None si no existe."""
    datos = json.loads(_bajar(GEO + urllib.parse.quote(ciudad)).decode("utf-8"))
    lugares = datos.get("results") or []
    if not lugares:
        return None
    l = lugares[0]
    nombre = l.get("name", ciudad) + (", %s" % l["country"] if l.get("country") else "")
    return nombre, l["latitude"], l["longitude"]
