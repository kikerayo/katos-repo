"""Punto de entrada de KatSafety.  Uso: kat-safety [--prueba sismo|huracan|inundacion|incendio]"""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("KatSafety")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    if "--prueba" in argv:                 # lo usa Kat Developer Center para su demostración
        from .prueba import AlertaDePrueba
        i = argv.index("--prueba")
        tipo = argv[i + 1] if i + 1 < len(argv) else "sismo"
        a = AlertaDePrueba(tipo, "rojo", 20)
        a.mostrar()
        a.destroyed.connect(app.quit)
        a.setAttribute(0x37, True)         # Qt.WA_DeleteOnClose: al cerrar, termina el programa
        return app.exec()
    from .ventana import VentanaSafety
    v = VentanaSafety()
    v.show()
    return app.exec()
