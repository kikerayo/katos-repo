"""Kat Emergency Power y Kat EcoSafety: modos de ahorro de energía (reales en Kat OS).

- Emergencia: perfil "ahorro de energía", tema oscuro (gasta menos en pantallas
  OLED) y brillo al 30 % si el equipo lo permite.
- Eco: perfil "ahorro de energía" y tema oscuro, sin tocar el brillo.
Al desactivarlo vuelve el perfil "equilibrado".
"""

import glob
import os

from katui import acciones, escritorio, plataforma


def bateria():
    """(porcentaje, cargando) de la batería, o None si el equipo no tiene (o no se puede saber)."""
    for carpeta in sorted(glob.glob("/sys/class/power_supply/BAT*")):
        try:
            with open(os.path.join(carpeta, "capacity")) as f:
                pct = int(f.read().strip())
            with open(os.path.join(carpeta, "status")) as f:
                estado = f.read().strip().lower()
            return pct, estado in ("charging", "full")
        except (OSError, ValueError):
            continue
    if plataforma.ES_WINDOWS:
        import ctypes

        class Estado(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_byte), ("BatteryFlag", ctypes.c_byte),
                        ("BatteryLifePercent", ctypes.c_byte), ("SystemStatusFlag", ctypes.c_byte),
                        ("BatteryLifeTime", ctypes.c_ulong), ("BatteryFullLifeTime", ctypes.c_ulong)]
        e = Estado()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(e)) and e.BatteryFlag != -128 \
                and 0 <= e.BatteryLifePercent <= 100:
            return int(e.BatteryLifePercent), e.ACLineStatus == 1
    return None


def _perfil(perfil):
    if not plataforma.tiene("powerprofilesctl"):
        return acciones.no_disponible("Los modos de energía se aplican en Kat OS")
    return acciones.ejecutar(["powerprofilesctl", "set", perfil])


def _brillo(porcentaje):
    if not plataforma.tiene("brightnessctl"):
        return acciones.no_disponible("brillo: este equipo no permite cambiarlo desde aquí")
    return acciones.ejecutar(["brightnessctl", "set", "%d%%" % porcentaje])


def aplicar_modo(modo, activar):
    """modo: 'emergencia' o 'eco'. Devuelve (Resultado general, [(paso, Resultado)])."""
    if modo not in ("emergencia", "eco"):
        return acciones.fallo("modo desconocido"), []
    pasos = []
    if activar:
        pasos.append(("Perfil de ahorro de energía", _perfil("power-saver")))
        pasos.append(("Tema oscuro", escritorio.cambiar_apariencia("oscuro", escritorio.acento_actual() or "violeta")))
        if modo == "emergencia":
            pasos.append(("Brillo al 30 %", _brillo(30)))
    else:
        pasos.append(("Perfil equilibrado", _perfil("balanced")))
        if modo == "emergencia":
            pasos.append(("Brillo al 70 %", _brillo(70)))
    hechos = [r for _, r in pasos if r.ok]
    if not hechos and all(r.estado == acciones.NO_DISPONIBLE for _, r in pasos):
        return acciones.no_disponible("Los modos de energía se aplican en Kat OS"), pasos
    nombre = "Energía de emergencia" if modo == "emergencia" else "Modo eco"
    fallos = [p for p, r in pasos if r.estado == acciones.FALLO]
    if fallos:
        return acciones.fallo("%s: falló %s" % (nombre, ", ".join(fallos))), pasos
    return acciones.hecho("%s %s" % (nombre, "activado" if activar else "desactivado")), pasos
