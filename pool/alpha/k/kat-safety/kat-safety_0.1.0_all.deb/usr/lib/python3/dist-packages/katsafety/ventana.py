"""Ventana de KatSafety: alertas reales, alertas de prueba y modos de energía."""

import json
import os
import webbrowser

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QStackedWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget, QHeaderView,
)

from katui import acciones as res
from katui import plataforma, recursos
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import APP_ID, VERSION, alertas, energia, prueba

COLOR_NIVEL = {"rojo": QColor("#ef4444"), "naranja": QColor("#f59e0b"), "verde": QColor("#22c55e")}


def _icono(nombre):
    ruta = recursos.icono(nombre)
    return QIcon(ruta) if ruta else QIcon()


def _registrar(nivel, mensaje):
    try:
        from katcore.cliente import KatCoreCliente
        kc = KatCoreCliente()
        kc.registrar_app(APP_ID, VERSION)
        kc.evento(APP_ID, nivel, mensaje)
    except Exception:
        pass


# --- ubicación guardada --------------------------------------------------------
def _archivo_ubicacion():
    return os.path.join(plataforma.carpeta_config("safety"), "ubicacion.json")


def leer_ubicacion():
    try:
        with open(_archivo_ubicacion(), encoding="utf-8") as f:
            d = json.load(f)
        return d["nombre"], float(d["lat"]), float(d["lon"])
    except (OSError, ValueError, KeyError):
        return None


def guardar_ubicacion(nombre, lat, lon):
    with open(_archivo_ubicacion(), "w", encoding="utf-8") as f:
        json.dump({"nombre": nombre, "lat": lat, "lon": lon}, f, ensure_ascii=False)


class Pagina(QWidget):
    titulo, icono, descripcion = "", "kat-security", ""

    def __init__(self):
        super().__init__()
        self.caja = QVBoxLayout(self)
        self.caja.setContentsMargins(28, 22, 28, 18)
        self.caja.addWidget(rol(QLabel(self.titulo), "titulo"))
        d = rol(QLabel(self.descripcion), "subtitulo")
        d.setWordWrap(True)
        self.caja.addWidget(d)
        self.caja.addSpacing(8)
        self.resultado = EtiquetaResultado()
        self.construir()
        self.caja.addWidget(self.resultado)

    def construir(self):
        pass

    def cargar(self):
        pass


class PaginaAlertas(Pagina):
    titulo = "KatDisaster Alert"
    descripcion = ("Sismos de la última semana cerca de ti (USGS) y alertas de desastres activas en tu región "
                   "(GDACS, de la ONU y la Comisión Europea). Tu ubicación no sale del equipo: se descargan "
                   "las listas públicas y se filtran aquí.")

    def construir(self):
        fila = QHBoxLayout()
        self.ciudad = QLineEdit()
        self.ciudad.setPlaceholderText("Tu ciudad (p. ej. Tegucigalpa)")
        self.ciudad.returnPressed.connect(self.buscar)
        self.boton = rol(QPushButton("Buscar alertas"), "principal")
        self.boton.clicked.connect(self.buscar)
        fila.addWidget(self.ciudad, 1)
        fila.addWidget(self.boton)
        self.caja.addLayout(fila)
        self.donde = rol(QLabel(""), "subtitulo")
        self.caja.addWidget(self.donde)
        self.tabla = QTreeWidget()
        self.tabla.setHeaderLabels(["Nivel", "Qué pasó", "Distancia", "Cuándo"])
        self.tabla.setRootIsDecorated(False)
        self.tabla.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tabla.itemDoubleClicked.connect(lambda it: it.data(0, Qt.UserRole) and
                                             webbrowser.open(it.data(0, Qt.UserRole)))
        self.caja.addWidget(self.tabla, 1)
        self.caja.addWidget(rol(QLabel("Doble clic en una alerta para ver el informe oficial."), "subtitulo"))

    def cargar(self):
        u = leer_ubicacion()
        if u and not self.ciudad.text():
            self.ciudad.setText(u[0].split(",")[0])
            self.buscar()

    def buscar(self):
        ciudad = self.ciudad.text().strip()
        if not ciudad:
            self.resultado.mostrar(res.fallo("Escribe tu ciudad"))
            return
        self.boton.setEnabled(False)
        self.resultado.trabajando("Descargando alertas públicas…")

        def trabajo():
            try:
                lugar = alertas.ubicar(ciudad)
                if lugar is None:
                    return res.fallo("No encontré la ciudad «%s»" % ciudad)
                return lugar, alertas.buscar(lugar[1], lugar[2])
            except alertas.SinConexion as e:
                return res.fallo(str(e))
        en_segundo_plano(trabajo, al_terminar=self._mostrar)

    def _mostrar(self, datos):
        self.boton.setEnabled(True)
        if isinstance(datos, res.Resultado):
            self.resultado.mostrar(datos)
            return
        (nombre, lat, lon), lista = datos
        guardar_ubicacion(nombre, lat, lon)
        self.donde.setText("Mostrando alertas cerca de %s" % nombre)
        self.tabla.clear()
        for a in lista:
            it = QTreeWidgetItem(["● " + a.nivel, a.titulo, "%.0f km" % a.distancia_km,
                                  a.fecha.strftime("%d/%m %H:%M")])
            it.setForeground(0, COLOR_NIVEL[a.nivel])
            it.setData(0, Qt.UserRole, a.enlace)
            self.tabla.addTopLevelItem(it)
        graves = sum(1 for a in lista if a.nivel == "rojo")
        if not lista:
            self.resultado.mostrar(res.hecho("Sin sismos ni desastres activos cerca de ti. 🟢"))
        else:
            self.resultado.mostrar(res.hecho("%d alerta%s cerca%s" % (len(lista), "" if len(lista) == 1 else "s",
                                                                     " · %d de nivel ROJO" % graves if graves else "")))
        _registrar("warning" if graves else "info", "KatSafety: %d alertas cerca de %s" % (len(lista), nombre))


class PaginaPrueba(Pagina):
    titulo, icono = "KatTest Alerts", "kat-acerca"
    descripcion = ("Practica cómo se ve una alerta. Es una SIMULACIÓN: se ve en tu pantalla, suena un aviso "
                   "y no se envía nada a nadie.")

    def construir(self):
        fila = QHBoxLayout()
        self.tipo = QComboBox()
        for clave, (icono, nombre, _) in prueba.TIPOS.items():
            self.tipo.addItem("%s  %s" % (icono, nombre), clave)
        self.nivel = QComboBox()
        self.nivel.addItem("Nivel rojo", "rojo")
        self.nivel.addItem("Nivel naranja", "naranja")
        lanzar = rol(QPushButton("Mostrar alerta de prueba"), "principal")
        lanzar.clicked.connect(self.lanzar)
        fila.addWidget(self.tipo)
        fila.addWidget(self.nivel)
        fila.addStretch(1)
        fila.addWidget(lanzar)
        self.caja.addLayout(fila)
        self.caja.addStretch(1)
        self.ventana_prueba = None

    def lanzar(self):
        self.ventana_prueba = prueba.AlertaDePrueba(self.tipo.currentData(), self.nivel.currentData())
        self.ventana_prueba.mostrar()
        self.resultado.mostrar(res.hecho("Alerta de prueba mostrada (simulación, no se contactó a nadie)"))
        _registrar("info", "KatTest Alerts: simulación de %s" % self.tipo.currentData())


class PaginaEnergia(Pagina):
    titulo, icono = "Energía de emergencia y Eco", "kat-energia"
    descripcion = "Ahorra batería cuando la necesitas: en una emergencia o para cuidar el planeta."

    def construir(self):
        self.bateria = QLabel("")
        self.bateria.setStyleSheet("font-size:15pt;font-weight:600;")
        self.caja.addWidget(self.bateria)
        for modo, titulo, texto in (
                ("emergencia", "🚨 Kat Emergency Power",
                 "Perfil de ahorro, tema oscuro y brillo al 30 %. Para que la batería dure lo más posible."),
                ("eco", "🌱 Kat EcoSafety", "Perfil de ahorro y tema oscuro: gasta menos energía en el día a día.")):
            t = rol(QFrame(), "tarjeta")
            c = QVBoxLayout(t)
            c.addWidget(QLabel("<b>%s</b>" % titulo))
            d = rol(QLabel(texto), "subtitulo")
            d.setWordWrap(True)
            c.addWidget(d)
            fila = QHBoxLayout()
            on = rol(QPushButton("Activar"), "principal")
            off = QPushButton("Desactivar")
            on.clicked.connect(lambda _=False, m=modo: self._modo(m, True))
            off.clicked.connect(lambda _=False, m=modo: self._modo(m, False))
            fila.addWidget(on)
            fila.addWidget(off)
            fila.addStretch(1)
            c.addLayout(fila)
            self.caja.addWidget(t)
        self.detalle = rol(QLabel(""), "subtitulo")
        self.detalle.setWordWrap(True)
        self.caja.addWidget(self.detalle)
        self.caja.addStretch(1)

    def cargar(self):
        b = energia.bateria()
        if b is None:
            self.bateria.setText("🔌 Este equipo no tiene batería (o no se puede leer)")
        else:
            self.bateria.setText("🔋 Batería: %d %%%s" % (b[0], " · cargando" if b[1] else ""))

    def _modo(self, modo, activar):
        self.resultado.trabajando()

        def fin(r):
            if isinstance(r, res.Resultado):
                self.resultado.mostrar(r)
                return
            general, pasos = r
            self.resultado.mostrar(general)
            simbolo = {res.HECHO: "✔", res.FALLO: "✖", res.NO_DISPONIBLE: "ⓘ"}
            self.detalle.setText("\n".join("%s %s%s" % (simbolo[x.estado], p, (" — " + x.mensaje) if x.mensaje else "")
                                           for p, x in pasos))
            _registrar("info", "KatSafety: %s" % general.mensaje)
        en_segundo_plano(energia.aplicar_modo, modo, activar, al_terminar=fin)


PAGINAS = [PaginaAlertas, PaginaPrueba, PaginaEnergia]


class VentanaSafety(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("KatSafety")
        self.setWindowIcon(_icono("kat-safety"))
        self.resize(1000, 660)
        raiz = QHBoxLayout(self)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)
        lateral = rol(QFrame(), "lateral")
        lateral.setFixedWidth(240)
        lat = QVBoxLayout(lateral)
        lat.setContentsMargins(14, 20, 14, 14)
        marca = QLabel("KatSafety")
        marca.setStyleSheet("font-size:15pt;font-weight:700;color:%s;padding-left:6px;" % COLORES["violeta_claro"])
        lat.addWidget(marca)
        self.lista = QListWidget()
        self.lista.setIconSize(QSize(22, 22))
        lat.addWidget(self.lista, 1)
        if plataforma.VISTA_PREVIA:
            v = rol(QLabel("Vista previa en %s: las alertas son reales; los modos de energía se aplican en Kat OS."
                           % plataforma.nombre()), "aviso")
            v.setWordWrap(True)
            lat.addWidget(v)
        raiz.addWidget(lateral)
        self.pila = QStackedWidget()
        self.paginas = []
        for clase in PAGINAS:
            p = clase()
            self.paginas.append(p)
            self.pila.addWidget(p)
            self.lista.addItem(QListWidgetItem(_icono(p.icono), p.titulo))
        raiz.addWidget(self.pila, 1)
        self.lista.currentRowChanged.connect(self.abrir)
        self.lista.setCurrentRow(0)

    def abrir(self, i):
        if i >= 0:
            self.pila.setCurrentIndex(i)
            self.paginas[i].cargar()
