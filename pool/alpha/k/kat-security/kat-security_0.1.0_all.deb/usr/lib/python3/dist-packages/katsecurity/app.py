"""Punto de entrada de Kat Security."""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaSecurity

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Security")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaSecurity()
    v.show()
    return app.exec()
