"""Ventana de Kat Security: módulos a la izquierda, el elegido a la derecha.

Todo lo que se muestra es real. Lo que aquí no se puede comprobar (p. ej.
en Windows) aparece como "desconocido", nunca como "bien".
"""

from PySide6.QtCore import QProcess, QSize, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QCheckBox, QFrame, QHBoxLayout, QHeaderView, QLabel, QListWidget, QListWidgetItem, QPushButton,
    QScrollArea, QStackedWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import plataforma, recursos, sistema
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import VERSION, comprobaciones as comp, integridad, red, usb

try:
    from katstore import flatpak
except ImportError:  # pragma: no cover
    flatpak = None

COLOR = {comp.BIEN: COLORES["ok"], comp.AVISO: COLORES["aviso"], comp.MAL: COLORES["error"],
         comp.DESCONOCIDO: COLORES["texto_suave"]}
SIMBOLO = {comp.BIEN: "✔", comp.AVISO: "!", comp.MAL: "✖", comp.DESCONOCIDO: "?"}


def _icono(nombre):
    ruta = recursos.icono(nombre)
    return QIcon(ruta) if ruta else QIcon.fromTheme("security-high")


def _arbol(columnas):
    t = QTreeWidget()
    t.setHeaderLabels(columnas)
    t.setRootIsDecorated(False)
    t.header().setSectionResizeMode(len(columnas) - 1, QHeaderView.Stretch)
    return t


class Pagina(QWidget):
    titulo = ""
    descripcion = ""
    icono = "kat-security"

    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        exterior = QVBoxLayout(self)
        exterior.setContentsMargins(0, 0, 0, 0)
        area = QScrollArea()
        area.setWidgetResizable(True)
        interior = QWidget()
        self.caja = QVBoxLayout(interior)
        self.caja.setContentsMargins(28, 22, 28, 18)
        self.caja.addWidget(rol(QLabel(self.titulo), "titulo"))
        d = rol(QLabel(self.descripcion), "subtitulo")
        d.setWordWrap(True)
        self.caja.addWidget(d)
        self.caja.addSpacing(8)
        self.resultado = EtiquetaResultado()
        self.construir()
        self.caja.addWidget(self.resultado)
        self.caja.addStretch(1)
        area.setWidget(interior)
        exterior.addWidget(area)

    def construir(self):
        pass

    def cargar(self):
        pass


class PaginaPanel(Pagina):
    titulo = "KatSecure"
    descripcion = "Revisión de la seguridad de tu equipo con datos reales."

    def construir(self):
        fila = QHBoxLayout()
        self.nota = QLabel("–")
        self.nota.setFixedSize(130, 130)
        self.nota.setAlignment(Qt.AlignCenter)
        fila.addWidget(self.nota)
        self.resumen = rol(QLabel(""), "subtitulo")
        self.resumen.setWordWrap(True)
        fila.addWidget(self.resumen, 1)
        revisar = rol(QPushButton("Revisar de nuevo"), "principal")
        revisar.clicked.connect(self.cargar)
        fila.addWidget(revisar, 0, Qt.AlignTop)
        self.caja.addLayout(fila)
        self.lista = QVBoxLayout()
        self.caja.addLayout(self.lista)

    def cargar(self):
        self.resultado.trabajando("Revisando…")
        en_segundo_plano(comp.revisar, al_terminar=self._mostrar)

    def _mostrar(self, lista):
        if isinstance(lista, res.Resultado):
            self.resultado.mostrar(lista)
            return
        self.resultado.mostrar(None)
        while self.lista.count():
            w = self.lista.takeAt(0).widget()
            if w:
                w.deleteLater()
        for c in lista:
            t = rol(QFrame(), "tarjeta")
            f = QHBoxLayout(t)
            s = QLabel(SIMBOLO[c.estado])
            s.setFixedWidth(28)
            s.setStyleSheet("color:%s;font-size:16pt;font-weight:700;" % COLOR[c.estado])
            f.addWidget(s)
            texto = QLabel("<b>%s</b> <span style='color:%s'>· %s</span><br>%s"
                           % (c.nombre, COLORES["texto_suave"], c.modulo, c.detalle))
            texto.setWordWrap(True)
            f.addWidget(texto, 1)
            self.lista.addWidget(t)
        n = comp.nota(lista)
        if n is None:
            self.nota.setText("?")
            color = COLORES["texto_suave"]
            self.resumen.setText("Aquí no se puede revisar la seguridad: se hace en Kat OS (%s)." % plataforma.nombre())
        else:
            color = COLORES["ok"] if n >= 80 else (COLORES["aviso"] if n >= 50 else COLORES["error"])
            self.nota.setText("%d" % n)
            malas = [c for c in lista if c.estado in (comp.MAL, comp.AVISO)]
            self.resumen.setText("Nota de seguridad sobre 100.\n" +
                                 ("Todo en orden." if not malas else "Revisa: " + ", ".join(c.nombre for c in malas)))
        self.nota.setStyleSheet("font-size:40pt;font-weight:800;color:%s;border:6px solid %s;border-radius:65px;"
                                % (color, color))
        self.ventana.registrar("info", "KatSecure: nota %s" % n)


class PaginaRed(Pagina):
    titulo, icono = "KatNet Shield", "kat-red"
    descripcion = "Cortafuegos y programas que esperan conexiones desde otros equipos."

    def construir(self):
        self.firewall = QCheckBox("Cortafuegos activado (te pedirá tu contraseña para cambiarlo)")
        self.firewall.clicked.connect(self._firewall)
        self.caja.addWidget(self.firewall)
        self.caja.addSpacing(8)
        self.caja.addWidget(QLabel("<b>Puertos abiertos</b>"))
        self.tabla = _arbol(["Puerto", "Protocolo", "Alcance", "Programa", "Qué es"])
        self.tabla.setMinimumHeight(260)
        self.caja.addWidget(self.tabla)

    def cargar(self):
        fw = sistema.firewall_activo()
        self.firewall.setChecked(bool(fw))
        self.firewall.setEnabled(fw is not None)
        self.tabla.clear()
        lista = red.puertos()
        if lista is None:
            self.resultado.mostrar(res.no_disponible("La red se revisa en Kat OS"))
            return
        expuestos = 0
        for p in lista:
            alcance = "Toda la red" if p.expuesto else "Solo este equipo"
            expuestos += p.expuesto
            it = QTreeWidgetItem([str(p.numero), p.protocolo.upper(), alcance, p.proceso or "—", p.descripcion])
            if p.expuesto:
                it.setForeground(2, Qt.GlobalColor.yellow)
            self.tabla.addTopLevelItem(it)
        self.resultado.mostrar(res.hecho("%d puerto%s abierto%s a la red%s" % (
            expuestos, "" if expuestos == 1 else "s", "" if expuestos == 1 else "s",
            " (el cortafuegos los protege)" if expuestos and sistema.firewall_activo() else "")))

    def _firewall(self, si):
        self.resultado.trabajando()
        en_segundo_plano(sistema.cambiar_firewall, si,
                         al_terminar=lambda r: (self.resultado.mostrar(r), self.cargar()))


class PaginaActualizaciones(Pagina):
    titulo, icono = "KatUpdates", "kat-update"
    descripcion = "Parches de seguridad y actualizaciones automáticas."

    def construir(self):
        self.estado = QLabel("")
        self.estado.setWordWrap(True)
        self.estado.setStyleSheet("font-size:13pt;")
        self.caja.addWidget(self.estado)
        self.auto = QCheckBox("Instalar las actualizaciones de seguridad automáticamente")
        self.auto.clicked.connect(lambda si: en_segundo_plano(
            sistema.cambiar_actualizaciones, si, al_terminar=lambda r: (self.resultado.mostrar(r), self.cargar())))
        self.caja.addWidget(self.auto)
        abrir = rol(QPushButton("Abrir Kat Update Center"), "principal")
        abrir.clicked.connect(self._abrir)
        self.caja.addWidget(abrir, 0, Qt.AlignLeft)

    def cargar(self):
        au = sistema.actualizaciones_automaticas()
        self.auto.setChecked(bool(au))
        c = comp.actualizaciones_seguridad()
        self.estado.setText("%s  %s" % (SIMBOLO[c.estado], c.detalle))
        self.estado.setStyleSheet("font-size:13pt;color:%s;" % COLOR[c.estado])

    def _abrir(self):
        ok = QProcess.startDetached("kat-update", []) if plataforma.tiene("kat-update") else False
        ok = ok[0] if isinstance(ok, tuple) else ok
        self.resultado.mostrar(res.hecho("Abriendo Kat Update Center") if ok else
                               res.no_disponible("Kat Update Center está en Kat OS"))


class PaginaIntegridad(Pagina):
    titulo, icono = "KatSystem Integrity", "kat-acerca"
    descripcion = ("Compara cada archivo de programa del sistema con su huella original para saber si "
                   "alguien lo modificó. Tarda unos minutos.")

    def construir(self):
        self.boton = rol(QPushButton("Revisar ahora"), "principal")
        self.boton.clicked.connect(self._revisar)
        self.caja.addWidget(self.boton, 0, Qt.AlignLeft)
        self.tabla = _arbol(["Archivo", "Qué cambió"])
        self.tabla.setMinimumHeight(260)
        self.caja.addWidget(self.tabla)

    def _revisar(self):
        self.boton.setEnabled(False)
        self.tabla.clear()
        self.resultado.trabajando("Revisando todos los archivos del sistema… puede tardar unos minutos")
        en_segundo_plano(integridad.revisar, al_terminar=self._fin)

    def _fin(self, cambios):
        self.boton.setEnabled(True)
        if isinstance(cambios, res.Resultado):
            self.resultado.mostrar(cambios)
            return
        if cambios is None:
            self.resultado.mostrar(res.no_disponible("La integridad se revisa en Kat OS"))
            return
        programas = [c for c in cambios if not c.configuracion]
        config = len(cambios) - len(programas)
        for c in programas:
            self.tabla.addTopLevelItem(QTreeWidgetItem([c.ruta, c.motivo]))
        texto = ("%d archivo%s de programa modificado%s" % (len(programas), "" if len(programas) == 1 else "s",
                                                             "" if len(programas) == 1 else "s")
                 if programas else "Ningún archivo de programa fue modificado")
        if config:
            texto += " · %d de configuración cambiados (normal: los ajustas tú o Kat OS)" % config
        self.resultado.mostrar(res.hecho(texto) if not programas else res.fallo(texto))
        self.ventana.registrar("warning" if programas else "info", "Integridad: " + texto)


class PaginaUSB(Pagina):
    titulo, icono = "KatUSB Guard", "kat-almacenamiento"
    descripcion = "Dispositivos USB conectados ahora. (Bloquear o permitir dispositivos llegará en una próxima versión.)"

    def construir(self):
        actualizar = QPushButton("Actualizar")
        actualizar.clicked.connect(self.cargar)
        self.caja.addWidget(actualizar, 0, Qt.AlignLeft)
        self.tabla = _arbol(["Dispositivo", "Fabricante", "Tipo", "ID"])
        self.tabla.setMinimumHeight(240)
        self.caja.addWidget(self.tabla)

    def cargar(self):
        self.tabla.clear()
        lista = usb.dispositivos()
        if lista is None:
            self.resultado.mostrar(res.no_disponible("Los USB se revisan en Kat OS"))
            return
        for d in lista:
            self.tabla.addTopLevelItem(QTreeWidgetItem([d.producto, d.fabricante or "—", d.tipo,
                                                        "%s:%s" % (d.vendedor, d.modelo)]))
        self.resultado.mostrar(res.hecho("%d dispositivo%s USB" % (len(lista), "" if len(lista) == 1 else "s")))


class PaginaPermisos(Pagina):
    titulo, icono = "KatPermission Watch", "kat-store"
    descripcion = "Qué puede hacer cada app que instalaste desde Kat Store."

    def construir(self):
        self.tabla = QTreeWidget()
        self.tabla.setHeaderLabels(["App", "Permisos"])
        self.tabla.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.tabla.setMinimumHeight(300)
        self.caja.addWidget(self.tabla)

    def cargar(self):
        self.tabla.clear()
        if flatpak is None or not flatpak.disponible():
            self.resultado.mostrar(res.no_disponible("Los permisos de apps se revisan en Kat OS"))
            return
        self.resultado.trabajando("Leyendo permisos…")

        def leer():
            return [(a, flatpak.permisos(a["id"]) or []) for a in (flatpak.instaladas() or [])]

        def fin(datos):
            if isinstance(datos, res.Resultado):
                self.resultado.mostrar(datos)
                return
            delicadas = 0
            for a, permisos in datos:
                padre = QTreeWidgetItem([a["nombre"], "%d permiso%s" % (len(permisos), "" if len(permisos) == 1 else "s")])
                for p in permisos:
                    hijo = QTreeWidgetItem(["", p])
                    if "TODO" in p:
                        hijo.setForeground(1, Qt.GlobalColor.yellow)
                        delicadas += 1
                    padre.addChild(hijo)
                self.tabla.addTopLevelItem(padre)
            self.resultado.mostrar(res.hecho("%d apps · %d permiso%s delicado%s" % (
                len(datos), delicadas, "" if delicadas == 1 else "s", "" if delicadas == 1 else "s")))
        en_segundo_plano(leer, al_terminar=fin)


class PaginaPrivacidad(Pagina):
    titulo, icono = "KatPrivacy", "kat-cuenta"
    descripcion = "Qué datos salen de tu equipo."

    def construir(self):
        self.texto = QLabel("")
        self.texto.setWordWrap(True)
        self.texto.setTextFormat(Qt.RichText)
        self.caja.addWidget(self.texto)

    def cargar(self):
        c = comp.privacidad()
        self.texto.setText(
            "<p style='color:%s;font-size:13pt'>%s %s</p>"
            "<p><b>Lo que sí se conecta a internet, y solo cuando tú lo usas:</b></p>"
            "<ul><li>Kat Store y Kat Bienvenida: catálogo de Flathub (lo que buscas).</li>"
            "<li>Kat Update Center: servidores de Debian y Flathub para descargar actualizaciones.</li>"
            "<li>Kat (asistente): el clima usa Open-Meteo (solo la ciudad que preguntas). "
            "<b>Kat Cloud AI</b> es opcional y viene apagado: si lo activas con tu clave de Groq, "
            "se envían a Groq solo las preguntas que Kat no sabe responder sola.</li></ul>"
            "<p>Kat OS no tiene cuentas obligatorias, publicidad ni telemetría.</p>"
            % (COLOR[c.estado], SIMBOLO[c.estado], c.detalle))


PAGINAS = [PaginaPanel, PaginaRed, PaginaActualizaciones, PaginaIntegridad, PaginaUSB, PaginaPermisos,
           PaginaPrivacidad]


class VentanaSecurity(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kat Security")
        self.setWindowIcon(_icono("kat-security"))
        self.resize(1040, 700)
        raiz = QHBoxLayout(self)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)
        lateral = rol(QFrame(), "lateral")
        lateral.setFixedWidth(240)
        lat = QVBoxLayout(lateral)
        lat.setContentsMargins(14, 20, 14, 14)
        marca = QLabel("Kat Security")
        marca.setStyleSheet("font-size:15pt;font-weight:700;color:%s;padding-left:6px;" % COLORES["violeta_claro"])
        lat.addWidget(marca)
        self.lista = QListWidget()
        self.lista.setIconSize(QSize(22, 22))
        lat.addWidget(self.lista, 1)
        bloquear = rol(QPushButton("🔒  Bloquear ahora (KatLock)"), "principal")
        bloquear.clicked.connect(self.bloquear)
        lat.addWidget(bloquear)
        self.estado = EtiquetaResultado()
        lat.addWidget(self.estado)
        if plataforma.VISTA_PREVIA:
            v = rol(QLabel("Vista previa en %s" % plataforma.nombre()), "aviso")
            v.setWordWrap(True)
            lat.addWidget(v)
        raiz.addWidget(lateral)
        self.pila = QStackedWidget()
        self.paginas = []
        for clase in PAGINAS:
            p = clase(self)
            self.paginas.append(p)
            self.pila.addWidget(p)
            item = QListWidgetItem(_icono(p.icono), p.titulo)
            self.lista.addItem(item)
        raiz.addWidget(self.pila, 1)
        self.lista.currentRowChanged.connect(self.abrir)
        self.lista.setCurrentRow(0)

    def abrir(self, i):
        if i >= 0:
            self.pila.setCurrentIndex(i)
            self.paginas[i].resultado.mostrar(None)
            self.paginas[i].cargar()

    def bloquear(self):
        if not plataforma.ES_LINUX:
            self.estado.mostrar(res.no_disponible("KatLock bloquea la pantalla en Kat OS"))
            return
        self.estado.mostrar(res.ejecutar(["loginctl", "lock-session"], exito="Pantalla bloqueada"))

    def registrar(self, nivel, mensaje):
        try:
            from katcore.cliente import KatCoreCliente
            from . import APP_ID
            kc = KatCoreCliente()
            kc.registrar_app(APP_ID, VERSION)
            kc.evento(APP_ID, nivel, mensaje)
        except Exception:
            pass
