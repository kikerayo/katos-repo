"""KatSystem Integrity: ¿algún archivo de programa del sistema fue modificado?

Usa 'dpkg --verify', que compara cada archivo instalado con la huella (MD5)
que trae su paquete. No necesita permisos de administrador.
- Archivos de configuración (/etc) que se cambian a propósito: se cuentan aparte.
- Archivos que Kat OS aparta con dpkg-divert: no son un problema.
"""

import subprocess

from katui import plataforma


class Cambio:
    def __init__(self, ruta, motivo, configuracion):
        self.ruta, self.motivo, self.configuracion = ruta, motivo, configuracion

    def __repr__(self):
        return "Cambio(%s, %s)" % (self.ruta, self.motivo)


def interpretar(texto, apartados=()):
    """Salida de 'dpkg --verify' -> [Cambio] (sin los archivos apartados por Kat)."""
    salida = []
    apartados = set(apartados)
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        if linea.startswith("missing"):
            partes = linea.split()
            ruta = partes[-1]
            motivo, conf = "falta", len(partes) == 3 and partes[1] == "c"
        else:
            marcas, resto = linea[:9], linea[9:]
            conf = resto[:2].strip() == "c"
            ruta = resto[2:].strip() if resto[:2].strip() else resto.strip()
            motivo = "contenido cambiado" if "5" in marcas else "permisos o dueño cambiados"
        if ruta in apartados:
            continue
        salida.append(Cambio(ruta, motivo, conf))
    return salida


def apartados_por_kat():
    """Rutas que Kat OS apartó con dpkg-divert (os-release, autostart...)."""
    try:
        r = subprocess.run(["dpkg-divert", "--list"], capture_output=True, text=True, timeout=30)
    except OSError:
        return set()
    rutas = set()
    for linea in r.stdout.splitlines():
        # "local diversion of /usr/lib/os-release to /usr/lib/os-release.debian"
        partes = linea.split()
        if "of" in partes and "to" in partes:
            rutas.add(partes[partes.index("of") + 1])
    return rutas


def revisar():
    """[Cambio] o None si aquí no se puede revisar. Puede tardar unos minutos."""
    if not (plataforma.ES_LINUX and plataforma.tiene("dpkg")):
        return None
    r = subprocess.run(["dpkg", "--verify"], capture_output=True, text=True, timeout=1800,
                       encoding="utf-8", errors="replace")
    # dpkg --verify termina con 1 si encontró diferencias: no es un error.
    if r.returncode not in (0, 1):
        return None
    return interpretar(r.stdout, apartados_por_kat())
