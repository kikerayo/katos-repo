"""KatSecure: comprobaciones de seguridad con datos reales del equipo.

Cada comprobación devuelve una Comprobacion con estado:
  BIEN, AVISO, MAL o DESCONOCIDO (no se pudo saber aquí, p. ej. en Windows).
La nota (0-100) solo cuenta las que se pudieron comprobar.
"""

import glob
import json
import os
import subprocess

from katui import plataforma, sistema

BIEN, AVISO, MAL, DESCONOCIDO = "bien", "aviso", "mal", "desconocido"
PESO = {BIEN: 1.0, AVISO: 0.5, MAL: 0.0}


class Comprobacion:
    def __init__(self, clave, nombre, estado, detalle, modulo):
        self.clave, self.nombre, self.estado, self.detalle, self.modulo = clave, nombre, estado, detalle, modulo

    def __repr__(self):
        return "Comprobacion(%s=%s)" % (self.clave, self.estado)


def _correr(cmd, tiempo=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=tiempo, encoding="utf-8", errors="replace")
        return r.returncode, r.stdout
    except (OSError, subprocess.TimeoutExpired):
        return None, ""


def firewall():
    activo = sistema.firewall_activo()
    if activo is None:
        return Comprobacion("firewall", "Cortafuegos", DESCONOCIDO, "Solo se comprueba en Kat OS", "KatNet Shield")
    if activo:
        return Comprobacion("firewall", "Cortafuegos", BIEN, "Activado: bloquea conexiones que no pediste",
                            "KatNet Shield")
    return Comprobacion("firewall", "Cortafuegos", MAL, "Desactivado: actívalo en KatNet Shield", "KatNet Shield")


def actualizaciones_automaticas():
    activo = sistema.actualizaciones_automaticas()
    if activo is None:
        if plataforma.ES_LINUX:
            return Comprobacion("auto", "Actualizaciones automáticas", AVISO, "No están configuradas", "KatUpdates")
        return Comprobacion("auto", "Actualizaciones automáticas", DESCONOCIDO, "Solo se comprueba en Kat OS",
                            "KatUpdates")
    if activo:
        return Comprobacion("auto", "Actualizaciones automáticas", BIEN, "Las de seguridad se instalan solas",
                            "KatUpdates")
    return Comprobacion("auto", "Actualizaciones automáticas", AVISO, "Desactivadas: tendrás que actualizar a mano",
                        "KatUpdates")


def actualizaciones_seguridad(pendientes=None):
    """'pendientes' es la lista de katupdate.sistema.pendientes() (o None para leerla aquí)."""
    if pendientes is None:
        try:
            from katupdate import sistema as upd
            pendientes = upd.pendientes()
        except ImportError:
            pendientes = None
    if pendientes is None:
        return Comprobacion("parches", "Parches de seguridad", DESCONOCIDO, "Solo se comprueba en Kat OS", "KatUpdates")
    n = sum(1 for p in pendientes if p.seguridad)
    if n == 0:
        return Comprobacion("parches", "Parches de seguridad", BIEN, "No falta ninguno", "KatUpdates")
    return Comprobacion("parches", "Parches de seguridad", MAL if n >= 5 else AVISO,
                        "Faltan %d: instálalos en Kat Update Center" % n, "KatUpdates")


def interpretar_lsblk(texto):
    """¿La raíz '/' está sobre un disco cifrado (LUKS)? True/False."""
    def buscar(nodos, cifrado):
        for n in nodos:
            dentro = cifrado or n.get("type") == "crypt"
            puntos = n.get("mountpoints") or [n.get("mountpoint")]
            if "/" in puntos:
                return dentro
            hijo = buscar(n.get("children") or [], dentro)
            if hijo is not None:
                return hijo
        return None
    return bool(buscar(json.loads(texto).get("blockdevices", []), False))


def cifrado_disco():
    if not plataforma.ES_LINUX or not plataforma.tiene("lsblk"):
        return Comprobacion("cifrado", "Cifrado del disco", DESCONOCIDO, "Solo se comprueba en Kat OS", "KatVault")
    if sistema.en_modo_live():
        return Comprobacion("cifrado", "Cifrado del disco", DESCONOCIDO,
                            "En modo live no hay disco instalado", "KatVault")
    codigo, salida = _correr(["lsblk", "-J", "-o", "NAME,TYPE,MOUNTPOINTS"])
    if codigo != 0:
        return Comprobacion("cifrado", "Cifrado del disco", DESCONOCIDO, "No se pudo leer", "KatVault")
    if interpretar_lsblk(salida):
        return Comprobacion("cifrado", "Cifrado del disco", BIEN, "El sistema está cifrado (LUKS)", "KatVault")
    return Comprobacion("cifrado", "Cifrado del disco", AVISO,
                        "Sin cifrar: si te roban el equipo pueden leer tus archivos. Se elige al instalar.",
                        "KatVault")


def arranque_seguro():
    if not plataforma.ES_LINUX:
        return Comprobacion("secureboot", "Arranque seguro", DESCONOCIDO, "Solo se comprueba en Kat OS", "KatBoot")
    if not os.path.isdir("/sys/firmware/efi"):
        return Comprobacion("secureboot", "Arranque seguro", AVISO, "El equipo arranca en modo BIOS antiguo", "KatBoot")
    variables = glob.glob("/sys/firmware/efi/efivars/SecureBoot-*")
    if not variables:
        return Comprobacion("secureboot", "Arranque seguro", DESCONOCIDO, "No se pudo leer", "KatBoot")
    try:
        with open(variables[0], "rb") as f:
            valor = f.read()[-1]
    except OSError:
        return Comprobacion("secureboot", "Arranque seguro", DESCONOCIDO, "No se pudo leer", "KatBoot")
    if valor == 1:
        return Comprobacion("secureboot", "Arranque seguro", BIEN, "Secure Boot activado", "KatBoot")
    return Comprobacion("secureboot", "Arranque seguro", AVISO, "Secure Boot desactivado", "KatBoot")


def bloqueo_pantalla(texto=None):
    """Lee ~/.config/kscreenlockerrc (por defecto Plasma bloquea a los 5 min)."""
    if not plataforma.ES_LINUX:
        return Comprobacion("bloqueo", "Bloqueo de pantalla", DESCONOCIDO, "Solo se comprueba en Kat OS", "KatLock")
    if texto is None:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
        try:
            with open(os.path.join(base, "kscreenlockerrc"), encoding="utf-8") as f:
                texto = f.read()
        except OSError:
            texto = ""
    if "Autolock=false" in texto.replace(" ", ""):
        return Comprobacion("bloqueo", "Bloqueo de pantalla", MAL, "La pantalla no se bloquea sola", "KatLock")
    return Comprobacion("bloqueo", "Bloqueo de pantalla", BIEN, "Se bloquea sola al dejar el equipo", "KatLock")


def privacidad():
    if not plataforma.ES_LINUX:
        return Comprobacion("privacidad", "Informes a terceros", DESCONOCIDO, "Solo se comprueba en Kat OS",
                            "KatPrivacy")
    enviador = "/etc/systemd/user/drkonqi-sentry-postman.timer"
    if os.path.islink(enviador) and os.readlink(enviador) == "/dev/null":
        return Comprobacion("privacidad", "Informes a terceros", BIEN, "Kat OS no envía informes de fallos ni datos",
                            "KatPrivacy")
    if not os.path.exists("/usr/lib/systemd/user/drkonqi-sentry-postman.timer"):
        return Comprobacion("privacidad", "Informes a terceros", BIEN, "No hay nada que envíe datos", "KatPrivacy")
    return Comprobacion("privacidad", "Informes a terceros", AVISO, "El envío de informes de fallos de KDE está activo",
                        "KatPrivacy")


TODAS = [firewall, actualizaciones_automaticas, actualizaciones_seguridad, cifrado_disco, arranque_seguro,
         bloqueo_pantalla, privacidad]


def revisar():
    return [f() for f in TODAS]


def nota(comprobaciones):
    """Nota 0-100 con las comprobaciones que se pudieron hacer, o None si ninguna."""
    validas = [c for c in comprobaciones if c.estado in PESO]
    if not validas:
        return None
    return round(100 * sum(PESO[c.estado] for c in validas) / len(validas))
