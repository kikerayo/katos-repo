"""KatNet Shield: qué programas esperan conexiones desde la red (puertos abiertos), con 'ss'."""

import re
import subprocess

from katui import plataforma

CONOCIDOS = {22: "SSH (acceso remoto)", 53: "DNS (nombres de internet)", 67: "DHCP", 68: "DHCP (dirección de red)",
             80: "Servidor web", 443: "Servidor web seguro", 631: "Impresoras (CUPS)", 1716: "KDE Connect",
             5353: "Descubrir equipos en la red local (mDNS)", 3389: "Escritorio remoto", 5900: "VNC (pantalla remota)"}


class Puerto:
    def __init__(self, protocolo, direccion, numero, proceso):
        self.protocolo, self.direccion, self.numero, self.proceso = protocolo, direccion, numero, proceso

    @property
    def expuesto(self):
        """True si se puede conectar desde otros equipos (no solo desde este)."""
        d = self.direccion.strip("[]").split("%")[0]
        return not (d.startswith("127.") or d == "::1" or d == "localhost")

    @property
    def descripcion(self):
        return CONOCIDOS.get(self.numero, "")

    def __repr__(self):
        return "Puerto(%s %s:%d)" % (self.protocolo, self.direccion, self.numero)


def interpretar(texto):
    """Salida de 'ss -tulnpH' -> [Puerto] sin repetir (IPv4/IPv6 del mismo programa cuentan una vez)."""
    vistos, salida = set(), []
    for linea in texto.splitlines():
        partes = linea.split()
        if len(partes) < 5:
            continue
        protocolo = partes[0]
        local = partes[4]
        direccion, _, puerto = local.rpartition(":")
        if not puerto.isdigit():
            continue
        m = re.search(r'users:\(\("([^"]+)"', linea)
        proceso = m.group(1) if m else ""
        p = Puerto(protocolo, direccion, int(puerto), proceso)
        clave = (protocolo, p.numero, p.expuesto, proceso)
        if clave in vistos:
            continue
        vistos.add(clave)
        salida.append(p)
    salida.sort(key=lambda p: (not p.expuesto, p.numero))
    return salida


def puertos():
    """[Puerto] o None si aquí no se puede saber."""
    if not (plataforma.ES_LINUX and plataforma.tiene("ss")):
        return None
    r = subprocess.run(["ss", "-tulnpH"], capture_output=True, text=True, timeout=15)
    return interpretar(r.stdout) if r.returncode == 0 else None
