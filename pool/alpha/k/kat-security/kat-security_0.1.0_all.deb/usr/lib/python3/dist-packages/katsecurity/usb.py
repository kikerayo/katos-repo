"""KatUSB Guard (versión 0.1): ver qué dispositivos USB hay conectados.

Se lee /sys/bus/usb/devices (no hace falta ningún permiso). Bloquear o
permitir dispositivos llegará en una versión posterior.
"""

import os

from katui import plataforma

SYS = "/sys/bus/usb/devices"
CLASES = {"01": "Audio", "02": "Comunicaciones", "03": "Teclado / ratón / mando", "06": "Cámara de fotos",
          "07": "Impresora", "08": "Memoria USB / disco", "09": "Concentrador USB", "0a": "Datos",
          "0b": "Lector de tarjetas", "0e": "Cámara web", "e0": "Bluetooth / inalámbrico", "ef": "Varios",
          "ff": "Dispositivo del fabricante"}


class Dispositivo:
    def __init__(self, ruta, fabricante, producto, vendedor, modelo, clase):
        self.ruta, self.fabricante, self.producto = ruta, fabricante, producto
        self.vendedor, self.modelo, self.clase = vendedor, modelo, clase

    @property
    def tipo(self):
        return CLASES.get(self.clase, "Otro")

    def __repr__(self):
        return "Dispositivo(%s %s:%s)" % (self.producto, self.vendedor, self.modelo)


def _leer(carpeta, archivo):
    try:
        with open(os.path.join(carpeta, archivo), encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def _clase(carpeta):
    clase = _leer(carpeta, "bDeviceClass")
    if clase in ("", "00"):                 # la clase está en la primera interfaz
        nombre = os.path.basename(carpeta)
        clase = _leer(os.path.join(carpeta, "%s:1.0" % nombre), "bInterfaceClass") or clase
    return clase.lower()


def dispositivos(base=SYS):
    """[Dispositivo] conectados (sin los concentradores internos), o None si aquí no se puede saber."""
    if not plataforma.ES_LINUX or not os.path.isdir(base):
        return None
    salida = []
    for nombre in sorted(os.listdir(base)):
        carpeta = os.path.join(base, nombre)
        if ":" in nombre or nombre.startswith("usb") or not os.path.exists(os.path.join(carpeta, "idVendor")):
            continue
        d = Dispositivo(nombre, _leer(carpeta, "manufacturer"), _leer(carpeta, "product") or "Dispositivo USB",
                        _leer(carpeta, "idVendor"), _leer(carpeta, "idProduct"), _clase(carpeta))
        if d.clase == "09":
            continue
        salida.append(d)
    return salida
