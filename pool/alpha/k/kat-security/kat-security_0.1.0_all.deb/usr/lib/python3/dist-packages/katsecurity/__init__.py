"""Kat Security (KatSecure): centro de seguridad de Kat OS.

Módulos de la versión 0.1 (todos con datos reales):
  comprobaciones.py  KatSecure: nota de seguridad a partir de comprobaciones reales
  red.py             KatNet Shield: puertos abiertos a la red
  usb.py             KatUSB Guard: dispositivos USB conectados (solo ver, por ahora)
  integridad.py      KatSystem Integrity: archivos del sistema modificados (dpkg --verify)
El resto de módulos de la lista oficial (KatVault, KatBoot, NightGuard,
KatAntiTheft, KatDecoy, KatPanic, KatGuard) se harán más adelante y no
aparecen en la interfaz hasta que funcionen.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Security"
