"""Ventana de Kat Bienvenida (PySide6).

Las páginas solo recogen lo que eliges; al final la página "Aplicando"
ejecuta cada acción de verdad (en un hilo aparte) y muestra el resultado
real de cada una: hecho, falló (con el motivo) o "solo en Kat OS".
"""

import os

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, QSize, Qt, QThread, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QFileDialog, QFrame, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit,
    QListView, QListWidget, QListWidgetItem, QProgressBar, QPushButton, QRadioButton, QScrollArea,
    QStackedWidget, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import musica, pin, plataforma, recursos, sistema
from katui.estilo import COLORES, rol

from . import VERSION, acciones, catalogo


class Eleccion:
    """Lo que el usuario eligió en cada página."""

    def __init__(self):
        self.nombre = acciones.nombre_actual()
        self.foto = None
        self.modo = "oscuro"
        self.acento = "violeta"
        self.estilo = "windows"
        self.fondo = None
        self.firewall = True
        self.actualizaciones = True
        self.pin = None
        self.rostro = False
        self.telefono = False
        self.apps = []


def _titulo(texto, sub=""):
    caja = QVBoxLayout()
    caja.addWidget(rol(QLabel(texto), "titulo"))
    if sub:
        s = rol(QLabel(sub), "subtitulo")
        s.setWordWrap(True)
        caja.addWidget(s)
    caja.addSpacing(10)
    return caja


class Pagina(QWidget):
    titulo_lateral = ""

    def guardar(self, eleccion):
        pass

    def valida(self):
        return True, ""


# --- páginas -----------------------------------------------------------------
class PaginaHola(Pagina):
    titulo_lateral = "Bienvenida"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addStretch(1)
        logo = QLabel()
        ruta = recursos.icono("kat-bienvenida")
        if ruta:
            logo.setPixmap(QIcon(ruta).pixmap(QSize(120, 120)))
        logo.setAlignment(Qt.AlignCenter)
        caja.addWidget(logo)
        t = rol(QLabel("¡Hola! Te damos la bienvenida a Kat OS"), "titulo")
        t.setAlignment(Qt.AlignCenter)
        caja.addWidget(t)
        s = rol(QLabel("En unos pasos dejamos Kat OS a tu gusto: tu perfil, cómo se ve, "
                       "tu seguridad y tus apps. Todo se puede cambiar después."), "subtitulo")
        s.setWordWrap(True)
        s.setAlignment(Qt.AlignCenter)
        caja.addWidget(s)
        if plataforma.VISTA_PREVIA:
            aviso = rol(QLabel("Estás en %s: puedes recorrer todo, pero los cambios solo se aplican "
                               "en Kat OS." % plataforma.nombre()), "aviso")
            aviso.setWordWrap(True)
            aviso.setAlignment(Qt.AlignCenter)
            caja.addSpacing(12)
            caja.addWidget(aviso)
        caja.addStretch(2)


class PaginaPerfil(Pagina):
    titulo_lateral = "Tu perfil"

    def __init__(self, eleccion):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Tu perfil", "Cómo te llamas y qué foto quieres. Aparece al iniciar sesión."))
        caja.addWidget(QLabel("Tu nombre:"))
        self.nombre = QLineEdit(eleccion.nombre)
        self.nombre.setMaxLength(60)
        caja.addWidget(self.nombre)
        caja.addSpacing(8)
        caja.addWidget(QLabel("Tu foto:"))
        self.fotos = QListWidget()
        self.fotos.setViewMode(QListView.IconMode)
        self.fotos.setIconSize(QSize(88, 88))
        self.fotos.setGridSize(QSize(108, 108))
        self.fotos.setMovement(QListView.Static)
        self.fotos.setResizeMode(QListView.Adjust)
        for ruta in recursos.avatares():
            item = QListWidgetItem(QIcon(ruta), "")
            item.setData(Qt.UserRole, ruta)
            item.setToolTip(os.path.basename(ruta)[4:-4].capitalize())
            self.fotos.addItem(item)
        if self.fotos.count():
            self.fotos.setCurrentRow(0)
        caja.addWidget(self.fotos, 1)
        otra = QPushButton("Elegir otra imagen…")
        otra.clicked.connect(self._elegir_otra)
        caja.addWidget(otra, 0, Qt.AlignLeft)

    def _elegir_otra(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Elegir foto de perfil", os.path.expanduser("~"),
                                              "Imágenes (*.png *.jpg *.jpeg *.webp)")
        if ruta:
            item = QListWidgetItem(QIcon(ruta), "")
            item.setData(Qt.UserRole, ruta)
            self.fotos.addItem(item)
            self.fotos.setCurrentItem(item)

    def valida(self):
        if not self.nombre.text().strip():
            return False, "Escribe tu nombre."
        return True, ""

    def guardar(self, e):
        e.nombre = self.nombre.text().strip()
        item = self.fotos.currentItem()
        e.foto = item.data(Qt.UserRole) if item else None


class PaginaApariencia(Pagina):
    titulo_lateral = "Apariencia"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Apariencia", "Elige entre modo oscuro o claro y tu color favorito."))
        fila = QHBoxLayout()
        self.modos = QButtonGroup(self)
        for clave, texto, fondo, letra in (("oscuro", "Oscuro", COLORES["fondo"], COLORES["texto"]),
                                           ("claro", "Claro", "#f5f3ff", "#1b1528")):
            tarjeta = rol(QFrame(), "tarjeta")
            t = QVBoxLayout(tarjeta)
            muestra = QLabel("Aa")
            muestra.setAlignment(Qt.AlignCenter)
            muestra.setMinimumSize(180, 100)
            muestra.setStyleSheet("background:%s;color:%s;border-radius:10px;font-size:26pt;" % (fondo, letra))
            boton = QRadioButton(texto)
            boton.setProperty("clave", clave)
            self.modos.addButton(boton)
            t.addWidget(muestra)
            t.addWidget(boton)
            fila.addWidget(tarjeta)
            if clave == "oscuro":
                boton.setChecked(True)
        caja.addLayout(fila)
        caja.addSpacing(16)
        caja.addWidget(QLabel("Color de acento:"))
        fila2 = QHBoxLayout()
        self.acentos = QButtonGroup(self)
        for clave, color in acciones.ACENTOS.items():
            b = QPushButton()
            b.setCheckable(True)
            b.setFixedSize(44, 44)
            b.setToolTip(clave.capitalize())
            b.setProperty("clave", clave)
            b.setStyleSheet("QPushButton{background:%s;border-radius:22px;border:3px solid transparent;}"
                            "QPushButton:checked{border:3px solid white;}" % color)
            self.acentos.addButton(b)
            fila2.addWidget(b)
            if clave == "violeta":
                b.setChecked(True)
        fila2.addStretch(1)
        caja.addLayout(fila2)
        caja.addStretch(1)

    def guardar(self, e):
        e.modo = self.modos.checkedButton().property("clave")
        e.acento = self.acentos.checkedButton().property("clave")


class PaginaEstilo(Pagina):
    titulo_lateral = "Estilo"

    def __init__(self):
        super().__init__()
        from katui import estilos
        from katui.vistas import VistaEstilo
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("¿Cómo quieres tu escritorio?",
                               "Elige el que te resulte más familiar. Se puede cambiar después en Kat Settings."))
        fila = QHBoxLayout()
        self.grupo = QButtonGroup(self)
        for clave, datos in estilos.ESTILOS.items():
            tarjeta = rol(QFrame(), "tarjeta")
            t = QVBoxLayout(tarjeta)
            t.addWidget(VistaEstilo(clave))
            b = QRadioButton(datos["nombre"])
            b.setProperty("clave", clave)
            b.setStyleSheet("font-weight:600;")
            self.grupo.addButton(b)
            t.addWidget(b)
            d = rol(QLabel(datos["descripcion"]), "subtitulo")
            d.setWordWrap(True)
            t.addWidget(d)
            t.addStretch(1)
            tarjeta.setMinimumWidth(1)          # que el texto no ensanche una tarjeta más que otra
            fila.addWidget(tarjeta, 1)
            if clave == "windows":
                b.setChecked(True)
        caja.addLayout(fila)
        caja.addStretch(1)

    def guardar(self, e):
        e.estilo = self.grupo.checkedButton().property("clave")


class PaginaFondo(Pagina):
    titulo_lateral = "Fondo"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Fondo de pantalla", "Puedes cambiarlo cuando quieras con clic derecho en el escritorio."))
        self.lista = QListWidget()
        self.lista.setViewMode(QListView.IconMode)
        self.lista.setIconSize(QSize(208, 117))
        self.lista.setGridSize(QSize(228, 150))
        self.lista.setMovement(QListView.Static)
        self.lista.setResizeMode(QListView.Adjust)
        self.lista.setWordWrap(True)
        for f in recursos.fondos():
            item = QListWidgetItem(QIcon(f.miniatura), f.nombre)
            item.setData(Qt.UserRole, f.imagen)
            self.lista.addItem(item)
        if self.lista.count():
            self.lista.setCurrentRow(0)
        caja.addWidget(self.lista, 1)

    def guardar(self, e):
        item = self.lista.currentItem()
        e.fondo = item.data(Qt.UserRole) if item else None


class PaginaSeguridad(Pagina):
    titulo_lateral = "Seguridad"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Seguridad y privacidad", "Lo recomendado ya viene marcado."))
        # Lo recomendado (ambos activados) viene marcado siempre.
        self.firewall = QCheckBox("Cortafuegos activado (bloquea conexiones que no pediste)")
        self.firewall.setChecked(True)
        self.actualizaciones = QCheckBox("Instalar actualizaciones de seguridad automáticamente")
        self.actualizaciones.setChecked(True)
        caja.addWidget(self.firewall)
        caja.addWidget(self.actualizaciones)
        caja.addSpacing(12)
        nota = rol(QLabel("Kat OS no envía tus datos ni informes de fallos a nadie.\n"
                          "Para cambiar el cortafuegos o las actualizaciones te pedirá tu contraseña."),
                   "subtitulo")
        nota.setWordWrap(True)
        caja.addWidget(nota)
        caja.addStretch(1)

    def guardar(self, e):
        e.firewall = self.firewall.isChecked()
        e.actualizaciones = self.actualizaciones.isChecked()


class PaginaDesbloqueo(Pagina):
    """Módulo de seguridad: cómo quieres desbloquear Kat OS (todo opcional)."""
    titulo_lateral = "Desbloqueo"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Cómo quieres desbloquear Kat OS",
                               "Todo es opcional: tu contraseña siempre funciona. Puedes cambiarlo luego en "
                               "Kat Settings → Seguridad."))
        t1 = rol(QFrame(), "tarjeta")
        c1 = QVBoxLayout(t1)
        c1.addWidget(QLabel("🔢  <b>PIN</b> — %d a %d números, se escribe donde la contraseña"
                            % (pin.LARGO_MIN, pin.LARGO_MAX)))
        fila = QHBoxLayout()
        self.pin1 = QLineEdit()
        self.pin1.setPlaceholderText("PIN (déjalo vacío si no quieres)")
        self.pin2 = QLineEdit()
        self.pin2.setPlaceholderText("Repite el PIN")
        for e in (self.pin1, self.pin2):
            e.setEchoMode(QLineEdit.Password)
            e.setMaxLength(pin.LARGO_MAX)
            fila.addWidget(e)
        c1.addLayout(fila)
        caja.addWidget(t1)

        t2 = rol(QFrame(), "tarjeta")
        c2 = QVBoxLayout(t2)
        self.rostro = QCheckBox("🙂  Desbloquear con mi cara (Kat Rostro) — se configura al terminar")
        c2.addWidget(self.rostro)
        aviso = rol(QLabel("Con una cámara normal una foto podría engañarlo: es una comodidad, no una caja fuerte."),
                    "aviso")
        aviso.setWordWrap(True)
        c2.addWidget(aviso)
        self.telefono = QCheckBox("📱  Desbloquear con un botón en mi teléfono (Kat Phone ID) — se vincula al "
                                  "terminar")
        c2.addWidget(self.telefono)
        nota = rol(QLabel("Kat Phone ID funciona solo en el Wi-Fi de tu casa."), "subtitulo")
        c2.addWidget(nota)
        caja.addWidget(t2)
        caja.addStretch(1)

    def valida(self):
        a, b = self.pin1.text().strip(), self.pin2.text().strip()
        if not a and not b:
            return True, ""
        try:
            pin.validar(a)
        except pin.ErrorPin as e:
            return False, str(e)
        if a != b:
            return False, "Los dos PIN no coinciden"
        return True, ""

    def guardar(self, e):
        e.pin = self.pin1.text().strip() or None
        e.rostro = self.rostro.isChecked()
        e.telefono = self.telefono.isChecked()


class PaginaApps(Pagina):
    titulo_lateral = "Apps"

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addLayout(_titulo("Apps sugeridas", "Marca las que quieras. Se instalan desde Flathub (hace falta internet)."))
        if sistema.en_modo_live():
            aviso = rol(QLabel("Estás probando Kat OS sin instalar: lo que instales se guarda en la memoria RAM "
                               "y se borra al apagar. Mejor instálalas después de instalar Kat OS."), "aviso")
            aviso.setWordWrap(True)
            caja.addWidget(aviso)
        area = QScrollArea()
        area.setWidgetResizable(True)
        interior = QWidget()
        grid = QGridLayout(interior)
        self.casillas = []
        for i, (app_id, nombre, desc) in enumerate(catalogo.APPS):
            c = QCheckBox("%s — %s" % (nombre, desc))
            c.setProperty("app_id", app_id)
            grid.addWidget(c, i // 2, i % 2)
            self.casillas.append(c)
        area.setWidget(interior)
        caja.addWidget(area, 1)

    def guardar(self, e):
        e.apps = [(c.property("app_id"), c.text().split(" — ")[0]) for c in self.casillas if c.isChecked()]


class Trabajador(QThread):
    """Aplica las elecciones una por una, fuera de la ventana (no la congela)."""

    empezando = Signal(int, str)
    terminado_paso = Signal(int, str, str, str)   # índice, nombre, estado, mensaje

    def __init__(self, pasos):
        super().__init__()
        self.pasos = pasos

    def run(self):
        for i, (nombre, funcion, args) in enumerate(self.pasos):
            self.empezando.emit(i, nombre)
            try:
                r = funcion(*args)
            except Exception as e:  # cualquier error inesperado se muestra, no se esconde
                r = res.fallo("error inesperado: %s" % e)
            self.terminado_paso.emit(i, nombre, r.estado, r.mensaje)


class PaginaAplicando(Pagina):
    titulo_lateral = "Listo"
    SIMBOLO = {res.HECHO: ("✔", COLORES["ok"]), res.FALLO: ("✖", COLORES["error"]),
               res.NO_DISPONIBLE: ("ⓘ", COLORES["aviso"])}

    listo = Signal()

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        self.encabezado = QVBoxLayout()
        self.titulo = rol(QLabel("Aplicando tus elecciones…"), "titulo")
        caja.addWidget(self.titulo)
        self.barra = QProgressBar()
        caja.addWidget(self.barra)
        caja.addSpacing(8)
        self.lista = QVBoxLayout()
        caja.addLayout(self.lista)
        caja.addStretch(1)
        self.filas = []
        self.resultados = []

    def empezar(self, pasos):
        self.barra.setRange(0, len(pasos))
        self.barra.setValue(0)
        for nombre, _f, _a in pasos:
            fila = QLabel("•  %s" % nombre)
            fila.setStyleSheet("color:%s;" % COLORES["texto_suave"])
            fila.setWordWrap(True)
            self.lista.addWidget(fila)
            self.filas.append(fila)
        self.trabajador = Trabajador(pasos)
        self.trabajador.empezando.connect(self._empieza)
        self.trabajador.terminado_paso.connect(self._termina)
        self.trabajador.finished.connect(self._fin)
        self.trabajador.start()

    def _empieza(self, i, nombre):
        self.filas[i].setText("…  %s" % nombre)
        self.filas[i].setStyleSheet("color:%s;" % COLORES["texto"])

    def _termina(self, i, nombre, estado, mensaje):
        simbolo, color = self.SIMBOLO[estado]
        texto = "%s  %s" % (simbolo, nombre)
        if mensaje:
            texto += "  —  %s" % mensaje
        self.filas[i].setText(texto)
        self.filas[i].setStyleSheet("color:%s;" % color)
        self.barra.setValue(i + 1)
        self.resultados.append((nombre, estado, mensaje))
        acciones.registrar("info" if estado == res.HECHO else "warning",
                           "bienvenida: %s -> %s %s" % (nombre, estado, mensaje))

    def _fin(self):
        fallos = sum(1 for _n, e, _m in self.resultados if e == res.FALLO)
        if fallos:
            self.titulo.setText("Listo, con %d cosa(s) por revisar" % fallos)
        elif plataforma.VISTA_PREVIA:
            self.titulo.setText("Recorrido terminado (vista previa)")
        else:
            self.titulo.setText("¡Todo listo! Disfruta Kat OS")
        self.listo.emit()


# --- ventana -----------------------------------------------------------------
class VentanaBienvenida(QWidget):
    def __init__(self, primer_inicio=False):
        super().__init__()
        self.primer_inicio = primer_inicio
        self.setWindowTitle("Kat Bienvenida")
        ruta = recursos.icono("kat-bienvenida")
        if ruta:
            self.setWindowIcon(QIcon(ruta))
        self.resize(980, 660)
        self.eleccion = Eleccion()

        self.paginas = [PaginaHola(), PaginaPerfil(self.eleccion), PaginaApariencia(), PaginaEstilo(),
                        PaginaFondo(), PaginaSeguridad(), PaginaDesbloqueo(), PaginaApps(), PaginaAplicando()]
        self.aplicando = self.paginas[-1]
        self.aplicando.listo.connect(self._aplicado)

        # Pantalla completa: el fondo de Kat detrás y una tarjeta centrada con el asistente.
        fondos = recursos.fondos()
        self._fondo = QPixmap(fondos[0].imagen) if fondos else QPixmap()
        exterior = QVBoxLayout(self)
        exterior.setContentsMargins(40, 40, 40, 40)
        self.tarjeta = QFrame()
        self.tarjeta.setObjectName("tarjetaBienvenida")
        self.tarjeta.setStyleSheet("#tarjetaBienvenida { background: rgba(16,13,25,232); border-radius: 22px; "
                                   "border: 1px solid %s; }" % COLORES["borde"])
        self.tarjeta.setMaximumSize(1180, 780)
        self.tarjeta.setMinimumSize(900, 620)
        exterior.addWidget(self.tarjeta, 0, Qt.AlignCenter)
        raiz = QHBoxLayout(self.tarjeta)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)

        lateral = rol(QFrame(), "lateral")
        lateral.setStyleSheet("border-top-left-radius: 22px; border-bottom-left-radius: 22px;")
        lateral.setFixedWidth(210)
        lat = QVBoxLayout(lateral)
        lat.setContentsMargins(18, 24, 18, 18)
        marca = QLabel("Kat OS")
        marca.setStyleSheet("font-size:16pt;font-weight:700;color:%s;" % COLORES["violeta_claro"])
        lat.addWidget(marca)
        lat.addSpacing(16)
        self.pasos = []
        for p in self.paginas:
            l = QLabel(p.titulo_lateral)
            lat.addWidget(l)
            self.pasos.append(l)
        lat.addStretch(1)
        self.musica = musica.Musica("kat-bienvenida")
        self.b_musica = QPushButton("♪  Música: sí")
        self.b_musica.setFlat(True)
        self.b_musica.clicked.connect(self._alternar_musica)
        self.b_musica.setVisible(self.musica.archivo is not None)
        lat.addWidget(self.b_musica)
        self.b_omitir = QPushButton("Omitir por ahora")
        self.b_omitir.setFlat(True)
        self.b_omitir.setStyleSheet("color:%s;" % COLORES["texto_suave"])
        self.b_omitir.clicked.connect(self.close)
        lat.addWidget(self.b_omitir)
        version = rol(QLabel("Kat Bienvenida %s" % VERSION), "subtitulo")
        lat.addWidget(version)
        raiz.addWidget(lateral)

        derecha = QVBoxLayout()
        derecha.setContentsMargins(32, 28, 32, 20)
        self.pila = QStackedWidget()
        for p in self.paginas:
            self.pila.addWidget(p)
        derecha.addWidget(self.pila, 1)
        self.error = rol(QLabel(""), "error")
        derecha.addWidget(self.error)
        botones = QHBoxLayout()
        self.atras = QPushButton("Atrás")
        self.siguiente = rol(QPushButton("Siguiente"), "principal")
        self.atras.clicked.connect(self.anterior)
        self.siguiente.clicked.connect(self.avanzar)
        botones.addStretch(1)
        botones.addWidget(self.atras)
        botones.addWidget(self.siguiente)
        derecha.addLayout(botones)
        raiz.addLayout(derecha, 1)
        self._ir(0)

    # --- fondo, animaciones y música ------------------------------------------------
    def paintEvent(self, evento):
        p = QPainter(self)
        if not self._fondo.isNull():
            img = self._fondo.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap((self.width() - img.width()) // 2, (self.height() - img.height()) // 2, img)
        else:
            p.fillRect(self.rect(), QColor(COLORES["fondo"]))
        p.fillRect(self.rect(), QColor(0, 0, 0, 90))
        p.end()

    def showEvent(self, evento):
        super().showEvent(evento)
        if not getattr(self, "_mostrada", False):
            self._mostrada = True
            self._aparecer(self.tarjeta, 600)
            self.musica.empezar()

    def _aparecer(self, widget, ms=280):
        """Aparición suave (de transparente a visible)."""
        efecto = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(efecto)
        anim = QPropertyAnimation(efecto, b"opacity", widget)
        anim.setDuration(ms)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(lambda: widget.setGraphicsEffect(None))   # sin efecto: dibuja más rápido
        anim.start(QPropertyAnimation.DeleteWhenStopped)

    def _alternar_musica(self):
        if self.musica.sonando:
            self.musica.parar()
            self.b_musica.setText("♪  Música: no")
        else:
            self.musica.empezar()
            self.b_musica.setText("♪  Música: sí")

    def closeEvent(self, evento):
        self.musica.parar()
        super().closeEvent(evento)

    def _ir(self, i):
        if i != self.pila.currentIndex():
            self._aparecer(self.paginas[i])
        self.pila.setCurrentIndex(i)
        for j, l in enumerate(self.pasos):
            if j == i:
                l.setStyleSheet("color:white;font-weight:600;padding:6px;border-radius:6px;background:%s;"
                                % COLORES["borde"])
            else:
                l.setStyleSheet("color:%s;padding:6px;" % (COLORES["texto"] if j < i else COLORES["texto_suave"]))
        ultima_eleccion = len(self.paginas) - 2
        self.atras.setEnabled(0 < i <= ultima_eleccion)
        self.siguiente.setText("Aplicar" if i == ultima_eleccion else "Siguiente")
        self.error.setText("")

    def anterior(self):
        self._ir(max(0, self.pila.currentIndex() - 1))

    def avanzar(self):
        i = self.pila.currentIndex()
        pagina = self.paginas[i]
        ok, motivo = pagina.valida()
        if not ok:
            self.error.setText(motivo)
            return
        pagina.guardar(self.eleccion)
        if pagina is self.aplicando:
            self.close()
            if self.eleccion.rostro:
                acciones.abrir_app_kat("kat-rostro", "katrostro.app")
            if self.eleccion.telefono:
                acciones.abrir_app_kat("kat-telefono", "kattelefono.app")
            return
        if i == len(self.paginas) - 2:
            self._ir(i + 1)
            self.siguiente.setEnabled(False)
            self.atras.setEnabled(False)
            self.aplicando.empezar(self.pasos_a_aplicar())
            return
        self._ir(i + 1)

    def pasos_a_aplicar(self):
        e = self.eleccion
        pasos = [
            ("Tu nombre", acciones.cambiar_nombre, (e.nombre,)),
            ("Tu foto de perfil", acciones.cambiar_foto, (e.foto,)),
            ("Apariencia", acciones.cambiar_apariencia, (e.modo, e.acento)),
            ("Estilo de escritorio", acciones.cambiar_estilo, (e.estilo,)),
            ("Fondo de pantalla", acciones.cambiar_fondo, (e.fondo,)),
            ("Cortafuegos", acciones.cambiar_firewall, (e.firewall,)),
            ("Actualizaciones automáticas", acciones.cambiar_actualizaciones, (e.actualizaciones,)),
        ]
        if e.pin:
            pasos.append(("PIN de desbloqueo", acciones.crear_pin, (e.pin,)))
        for app_id, nombre in e.apps:
            pasos.append(("Instalar %s" % nombre, acciones.instalar_app, (app_id,)))
        return pasos

    def _aplicado(self):
        self.siguiente.setText("Empezar a usar Kat OS")
        self.siguiente.setEnabled(True)
        self.b_omitir.hide()
        if not plataforma.VISTA_PREVIA:
            acciones.marcar_hecha()
