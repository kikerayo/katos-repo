"""Punto de entrada de Kat Bienvenida."""

import sys

from . import APP_ID, VERSION, acciones


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    primer_inicio = "--primer-inicio" in argv
    # En el arranque automático no molestar si ya se hizo.
    if primer_inicio and acciones.ya_hecha():
        return 0

    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaBienvenida

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Bienvenida")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaBienvenida(primer_inicio=primer_inicio)
    v.showFullScreen()
    return app.exec()
