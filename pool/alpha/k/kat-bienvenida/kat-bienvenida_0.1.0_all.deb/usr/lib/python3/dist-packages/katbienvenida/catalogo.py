"""Apps sugeridas en Kat Bienvenida (se instalan desde Flathub)."""

APPS = [
    # (id de Flathub, nombre, para qué sirve)
    ("com.discordapp.Discord", "Discord", "chat de voz y texto con tus comunidades"),
    ("com.spotify.Client", "Spotify", "música"),
    ("com.valvesoftware.Steam", "Steam", "juegos"),
    ("org.videolan.VLC", "VLC", "reproduce cualquier video o audio"),
    ("com.obsproject.Studio", "OBS Studio", "grabar pantalla y hacer directos"),
    ("org.telegram.desktop", "Telegram", "mensajería"),
    ("com.google.Chrome", "Google Chrome", "navegador de Google"),
    ("com.visualstudio.code", "Visual Studio Code", "editor de código"),
    ("org.libreoffice.LibreOffice", "LibreOffice", "documentos, hojas de cálculo y presentaciones"),
    ("org.gimp.GIMP", "GIMP", "editar fotos"),
    ("org.kde.krita", "Krita", "dibujo digital"),
]
