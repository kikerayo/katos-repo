"""Lo que Kat Bienvenida aplica de verdad. Cada función devuelve un Resultado.

Tema, fondo, nombre, foto, cortafuegos y actualizaciones vienen de kat-ui
(los comparte con Kat Settings). En Windows (vista previa) todo responde
"solo funciona en Kat OS": no se finge nada.
"""

import os
import subprocess

from katui import acciones, cuenta, escritorio, plataforma, sistema

from . import APP_ID, VERSION

ESQUEMAS = escritorio.ESQUEMAS
ACENTOS = escritorio.ACENTOS


# --- registro en Kat Core (si está) ---------------------------------------
def registrar(nivel, mensaje):
    try:
        from katcore.cliente import KatCoreCliente
        kc = KatCoreCliente()
        kc.registrar_app(APP_ID, VERSION)
        kc.evento(APP_ID, nivel, mensaje)
    except Exception:
        pass  # en Windows o sin katd: no pasa nada


# --- compartido con Kat Settings ------------------------------------------
nombre_actual = cuenta.nombre_actual


def cambiar_nombre(nombre):
    return cuenta.cambiar_nombre(nombre)


def cambiar_foto(ruta):
    return cuenta.cambiar_foto(ruta)


def cambiar_apariencia(modo, acento):
    return escritorio.cambiar_apariencia(modo, acento)


def cambiar_fondo(imagen):
    return escritorio.cambiar_fondo(imagen)


def cambiar_estilo(clave):
    from katui import estilos
    return estilos.aplicar(clave)


def cambiar_firewall(activar):
    return sistema.cambiar_firewall(activar)


def cambiar_actualizaciones(activar):
    return sistema.cambiar_actualizaciones(activar)


def crear_pin(pin_nuevo):
    from katui import pin
    try:
        pin.crear(pin_nuevo)
    except pin.ErrorPin as e:
        return acciones.fallo(str(e))
    return acciones.hecho("listo: desbloquea la pantalla con tu PIN")


def abrir_app_kat(programa, modulo):
    """Abre una app Kat (en Windows, la vista previa desde el proyecto)."""
    import shutil
    import sys
    if shutil.which(programa):
        orden = [programa]
    else:
        orden = [sys.executable, "-m", modulo]
    try:
        subprocess.Popen(orden, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except OSError:
        return False


# --- apps de Flathub --------------------------------------------------------
def app_instalada(app_id):
    if not plataforma.tiene("flatpak"):
        return False
    return subprocess.run(["flatpak", "info", app_id], capture_output=True).returncode == 0


def instalar_app(app_id):
    if not plataforma.tiene("flatpak"):
        return acciones.no_disponible("Las apps se instalan en Kat OS")
    if app_instalada(app_id):
        return acciones.hecho("ya estaba instalada")
    r = acciones.ejecutar(["flatpak", "install", "--system", "--noninteractive", "-y", "flathub", app_id],
                          tiempo=3600)
    return acciones.hecho("instalada") if r.ok else r


# --- primer inicio ---------------------------------------------------------
def _marca():
    return os.path.join(plataforma.carpeta_config("bienvenida"), "hecha")


def ya_hecha():
    return os.path.exists(_marca())


def marcar_hecha():
    with open(_marca(), "w", encoding="utf-8") as f:
        f.write("Kat Bienvenida %s\n" % VERSION)
