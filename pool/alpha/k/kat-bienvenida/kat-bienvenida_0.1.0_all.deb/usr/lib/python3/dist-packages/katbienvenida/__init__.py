"""Kat Bienvenida: la configuración del primer inicio de Kat OS.

Sustituye a la bienvenida genérica de Plasma. Pasos: perfil (nombre y
foto), apariencia (oscuro/claro y color), fondo, seguridad, apps
sugeridas y resumen con lo que de verdad se aplicó.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Bienvenida"
