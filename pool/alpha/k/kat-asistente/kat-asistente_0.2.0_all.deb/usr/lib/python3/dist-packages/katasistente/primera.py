"""La primera vez que usas a Kat: palabra de activación, micrófono, voz y diseño.

Va en el panel junto a la canica, en pasos cortos.
Mientras tanto suena la música de Kat Bienvenida bajito y con eco, como si
Kat la estuviera reproduciendo.
"""

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QButtonGroup, QHBoxLayout, QLabel, QLineEdit, QPushButton, QRadioButton,
                               QStackedWidget, QVBoxLayout, QWidget)

from katui.estilo import COLORES

from . import perfil

ESTILO_CHIP = ("QPushButton{background:%s;border:1px solid %s;border-radius:12px;padding:4px 10px;font-size:9pt;}"
               "QPushButton:checked{border:2px solid %s;}" % (COLORES["tarjeta"], COLORES["borde"],
                                                              COLORES["violeta_claro"]))
ESTILO_PRINCIPAL = ("QPushButton{background:%s;border:none;border-radius:14px;padding:8px 18px;color:white;"
                    "font-weight:600;}" % COLORES["violeta"])
ESTILO_TEXTO = "background:transparent;color:%s;font-size:10.5pt;" % COLORES["texto"]


def _texto(t, suave=False):
    l = QLabel(t)
    l.setWordWrap(True)
    l.setAlignment(Qt.AlignCenter)
    l.setStyleSheet(ESTILO_TEXTO if not suave else
                    "background:transparent;color:%s;font-size:8.5pt;" % COLORES["texto_suave"])
    return l


class PrimeraVez(QWidget):
    """Señales: probar_voz(id de voz), probar_diseno(clave), terminado(perfil guardado)."""

    probar_voz = Signal(str)
    probar_diseno = Signal(str)
    terminado = Signal(dict)

    def __init__(self, voces=None, tiene_clave=True):
        super().__init__()
        self.setStyleSheet("background:transparent;")
        caja = QVBoxLayout(self)
        caja.setContentsMargins(0, 0, 0, 0)
        self.pasos = QStackedWidget()
        caja.addWidget(self.pasos)
        self.error = _texto("", suave=True)
        self.error.setStyleSheet("background:transparent;color:%s;font-size:8.5pt;" % COLORES["error"])
        caja.addWidget(self.error)
        botones = QHBoxLayout()
        self.atras = QPushButton("Atrás")
        self.atras.setStyleSheet(ESTILO_CHIP)
        self.siguiente = QPushButton("Empezar")
        self.siguiente.setStyleSheet(ESTILO_PRINCIPAL)
        self.atras.clicked.connect(lambda: self._ir(self.pasos.currentIndex() - 1))
        self.siguiente.clicked.connect(self._avanzar)
        botones.addWidget(self.atras)
        botones.addStretch(1)
        botones.addWidget(self.siguiente)
        caja.addLayout(botones)

        # 0: hola
        p0 = QWidget()
        l0 = QVBoxLayout(p0)
        l0.addWidget(_texto("<b>¡Por fin salí! 😺</b><br>Soy Kat, tu asistente. Antes de empezar, "
                            "vamos a dejarme a tu gusto: cómo me llamas, cómo sueno y cómo me veo."))
        self.pasos.addWidget(p0)

        # 1: palabra de activación
        p1 = QWidget()
        l1 = QVBoxLayout(p1)
        l1.addWidget(_texto("<b>¿Con qué palabra me llamas?</b>"))
        self.palabra = QLineEdit(perfil.PREDETERMINADO["palabra"])
        self.palabra.setMaxLength(24)
        self.palabra.setAlignment(Qt.AlignCenter)
        self.palabra.setStyleSheet("QLineEdit{background:%s;border:1px solid %s;border-radius:14px;padding:7px;"
                                   "font-size:11pt;}" % (COLORES["tarjeta"], COLORES["borde"]))
        l1.addWidget(self.palabra)
        fila = QHBoxLayout()
        for sugerida in perfil.PALABRAS:
            b = QPushButton(sugerida)
            b.setStyleSheet(ESTILO_CHIP)
            b.clicked.connect(lambda _=False, t=sugerida: self.palabra.setText(t))
            fila.addWidget(b)
        l1.addLayout(fila)
        l1.addWidget(_texto("La escucha por voz llega con «Hey Kat»: tu palabra ya quedará lista para entonces.",
                            suave=True))
        self.pasos.addWidget(p1)

        # 2: micrófono
        p2 = QWidget()
        l2 = QVBoxLayout(p2)
        l2.addWidget(_texto("<b>¿Tienes micrófono?</b>"))
        self.grupo_micro = QButtonGroup(self)
        for clave, nombre in (("si", "🎤  Sí: toco la canica y te hablo"), ("no", "⌨️  No: toco la canica y te escribo")):
            r = QRadioButton(nombre)
            r.setProperty("clave", clave)
            r.setStyleSheet(ESTILO_TEXTO)
            r.setChecked(clave == "si")
            self.grupo_micro.addButton(r)
            l2.addWidget(r, 0, Qt.AlignHCenter)
        nota = ("Para entender tu voz, Kat la envía a Groq (Whisper) solo cuando tocas la canica para hablar."
                if tiene_clave else
                "Para entender tu voz hace falta tu clave gratis de Groq (clic derecho en la canica → Kat Cloud AI). "
                "Mientras no la pongas, te abriré la caja de texto.")
        l2.addWidget(_texto(nota, suave=True))
        self.pasos.addWidget(p2)

        # 3: voz (de verdad: Kat dice sus respuestas en voz alta)
        p3v = QWidget()
        l3v = QVBoxLayout(p3v)
        l3v.addWidget(_texto("<b>Elige mi voz</b> — toca una para escucharme"))
        self.grupo_voz = QButtonGroup(self)
        self.caja_voces = QVBoxLayout()
        l3v.addLayout(self.caja_voces)
        self.poner_voces(voces if voces is not None else [])
        self.pasos.addWidget(p3v)

        # 4: diseño
        p3 = QWidget()
        l3 = QVBoxLayout(p3)
        l3.addWidget(_texto("<b>Elige mi diseño</b> (mira la canica)"))
        fila = QHBoxLayout()
        fila.setSpacing(6)
        self.grupo_diseno = QButtonGroup(self)
        for clave, (nombre, colores) in perfil.DISENOS.items():
            b = QPushButton()
            b.setCheckable(True)
            b.setChecked(clave == "kat")
            b.setToolTip(nombre)
            b.setProperty("clave", clave)
            b.setFixedSize(40, 40)
            paradas = ", ".join("stop:%.2f rgb%s" % (i / (len(colores) - 1), c) for i, c in enumerate(colores))
            b.setStyleSheet("QPushButton{border-radius:20px;border:2px solid %s;background:qlineargradient("
                            "x1:0,y1:0,x2:1,y2:1, %s);} QPushButton:checked{border:3px solid white;}"
                            % (COLORES["borde"], paradas))
            b.clicked.connect(lambda _=False, k=clave: self._elegir_diseno(k))
            self.grupo_diseno.addButton(b)
            fila.addWidget(b)
        l3.addLayout(fila)
        self.nombre_diseno = _texto(perfil.DISENOS["kat"][0], suave=True)
        l3.addWidget(self.nombre_diseno)
        self.pasos.addWidget(p3)
        self._ir(0)

    def poner_voces(self, voces):
        """Las voces del equipo [(id, nombre)] + "sin voz". La primera en español queda elegida."""
        for b in self.grupo_voz.buttons():
            self.grupo_voz.removeButton(b)
            b.deleteLater()
        if getattr(self, "_sin_voces", None) is not None:
            self._sin_voces.deleteLater()
            self._sin_voces = None
        opciones = list(voces[:5]) + [("", "🔇  Sin voz (solo escribo)")]
        for i, (id_voz, nombre) in enumerate(opciones):
            r = QRadioButton(nombre)
            r.setProperty("clave", id_voz)
            r.setStyleSheet(ESTILO_TEXTO)
            r.setChecked(i == 0)
            if id_voz:
                r.clicked.connect(lambda _=False, v=id_voz: self.probar_voz.emit(v))
            self.grupo_voz.addButton(r)
            self.caja_voces.addWidget(r, 0, Qt.AlignHCenter)
        if not voces:
            self._sin_voces = _texto("Buscando voces… (si no hay, escribiré mis respuestas)", suave=True)
            self.caja_voces.addWidget(self._sin_voces)

    def _elegir_diseno(self, clave):
        self.nombre_diseno.setText(perfil.DISENOS[clave][0])
        self.probar_diseno.emit(clave)

    def _clave(self, grupo, por_defecto):
        b = grupo.checkedButton()
        return b.property("clave") if b else por_defecto

    def _ir(self, i):
        i = max(0, min(i, self.pasos.count() - 1))
        self.pasos.setCurrentIndex(i)
        self.error.setText("")
        self.atras.setVisible(i > 0)
        ultimo = i == self.pasos.count() - 1
        self.siguiente.setText("Empezar" if i == 0 else ("¡Listo!" if ultimo else "Siguiente"))

    def _avanzar(self):
        i = self.pasos.currentIndex()
        if i == 1:
            try:
                self.palabra.setText(perfil.validar_palabra(self.palabra.text()))
            except ValueError as e:
                self.error.setText(str(e))
                return
        if i < self.pasos.count() - 1:
            self._ir(i + 1)
            return
        datos = perfil.guardar(self.palabra.text(), self._clave(self.grupo_micro, "si") == "si",
                               self._clave(self.grupo_voz, ""), self._clave(self.grupo_diseno, "kat"))
        self.terminado.emit(datos)
