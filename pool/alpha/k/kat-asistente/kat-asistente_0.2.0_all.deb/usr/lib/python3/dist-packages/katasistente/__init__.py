"""Kat, el asistente de Kat OS (Kat Assistant): una orbe animada con orejas de gato.

Versión 0.2: entiende órdenes escritas o habladas en español y las ejecuta de verdad
(abrir apps, hora y fechas, clima, cuentas, volumen, tema, buscar en Kat Store, bloquear,
nota de seguridad). Responde preguntas de saber con Wikipedia y, con Kat Cloud AI
activada, conversa recordando lo hablado y puede pedirle a Kat acciones reales.
"""

VERSION = "0.2.0"
APP_ID = "org.katos.Asistente"
