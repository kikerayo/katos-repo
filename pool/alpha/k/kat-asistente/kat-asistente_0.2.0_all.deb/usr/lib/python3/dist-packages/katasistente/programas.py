"""Encontrar y abrir cualquier programa instalado por su nombre.

- Kat OS / Linux: los archivos .desktop (menú de aplicaciones), incluidas las apps de Flatpak.
- Windows (vista previa): los accesos directos del menú Inicio.
"""

import glob
import os
import re
import shlex
import subprocess
import unicodedata

from katui import plataforma


def _norm(t):
    t = unicodedata.normalize("NFD", (t or "").lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn").strip()


def leer_desktop(ruta):
    """(Nombre, orden Exec) de un .desktop visible, o None."""
    nombre = exec_ = None
    oculto = False
    seccion = None
    try:
        with open(ruta, encoding="utf-8", errors="replace") as f:
            for linea in f:
                linea = linea.strip()
                if linea.startswith("["):
                    seccion = linea
                    continue
                if seccion != "[Desktop Entry]":
                    continue
                if linea.startswith("Name=") and nombre is None:
                    nombre = linea[5:]
                elif linea.startswith("Name[es]="):
                    nombre = linea[9:]
                elif linea.startswith("Exec="):
                    exec_ = linea[5:]
                elif linea in ("NoDisplay=true", "Hidden=true"):
                    oculto = True
    except OSError:
        return None
    if oculto or not nombre or not exec_:
        return None
    return nombre, exec_


def lista():
    """[(nombre, cómo abrirlo)] de los programas instalados."""
    salida = []
    if plataforma.ES_WINDOWS:
        bases = [os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu\Programs"),
                 os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs")]
        for b in bases:
            for lnk in glob.glob(os.path.join(b, "**", "*.lnk"), recursive=True):
                nombre = os.path.splitext(os.path.basename(lnk))[0]
                if not re.search(r"(?i)uninstall|desinstalar|readme|léame|help|ayuda", nombre):
                    salida.append((nombre, lnk))
        return salida
    dirs = ["/usr/share/applications", "/var/lib/flatpak/exports/share/applications",
            os.path.expanduser("~/.local/share/applications"),
            os.path.expanduser("~/.local/share/flatpak/exports/share/applications")]
    for d in dirs:
        for ruta in glob.glob(os.path.join(d, "*.desktop")):
            datos = leer_desktop(ruta)
            if datos:
                salida.append(datos)
    return salida


def buscar(pedido, programas=None):
    """El programa cuyo nombre se parece más a lo pedido, o None."""
    p = _norm(pedido)
    if not p:
        return None
    programas = lista() if programas is None else programas
    exactos = [x for x in programas if _norm(x[0]) == p]
    if exactos:
        return exactos[0]
    empiezan = [x for x in programas if _norm(x[0]).startswith(p)]
    if empiezan:
        return min(empiezan, key=lambda x: len(x[0]))
    contienen = [x for x in programas if p in _norm(x[0])]
    if contienen:
        return min(contienen, key=lambda x: len(x[0]))
    return None


def orden(exec_):
    """Quita los %f, %U... de la línea Exec de un .desktop."""
    partes = [x for x in shlex.split(exec_) if not re.fullmatch(r"%[a-zA-Z]", x)]
    return partes


def abrir(programa):
    nombre, como = programa
    try:
        if plataforma.ES_WINDOWS:
            os.startfile(como)          # abre el acceso directo del menú Inicio
        else:
            subprocess.Popen(orden(como), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        return True
    except OSError:
        return False
