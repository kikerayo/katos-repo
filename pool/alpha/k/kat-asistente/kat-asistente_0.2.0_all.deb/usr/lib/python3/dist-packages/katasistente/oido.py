"""El oído de Kat: graba lo que dices y lo convierte en texto con Groq Whisper.

- Grabar: en Kat OS con pw-record (PipeWire) o arecord; en Windows con el
  grabador del sistema (MCI de winmm). Solo mientras tocas la canica para hablar.
- Entender: el audio se envía a Groq (modelo Whisper) con TU clave de Kat Cloud
  AI y se borra del equipo al terminar. Sin clave o sin internet, Kat lo dice
  y puedes escribir.
"""

import json
import os
import shutil
import signal
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import uuid

from katui import plataforma

from .nube import ErrorNube, LimiteDiario, leer_config

URL = "https://api.groq.com/openai/v1/audio/transcriptions"
MODELO = "whisper-large-v3-turbo"
SEGUNDOS_MAX = 15


def hay_microfono():
    """True si parece haber un micrófono (o None si no se puede saber)."""
    if plataforma.ES_WINDOWS:
        try:
            import ctypes
            return ctypes.windll.winmm.waveInGetNumDevs() > 0
        except Exception:
            return None
    if not (shutil.which("pw-record") or shutil.which("arecord")):
        return False
    return None


class Grabadora:
    """g = Grabadora(); g.empezar(); ...; ruta = g.terminar()  (WAV de 16 kHz mono)"""

    def __init__(self):
        self.ruta = os.path.join(tempfile.gettempdir(), "kat-oido-%s.wav" % uuid.uuid4().hex[:8])
        self.proceso = None
        self.inicio = None
        self._mci = None

    def _orden_mci(self, orden):
        import ctypes
        if self._mci is None:
            self._mci = ctypes.windll.winmm.mciSendStringW
        return self._mci(orden, None, 0, None) == 0

    def empezar(self):
        self.inicio = time.monotonic()
        if plataforma.ES_WINDOWS:
            ok = self._orden_mci("open new type waveaudio alias katoido")
            self._orden_mci("set katoido bitspersample 16 channels 1 samplespersec 16000")
            return ok and self._orden_mci("record katoido")
        if shutil.which("pw-record"):
            orden = ["pw-record", "--rate", "16000", "--channels", "1", "--format", "s16", self.ruta]
        elif shutil.which("arecord"):
            orden = ["arecord", "-q", "-f", "S16_LE", "-r", "16000", "-c", "1", self.ruta]
        else:
            return False
        try:
            self.proceso = subprocess.Popen(orden, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        except OSError:
            return False

    def segundos(self):
        return 0.0 if self.inicio is None else time.monotonic() - self.inicio

    def terminar(self):
        """Para de grabar y devuelve la ruta del WAV (o None si no se grabó nada)."""
        if plataforma.ES_WINDOWS:
            self._orden_mci("stop katoido")
            self._orden_mci('save katoido "%s"' % self.ruta)
            self._orden_mci("close katoido")
        elif self.proceso is not None:
            try:
                self.proceso.send_signal(signal.SIGINT)     # así cierra bien el archivo WAV
                self.proceso.wait(timeout=3)
            except (OSError, subprocess.TimeoutExpired):
                self.proceso.kill()
        if os.path.isfile(self.ruta) and os.path.getsize(self.ruta) > 2000:
            return self.ruta
        self.borrar()
        return None

    def cancelar(self):
        self.terminar()
        self.borrar()

    def borrar(self):
        try:
            os.remove(self.ruta)
        except OSError:
            pass


def _multipart(campos, archivo_nombre, archivo_datos):
    limite = "----kat%s" % uuid.uuid4().hex
    partes = []
    for nombre, valor in campos.items():
        partes.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
                       % (limite, nombre, valor)).encode("utf-8"))
    partes.append(("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
                   "Content-Type: audio/wav\r\n\r\n" % (limite, archivo_nombre)).encode("utf-8"))
    partes.append(archivo_datos)
    partes.append(("\r\n--%s--\r\n" % limite).encode("utf-8"))
    return b"".join(partes), "multipart/form-data; boundary=" + limite


def transcribir(ruta, clave=None, abrir=urllib.request.urlopen):
    """Texto de lo que dijiste en el WAV (lo borra al terminar). ErrorNube si no se pudo."""
    clave = clave or leer_config()["clave"]
    try:
        if not clave:
            raise ErrorNube("Para entender tu voz, pon tu clave de Groq en Kat Cloud AI (clic derecho → ⚙)")
        with open(ruta, "rb") as f:
            datos = f.read()
        cuerpo, tipo = _multipart({"model": MODELO, "language": "es", "response_format": "json",
                                   "temperature": "0"}, "voz.wav", datos)
        peticion = urllib.request.Request(URL, data=cuerpo, method="POST", headers={
            "Authorization": "Bearer " + clave, "Content-Type": tipo, "User-Agent": "KatOS/0.1"})
        try:
            with abrir(peticion, timeout=40) as r:
                texto = json.loads(r.read().decode("utf-8")).get("text", "")
        except urllib.error.HTTPError as e:
            if e.code == 429:
                raise LimiteDiario("Se acabó el límite gratuito de hoy para entender tu voz") from e
            if e.code == 401:
                raise ErrorNube("La clave de Groq no es válida; revísala en ⚙") from e
            raise ErrorNube("Groq no pudo entender el audio (error %d)" % e.code) from e
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise ErrorNube("Sin conexión: no pude entender tu voz") from e
        except ValueError as e:
            raise ErrorNube("Respuesta rara al entender tu voz") from e
        texto = (texto or "").strip()
        if not texto:
            raise ErrorNube("No escuché nada; intenta de nuevo más cerca del micrófono")
        return texto
    finally:
        try:
            os.remove(ruta)
        except OSError:
            pass
