"""La primera vez: Kat golpea la barra de tareas desde dentro antes de salir.

Una capa transparente (no recibe el ratón) sobre la barra: en cada golpe suena
un "bum", la barra tiembla y sale un destello con los colores de Kat (rojo,
azul y blanco) y unas grietas de luz que crecen. Al último golpe, Kat sale.
Para el temblor se copia la imagen de la barra y se dibuja sacudiéndose; si el
sistema no deja copiarla (sale negra, p. ej. en Wayland), solo tiembla el brillo.
"""

import math
import random

from PySide6.QtCore import QPointF, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import QWidget

from . import barra

COLORES = [QColor(255, 59, 92), QColor(59, 130, 246), QColor(255, 255, 255)]
# (segundos, sonido): tres golpes y el último más fuerte
GOLPES = [(0.35, "kat-golpe"), (1.15, "kat-golpe"), (1.85, "kat-golpe"), (2.55, "kat-golpe-final")]


def copia_util(pixmap):
    """True si la copia de la pantalla tiene contenido (no salió toda negra)."""
    if pixmap is None or pixmap.isNull():
        return False
    img = pixmap.toImage()
    w, h = img.width(), img.height()
    if w < 8 or h < 4:
        return False
    vistos = set()
    for i in range(1, 8):
        for j in range(1, 4):
            c = img.pixelColor(w * i // 8, h * j // 4)
            vistos.add((c.red() // 8, c.green() // 8, c.blue() // 8))
    return vistos != {(0, 0, 0)}


class GolpesBarra(QWidget):
    def __init__(self, punto, sonar=None, semilla=None, copiar=True):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                         | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        pantalla = QGuiApplication.primaryScreen()
        self.lado, zona, self.barra_r, self.origen = barra.franja(pantalla.geometry(),
                                                                  pantalla.availableGeometry(), punto)
        self.setGeometry(zona)
        self.sonar = sonar or (lambda nombre: None)
        self.azar = random.Random(semilla)
        self.copia = None
        if copiar:
            try:
                r = self.barra_r.translated(zona.topLeft()).translated(-pantalla.geometry().topLeft())
                c = pantalla.grabWindow(0, r.x(), r.y(), r.width(), r.height())
                self.copia = c if copia_util(c) else None
            except Exception:
                self.copia = None
        self.intensidad, self.temblor, self.color = 0.0, 0.0, COLORES[0]
        self.n_golpes, self.desvanecer, self.saliendo = 0, 1.0, False
        self.grietas = [self._grieta() for _ in range(12)]
        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self._tic)
        self.al_terminar = None

    def _grieta(self):
        """Una grieta de luz en zigzag que sale del centro del golpe."""
        angulo = self.azar.uniform(0, 2 * math.pi)
        puntos, x, y = [QPointF(0, 0)], 0.0, 0.0
        for _ in range(self.azar.randint(3, 5)):
            angulo += self.azar.uniform(-0.6, 0.6)
            paso = self.azar.uniform(14, 34)
            x, y = x + math.cos(angulo) * paso, y + math.sin(angulo) * paso
            puntos.append(QPointF(x, y))
        return puntos

    def empezar(self, al_terminar=None):
        self.al_terminar = al_terminar
        self.show()
        self.reloj.start(16)
        for i, (t, sonido) in enumerate(GOLPES):
            QTimer.singleShot(int(t * 1000), lambda i=i, s=sonido: self.golpe(i, s))
        QTimer.singleShot(int(GOLPES[-1][0] * 1000) + 180, self._terminar)

    def golpe(self, i, sonido):
        self.n_golpes = i + 1
        ultimo = i == len(GOLPES) - 1
        self.intensidad = 1.4 if ultimo else 1.0
        self.temblor = 1.6 if ultimo else 1.0
        self.color = COLORES[i % len(COLORES)]
        self.sonar(sonido)

    def _terminar(self):
        self.saliendo = True
        if self.al_terminar:
            self.al_terminar()

    def _tic(self):
        self.intensidad *= 0.9
        self.temblor *= 0.86
        if self.saliendo:
            self.desvanecer -= 0.05
            if self.desvanecer <= 0:
                self.reloj.stop()
                self.close()
                return
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setOpacity(max(0.0, self.desvanecer))
        fuerza = self.temblor * 7
        dx, dy = self.azar.uniform(-fuerza, fuerza), self.azar.uniform(-fuerza, fuerza)
        if self.lado in ("abajo", "arriba"):
            dy *= 0.4
        else:
            dx *= 0.4
        # la barra temblando (si se pudo copiar su imagen)
        if self.copia is not None and self.temblor > 0.03:
            p.drawPixmap(self.barra_r.translated(int(dx), int(dy)), self.copia)
        o = QPointF(self.origen.x() + dx, self.origen.y() + dy)
        # destello con el color de este golpe
        if self.intensidad > 0.02:
            radio = 120 + 90 * min(self.intensidad, 1.4)
            g = QRadialGradient(o, radio)
            c = QColor(self.color)
            c.setAlpha(int(min(255, 200 * self.intensidad)))
            transparente = QColor(self.color)
            transparente.setAlpha(0)
            g.setColorAt(0.0, QColor(255, 255, 255, int(min(255, 230 * self.intensidad))))
            g.setColorAt(0.25, c)
            g.setColorAt(1.0, transparente)
            p.setPen(Qt.NoPen)
            p.setBrush(g)
            p.drawEllipse(o, radio, radio)
        # grietas de luz: más con cada golpe
        for k, puntos in enumerate(self.grietas[:self.n_golpes * 3]):
            camino = QPainterPath(o + puntos[0])
            for q in puntos[1:]:
                camino.lineTo(o + q)
            brillo = COLORES[k % 3]
            alfa = int(90 + 140 * min(1.0, self.intensidad + 0.25))
            p.setPen(QPen(QColor(brillo.red(), brillo.green(), brillo.blue(), alfa), 2.2, Qt.SolidLine,
                          Qt.RoundCap, Qt.RoundJoin))
            p.drawPath(camino)
        p.end()
