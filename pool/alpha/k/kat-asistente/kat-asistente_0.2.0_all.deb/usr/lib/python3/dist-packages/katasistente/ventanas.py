"""¿Dónde está la ventana de una app? (para que Kat se meta dentro de ella)

- Windows: se busca la ventana visible cuyo título contiene el nombre de la app
  y se toma su rectángulo real.
- Kat OS (Wayland): las apps no pueden saber dónde están las ventanas de otras.
  KWin abre las ventanas centradas (Placement=Centered en /etc/xdg/kwinrc), así
  que se usa el centro del área libre de la pantalla.
"""

from PySide6.QtCore import QPoint
from PySide6.QtGui import QGuiApplication

from katui import plataforma


def _rect_windows(nombre):
    import ctypes
    from ctypes import wintypes
    usuario = ctypes.windll.user32
    encontrada = []
    buscado = nombre.lower()

    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
    def cada(hwnd, _):
        if not usuario.IsWindowVisible(hwnd):
            return True
        largo = usuario.GetWindowTextLengthW(hwnd)
        if largo == 0:
            return True
        titulo = ctypes.create_unicode_buffer(largo + 1)
        usuario.GetWindowTextW(hwnd, titulo, largo + 1)
        if buscado in titulo.value.lower():
            r = wintypes.RECT()
            if usuario.GetWindowRect(hwnd, ctypes.byref(r)) and r.right - r.left > 80:
                encontrada.append((r.left, r.top, r.right, r.bottom))
                return False
        return True
    usuario.EnumWindows(cada, 0)
    return encontrada[0] if encontrada else None


def centro_de(nombre):
    """Centro (en coordenadas de Qt) de la ventana de la app 'nombre', o None si no se sabe."""
    if not plataforma.ES_WINDOWS or not nombre:
        return None
    try:
        r = _rect_windows(nombre)
    except Exception:
        return None
    if r is None:
        return None
    escala = QGuiApplication.primaryScreen().devicePixelRatio() or 1.0   # Windows da píxeles físicos
    return QPoint(int((r[0] + r[2]) / 2 / escala), int((r[1] + r[3]) / 2 / escala))


def centro_probable():
    """Donde KWin abre las ventanas nuevas: el centro del área libre."""
    return QGuiApplication.primaryScreen().availableGeometry().center()
