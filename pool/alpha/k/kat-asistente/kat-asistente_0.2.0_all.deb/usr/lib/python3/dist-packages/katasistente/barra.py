"""Dónde está la barra de tareas y desde dónde sale Kat.

La barra "le quita" espacio a la pantalla: comparando la pantalla entera con
el área libre se sabe en qué lado está (abajo en el estilo Windows, abajo
con el dock en el estilo Mac, a la izquierda en el estilo Linux...).
"""

from PySide6.QtCore import QPoint

MARGEN = 18


def lado(pantalla, libre):
    """'abajo', 'arriba', 'izquierda' o 'derecha' (QRect de la pantalla y del área libre)."""
    huecos = {
        "abajo": pantalla.bottom() - libre.bottom(),
        "arriba": libre.top() - pantalla.top(),
        "izquierda": libre.left() - pantalla.left(),
        "derecha": pantalla.right() - libre.right(),
    }
    mejor = max(huecos, key=lambda k: (huecos[k], k == "abajo"))
    return mejor if huecos[mejor] > 0 else "abajo"


def posiciones(pantalla, libre, ancho, alto):
    """(lado, punto de salida dentro de la barra, punto final junto a la barra)."""
    l = lado(pantalla, libre)
    if l == "abajo":
        final = QPoint(libre.right() - ancho - MARGEN, libre.bottom() - alto - MARGEN)
        inicio = QPoint(final.x(), pantalla.bottom() - alto // 5)
    elif l == "arriba":
        final = QPoint(libre.right() - ancho - MARGEN, libre.top() + MARGEN)
        inicio = QPoint(final.x(), pantalla.top() - alto * 4 // 5)
    elif l == "izquierda":
        final = QPoint(libre.left() + MARGEN, libre.bottom() - alto - MARGEN)
        inicio = QPoint(pantalla.left() - ancho * 4 // 5, final.y())
    else:
        final = QPoint(libre.right() - ancho - MARGEN, libre.bottom() - alto - MARGEN)
        inicio = QPoint(pantalla.right() - ancho // 5, final.y())
    return l, inicio, final


def franja(pantalla, libre, punto, ancho=560, adentro=140):
    """Zona sobre la barra donde Kat golpea: (lado, zona, barra dentro de la zona, origen del golpe).

    punto: centro de donde saldrá Kat; adentro: cuánto entra la zona en el escritorio.
    """
    from PySide6.QtCore import QRect
    l = lado(pantalla, libre)
    if l == "abajo":
        grosor = max(pantalla.bottom() - libre.bottom(), 40)
        zona = QRect(punto.x() - ancho // 2, pantalla.bottom() - grosor - adentro + 1, ancho, grosor + adentro)
        barra_r = QRect(0, adentro, ancho, grosor)
    elif l == "arriba":
        grosor = max(libre.top() - pantalla.top(), 40)
        zona = QRect(punto.x() - ancho // 2, pantalla.top(), ancho, grosor + adentro)
        barra_r = QRect(0, 0, ancho, grosor)
    elif l == "izquierda":
        grosor = max(libre.left() - pantalla.left(), 40)
        zona = QRect(pantalla.left(), punto.y() - ancho // 2, grosor + adentro, ancho)
        barra_r = QRect(0, 0, grosor, ancho)
    else:
        grosor = max(pantalla.right() - libre.right(), 40)
        zona = QRect(pantalla.right() - grosor - adentro + 1, punto.y() - ancho // 2, grosor + adentro, ancho)
        barra_r = QRect(adentro, 0, grosor, ancho)
    recortada = zona.intersected(pantalla)
    barra_r.translate(zona.topLeft() - recortada.topLeft())     # si se recortó por un borde
    return l, recortada, barra_r, barra_r.center()
