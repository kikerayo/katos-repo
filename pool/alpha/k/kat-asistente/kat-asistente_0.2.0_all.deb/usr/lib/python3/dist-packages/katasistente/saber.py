"""Preguntas de saber («qué es…», «quién fue…») respondidas con Wikipedia en español.

No necesita clave ni cuenta: es la API pública de Wikipedia. Kat dice de dónde
sacó la respuesta y, si no encuentra nada claro, lo dice en vez de inventar.
"""

import json
import re
import urllib.error
import urllib.parse
import urllib.request

API = "https://es.wikipedia.org/w/api.php"
RESUMEN = "https://es.wikipedia.org/api/rest_v1/page/summary/"
AGENTE = "KatOS-Kat/0.2 (https://kikerayo.github.io/katos/)"
MAX_LETRAS = 420

_PREGUNTA = re.compile(
    r"^(?:y\s+|oye\s+|kat\s+)?(?:"
    r"(?:qu[eé]|que)\s+(?:es|son|era|fue|significa|quiere\s+decir)|"
    r"(?:qui[eé]n|quienes|quiénes)\s+(?:es|era|fue|son|fueron|invent[oó]|cre[oó]|descubri[oó]|escribi[oó]|pint[oó])|"
    r"h[aá]blame\s+(?:de|sobre|acerca\s+de)|"
    r"(?:qu[eé]|que)\s+sabes\s+(?:de|sobre)|"
    r"expl[ií]ca(?:me)?(?:\s+(?:qu[eé]|que)\s+(?:es|son))?|"
    r"dime\s+(?:(?:qu[eé]|que)\s+es|(?:qui[eé]n|quien)\s+(?:es|fue)|algo\s+(?:de|sobre))|"
    r"define|definici[oó]n\s+de|significado\s+de"
    r")\s+(?:(?:un|una|unos|unas|el|la|los|las|lo|del|al)\s+)?(?P<tema>.+?)[\s?!.]*$",
    re.IGNORECASE)


class SinConexion(RuntimeError):
    pass


def tema_de(frase):
    """El tema de una pregunta de saber, tal como se escribió, o None si no lo es."""
    t = re.sub(r"[¿¡]", "", (frase or "")).strip()
    m = _PREGUNTA.match(t)
    if not m:
        return None
    tema = m.group("tema").strip(" ,;:\"'«»")
    # «qué es eso», «quién eres»… no son temas de enciclopedia
    if len(tema) < 2 or tema.lower() in {"eso", "esto", "aquello", "tu", "tú", "usted", "kat", "kat os", "esa", "ese"}:
        return None
    return tema


def _pedir(url, abrir):
    peticion = urllib.request.Request(url, headers={"User-Agent": AGENTE, "Accept": "application/json"})
    try:
        with abrir(peticion, timeout=8) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise SinConexion("Wikipedia respondió con error %d" % e.code) from e
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        raise SinConexion("Sin conexión con Wikipedia") from e


def recortar(texto, maximo=MAX_LETRAS):
    """Las primeras frases completas que quepan en 'maximo' letras."""
    texto = re.sub(r"\s+", " ", texto or "").strip()
    if len(texto) <= maximo:
        return texto
    frases = re.split(r"(?<=[.!?])\s+", texto)
    salida = ""
    for f in frases:
        if len(salida) + len(f) + 1 > maximo:
            break
        salida = (salida + " " + f).strip()
    return salida or texto[:maximo - 1].rsplit(" ", 1)[0] + "…"


def buscar(tema, abrir=urllib.request.urlopen):
    """(resumen, url) del artículo que mejor encaja con 'tema', o None si no hay uno claro.
    Lanza SinConexion si no se puede consultar."""
    consulta = urllib.parse.urlencode({"action": "query", "list": "search", "srsearch": tema,
                                       "srlimit": 1, "format": "json", "utf8": 1})
    datos = _pedir(API + "?" + consulta, abrir) or {}
    resultados = datos.get("query", {}).get("search", [])
    if not resultados:
        return None
    titulo = resultados[0]["title"]
    ficha = _pedir(RESUMEN + urllib.parse.quote(titulo.replace(" ", "_"), safe=""), abrir)
    if not ficha or ficha.get("type") == "disambiguation" or not ficha.get("extract"):
        return None
    url = ficha.get("content_urls", {}).get("desktop", {}).get("page") or \
        "https://es.wikipedia.org/wiki/" + urllib.parse.quote(titulo.replace(" ", "_"))
    return recortar(ficha["extract"]), url
