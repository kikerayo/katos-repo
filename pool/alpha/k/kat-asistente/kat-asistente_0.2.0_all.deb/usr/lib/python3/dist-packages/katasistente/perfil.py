"""Cómo es tu Kat: palabra de activación, si tienes micrófono, su voz y su diseño.
Se elige la primera vez.

Archivo: ~/.config/katos/asistente/perfil.json
"""

import json
import os
import re

from katui import plataforma

PALABRAS = ["Hey Kat", "Oye Kat", "Kat"]

# diseño de la canica: nombre bonito y los 5 colores de sus ondas (RGB)
DISENOS = {
    "kat": ("Kat (rojo, azul y blanco)", [(255, 59, 92), (168, 85, 247), (59, 130, 246), (34, 211, 238),
                                         (255, 255, 255)]),
    "galaxia": ("Galaxia", [(236, 72, 153), (139, 92, 246), (99, 102, 241), (192, 132, 252), (255, 255, 255)]),
    "fuego": ("Fuego", [(239, 68, 68), (249, 115, 22), (250, 204, 21), (251, 146, 60), (255, 255, 255)]),
    "hielo": ("Hielo", [(56, 189, 248), (59, 130, 246), (165, 243, 252), (14, 165, 233), (255, 255, 255)]),
    "menta": ("Menta", [(52, 211, 153), (16, 185, 129), (45, 212, 191), (163, 230, 53), (255, 255, 255)]),
}

# voz: id de una voz de katasistente.voz ("" = Kat no habla, solo escribe)
PREDETERMINADO = {"configurada": False, "palabra": "Hey Kat", "microfono": True, "voz": "", "diseno": "kat"}


def archivo():
    return os.path.join(plataforma.carpeta_config("asistente"), "perfil.json")


def leer():
    d = dict(PREDETERMINADO)
    try:
        with open(archivo(), encoding="utf-8") as f:
            guardado = json.load(f)
        if isinstance(guardado, dict):
            d.update({k: guardado[k] for k in PREDETERMINADO if k in guardado})
    except (OSError, ValueError):
        pass
    if not isinstance(d["voz"], str) or len(d["voz"]) > 120:
        d["voz"] = ""
    d["microfono"] = bool(d["microfono"])
    if d["diseno"] not in DISENOS:
        d["diseno"] = "kat"
    return d


def validar_palabra(texto):
    """La palabra de activación limpia, o ValueError con el motivo."""
    t = re.sub(r"\s+", " ", (texto or "").strip())
    if not 2 <= len(t) <= 24:
        raise ValueError("La palabra de activación debe tener entre 2 y 24 letras")
    if not re.fullmatch(r"[\wáéíóúüñÁÉÍÓÚÜÑ ¡!¿?,.'-]+", t):
        raise ValueError("Usa solo letras, números y espacios")
    return t


def guardar(palabra, microfono, voz, diseno):
    d = {"configurada": True, "palabra": validar_palabra(palabra), "microfono": bool(microfono),
         "voz": voz if isinstance(voz, str) and len(voz) <= 120 else "",
         "diseno": diseno if diseno in DISENOS else "kat"}
    with open(archivo(), "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    return d


def primera_vez():
    return not leer()["configurada"]
