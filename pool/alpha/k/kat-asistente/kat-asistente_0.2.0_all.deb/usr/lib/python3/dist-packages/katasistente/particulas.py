"""Kat se desintegra en pedacitos (bits) que vuelan a la barra de tareas al cerrarla.

Se toma la imagen de la canica, se parte en cuadritos con su color y cada uno
vuela (con un pequeño remolino y a su ritmo) hacia el punto de la barra de
donde sale Kat, encogiéndose y apagándose. Al llegar todos, un destello.
La capa no recibe el ratón y se cierra sola.
"""

import math
import random

from PySide6.QtCore import QPointF, QRect, Qt, QTimer
from PySide6.QtGui import QColor, QPainter, QRadialGradient
from PySide6.QtWidgets import QWidget

PASO = 7                 # tamaño de cada cuadrito (px)
DURACION = (0.55, 0.95)  # segundos que tarda cada uno
RETRASO = 0.35           # los de arriba salen antes, como si se deshiciera


class Desintegrar(QWidget):
    def __init__(self, imagen, origen, destino, semilla=None):
        """imagen: QImage de la canica; origen: su esquina en la pantalla; destino: punto de la barra."""
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
                         | Qt.WindowTransparentForInput)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_ShowWithoutActivating)
        azar = random.Random(semilla)
        zona = QRect(origen, imagen.size()).united(QRect(destino.x() - 60, destino.y() - 60, 120, 120))
        zona.adjust(-40, -40, 40, 40)
        self.setGeometry(zona)
        self.destino = QPointF(destino - zona.topLeft())
        self.bits = []
        alto = max(1, imagen.height())
        for y in range(0, imagen.height(), PASO):
            for x in range(0, imagen.width(), PASO):
                c = imagen.pixelColor(x + PASO // 2 if x + PASO // 2 < imagen.width() else x,
                                      y + PASO // 2 if y + PASO // 2 < imagen.height() else y)
                if c.alpha() < 50:
                    continue
                inicio = QPointF(origen.x() - zona.x() + x, origen.y() - zona.y() + y)
                self.bits.append({
                    "inicio": inicio, "color": c,
                    "retraso": RETRASO * (y / alto) + azar.uniform(0, 0.12),
                    "duracion": azar.uniform(*DURACION),
                    "giro": azar.uniform(-1.0, 1.0) * 60,
                })
        self.t = 0.0
        self.al_terminar = None
        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self._tic)
        self.fin = max((b["retraso"] + b["duracion"] for b in self.bits), default=0.0)

    def empezar(self, al_terminar=None):
        self.al_terminar = al_terminar
        self.show()
        self.reloj.start(16)

    def _tic(self):
        self.t += 0.016
        if self.t > self.fin + 0.35:
            self.reloj.stop()
            self.close()
            if self.al_terminar:
                # un instante después: quien la creó puede soltarla sin borrarla mientras trabaja
                QTimer.singleShot(0, self.al_terminar)
                self.al_terminar = None
            return
        self.update()

    def posicion(self, b, u):
        """Dónde está un cuadrito con avance u (0..1): curva con remolino hacia la barra."""
        e = u * u * (3 - 2 * u)                      # suave al salir y al llegar
        x = b["inicio"].x() + (self.destino.x() - b["inicio"].x()) * e
        y = b["inicio"].y() + (self.destino.y() - b["inicio"].y()) * e
        remolino = math.sin(math.pi * u) * b["giro"]
        return QPointF(x + remolino, y - abs(remolino) * 0.4)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setPen(Qt.NoPen)
        for b in self.bits:
            u = (self.t - b["retraso"]) / b["duracion"]
            if u >= 1:
                continue
            u = max(0.0, u)
            q = self.posicion(b, u)
            lado = PASO * (1.0 - 0.75 * u)
            c = QColor(b["color"])
            c.setAlpha(int(c.alpha() * (1.0 - 0.7 * u)))
            p.setBrush(c)
            p.drawRect(int(q.x()), int(q.y()), max(1, int(lado)), max(1, int(lado)))
        # destello al final, cuando los bits entran en la barra
        llegada = (self.t - self.fin * 0.7) / 0.5
        if 0 < llegada < 1:
            fuerza = math.sin(math.pi * llegada)
            g = QRadialGradient(self.destino, 70)
            g.setColorAt(0, QColor(255, 255, 255, int(220 * fuerza)))
            g.setColorAt(0.4, QColor(168, 85, 247, int(150 * fuerza)))
            g.setColorAt(1, QColor(59, 130, 246, 0))
            p.setBrush(g)
            p.drawEllipse(self.destino, 70, 70)
        p.end()
