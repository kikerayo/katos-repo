"""Una sola Kat por usuario.

La primera Kat abre un "buzón" local (QLocalServer, solo para tu usuario). Si la
llaman otra vez, la nueva Kat deja un mensaje en ese buzón, espera el "ok" y se
cierra; la que ya estaba sale (de la ventana donde se había metido, o de la
barra) y, si traía una pregunta, la responde.
"""

import getpass
import time

try:
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    DISPONIBLE = True
except ImportError:               # sin python3-pyside6.qtnetwork: cada Kat va por su cuenta
    DISPONIBLE = False

ESPERA_MS = 1500
FIN = b"\0"


def nombre_buzon():
    try:
        usuario = getpass.getuser()
    except Exception:
        usuario = "kat"
    return "kat-asistente-" + "".join(c for c in usuario if c.isalnum() or c in "-_")


def avisar(pregunta="", buzon=None):
    """Si ya hay una Kat, le pide que salga (con la pregunta) y devuelve True."""
    if not DISPONIBLE:
        return False
    s = QLocalSocket()
    s.connectToServer(buzon or nombre_buzon())
    if not s.waitForConnected(400):
        return False
    s.write(("salir\n" + (pregunta or "")[:500]).encode("utf-8") + FIN)
    s.flush()
    limite = time.monotonic() + ESPERA_MS / 1000
    respuesta = b""
    while time.monotonic() < limite and b"ok" not in respuesta:   # esperar el "ok" (así el mensaje llegó)
        s.waitForBytesWritten(50)
        if s.waitForReadyRead(50):
            respuesta += bytes(s.readAll())
    s.disconnectFromServer()
    return True                                    # había otra Kat (aunque no contestara a tiempo)


class Buzon:
    """Escucha los avisos de otras Kats y llama a al_llamar(pregunta)."""

    def __init__(self, al_llamar, buzon=None):
        self.al_llamar = al_llamar
        self.nombre = buzon or nombre_buzon()
        self.conexiones = []
        self.ok = False
        if not DISPONIBLE:
            return
        QLocalServer.removeServer(self.nombre)            # por si quedó uno viejo de una Kat que se cerró mal
        self.servidor = QLocalServer()
        self.servidor.setSocketOptions(QLocalServer.UserAccessOption)   # solo tu usuario
        self.servidor.newConnection.connect(self._nuevo)
        self.ok = self.servidor.listen(self.nombre)

    def _nuevo(self):
        while self.servidor.hasPendingConnections():
            self._atender(self.servidor.nextPendingConnection())

    def _atender(self, s):
        recibido = bytearray()
        self.conexiones.append(s)

        def leer():
            recibido.extend(bytes(s.readAll()))
            if FIN in recibido:
                mensaje = bytes(recibido[:recibido.index(FIN)])
                recibido.clear()
                s.write(b"ok")
                s.flush()
                s.disconnectFromServer()                 # contestado: colgar (cuando salga el "ok")
                orden, _, pregunta = mensaje.decode("utf-8", "replace").partition("\n")
                if orden == "salir":
                    self.al_llamar(pregunta.strip())

        def colgada():
            if s in self.conexiones:
                self.conexiones.remove(s)
            s.deleteLater()
        s.readyRead.connect(leer)
        s.disconnected.connect(colgada)
        leer()                                            # lo que ya hubiera llegado

    def cerrar(self):
        for s in list(self.conexiones):
            s.abort()
        self.conexiones.clear()
        if DISPONIBLE:
            self.servidor.close()
