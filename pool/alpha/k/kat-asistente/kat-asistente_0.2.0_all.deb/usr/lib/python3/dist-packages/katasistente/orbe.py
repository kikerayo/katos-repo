"""La orbe de Kat: una canica de vidrio oscuro con orejas de gato y ondas de
color dentro (rojo, violeta, azul y blanco), dibujada con QPainter.

Estados (cambian la animación):
  reposo     ondas suaves y lentas
  pensando   ondas rápidas que se cruzan
  hablando   ondas altas que suben y bajan con el ritmo de la voz
  escuchando ondas que respiran despacio mientras le hablas
Además: crece con un rebote suave (resorte) al salir de la barra, y puede
mostrar el logo de una app dentro, con un anillo de carga, mientras se abre.
"""

import math

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import QColor, QConicalGradient, QLinearGradient, QPainter, QPainterPath, QPen, QRadialGradient
from PySide6.QtWidgets import QWidget

REPOSO, PENSANDO, HABLANDO, ESCUCHANDO = "reposo", "pensando", "hablando", "escuchando"

# (color, fase, frecuencia, desplazamiento vertical relativo)
ONDAS = [
    (QColor(255, 59, 92), 0.0, 1.0, -0.10),     # rojo
    (QColor(168, 85, 247), 1.7, 1.25, -0.03),   # violeta Kat
    (QColor(59, 130, 246), 3.1, 0.9, 0.05),     # azul
    (QColor(34, 211, 238), 4.4, 1.4, 0.09),     # cian
    (QColor(255, 255, 255), 2.4, 1.1, 0.02),    # blanco (brillo central)
]


class Orbe(QWidget):
    def __init__(self, tam=180):
        super().__init__()
        self.setMinimumSize(tam, tam)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.estado = REPOSO
        self.t = 0.0
        self.energia = 0.25          # amplitud actual de las ondas (sube al hablar)
        self.escala, self._vel, self.escala_obj = 1.0, 0.0, 1.0      # resorte para crecer/encoger
        self.logo, self.logo_t, self.logo_obj = None, 0.0, 0.0      # logo de la app que se abre
        self.ondas = list(ONDAS)                                     # colores según el diseño elegido
        self.reloj = QTimer(self)
        self.reloj.timeout.connect(self._tic)
        self.reloj.start(16)         # ~60 imágenes por segundo

    def poner_estado(self, estado):
        self.estado = estado

    def poner_diseno(self, colores):
        """Cambia los colores de las ondas (lista de 5 colores RGB del diseño)."""
        self.ondas = [(QColor(*c), fase, frec, desp) for c, (_, fase, frec, desp) in zip(colores, ONDAS)]

    def crecer(self, desde=0.35):
        """Aparece pequeña y crece con un rebote suave."""
        self.escala, self._vel, self.escala_obj = desde, 0.0, 1.0

    def encoger(self):
        self.escala_obj = 0.3

    def mostrar_logo(self, pixmap):
        self.logo, self.logo_obj = pixmap, 1.0

    def quitar_logo(self):
        self.logo_obj = 0.0

    def _tic(self):
        paso = 0.016
        self.t += paso * (2.6 if self.estado == PENSANDO else 1.0)
        objetivo = {REPOSO: 0.25, PENSANDO: 0.45, HABLANDO: 0.55 + 0.35 * abs(math.sin(self.t * 7.3)),
                    ESCUCHANDO: 0.35 + 0.12 * math.sin(self.t * 3.0)}[self.estado]
        self.energia += (objetivo - self.energia) * 0.08
        # resorte (con un poquito de rebote) para la escala
        self._vel = (self._vel + (self.escala_obj - self.escala) * 0.12) * 0.74
        self.escala += self._vel
        self.logo_t += (self.logo_obj - self.logo_t) * 0.12
        if self.logo_obj == 0 and self.logo_t < 0.01:
            self.logo = None
        self.update()

    # --- dibujo -----------------------------------------------------------------
    def _oreja(self, c, r, lado):
        """Oreja de vidrio (triángulo redondeado) detrás de la canica."""
        base_x = c.x() + lado * r * 0.52
        mov = math.sin(self.t * 2.0 + lado) * r * 0.03 * (1 + self.energia)
        punta = QPointF(base_x + lado * r * 0.2, c.y() - r * 1.36 + mov)
        path = QPainterPath()
        path.moveTo(base_x - lado * r * 0.45, c.y() - r * 0.62)
        path.quadTo(punta.x() - lado * r * 0.05, punta.y() + r * 0.1, punta.x(), punta.y())
        path.quadTo(punta.x() + lado * r * 0.08, punta.y() + r * 0.25, base_x + lado * r * 0.46, c.y() - r * 0.3)
        path.closeSubpath()
        return path, punta

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        lado = min(w, h)
        r = lado * 0.31
        c = QPointF(w / 2, h / 2 + lado * 0.07)
        p.setPen(Qt.NoPen)
        if abs(self.escala - 1.0) > 0.001:
            p.translate(c)
            p.scale(self.escala, self.escala)
            p.translate(-c)

        # resplandor exterior muy suave (de los colores de dentro)
        rh = min(r * 1.6, lado / 2 - lado * 0.04)
        halo = QRadialGradient(c, rh)
        halo.setColorAt(r / rh * 0.95, QColor(120, 80, 255, int(50 + 60 * self.energia)))
        halo.setColorAt(1.0, QColor(120, 80, 255, 0))
        p.setBrush(halo)
        p.drawEllipse(c, rh, rh)

        # orejas de vidrio
        for lado_x in (-1, 1):
            path, punta = self._oreja(c, r, lado_x)
            vidrio = QLinearGradient(punta, QPointF(punta.x(), c.y() - r * 0.3))
            vidrio.setColorAt(0, QColor(70, 50, 110, 230))
            vidrio.setColorAt(1, QColor(12, 10, 22, 240))
            p.setBrush(vidrio)
            p.setPen(QPen(QColor(200, 180, 255, 120), max(1.0, r * 0.025)))
            p.drawPath(path)
        p.setPen(Qt.NoPen)

        # cuerpo de vidrio oscuro
        cuerpo = QRadialGradient(QPointF(c.x(), c.y() + r * 0.1), r)
        cuerpo.setColorAt(0.0, QColor(10, 8, 18, 250))
        cuerpo.setColorAt(0.82, QColor(14, 11, 26, 250))
        cuerpo.setColorAt(1.0, QColor(40, 32, 70, 255))
        p.setBrush(cuerpo)
        p.drawEllipse(c, r, r)

        # ondas de color dentro (se suman como la luz)
        p.save()
        recorte = QPainterPath()
        recorte.addEllipse(c, r * 0.985, r * 0.985)
        p.setClipPath(recorte)
        p.setCompositionMode(QPainter.CompositionMode_Plus)
        pasos = 48
        for color, fase, frec, desp in self.ondas:
            amp = r * (0.10 + 0.22 * self.energia)
            grosor = r * (0.05 + 0.10 * self.energia) * (0.6 if color.red() == 255 and color.green() == 255 else 1)
            centro_y = c.y() + desp * r
            arriba, abajo = [], []
            for i in range(pasos + 1):
                u = i / pasos
                x = c.x() - r + 2 * r * u
                envolvente = math.sin(math.pi * u) ** 1.6          # se afina hacia los bordes
                y = centro_y + amp * envolvente * math.sin(frec * 6.0 * u + self.t * 2.2 + fase)
                g = grosor * envolvente
                arriba.append(QPointF(x, y - g))
                abajo.append(QPointF(x, y + g))
            onda = QPainterPath(arriba[0])
            for q in arriba[1:]:
                onda.lineTo(q)
            for q in reversed(abajo):
                onda.lineTo(q)
            onda.closeSubpath()
            degradado = QLinearGradient(c.x() - r, 0, c.x() + r, 0)
            transparente = QColor(color.red(), color.green(), color.blue(), 0)
            degradado.setColorAt(0.0, transparente)
            degradado.setColorAt(0.5, QColor(color.red(), color.green(), color.blue(), 210))
            degradado.setColorAt(1.0, transparente)
            p.setBrush(degradado)
            p.drawPath(onda)
        p.restore()

        if self.logo is not None and self.logo_t > 0.01:
            self._dibujar_logo(p, c, r)

        # borde de luz (efecto vidrio: más brillante en el contorno)
        borde = QRadialGradient(c, r)
        borde.setColorAt(0.80, QColor(255, 255, 255, 0))
        borde.setColorAt(0.97, QColor(220, 210, 255, 70))
        borde.setColorAt(1.0, QColor(255, 255, 255, 120))
        p.setBrush(borde)
        p.drawEllipse(c, r, r)
        # reflejos de color en los lados, como una canica
        for angulo, color in ((200, QColor(255, 80, 110, 55)), (-20, QColor(80, 160, 255, 55))):
            p.setPen(QPen(color, r * 0.035, Qt.SolidLine, Qt.RoundCap))
            p.setBrush(Qt.NoBrush)
            p.drawArc(QRectF(c.x() - r * 0.95, c.y() - r * 0.95, r * 1.9, r * 1.9), angulo * 16, 50 * 16)
        p.setPen(Qt.NoPen)
        # brillo de arriba
        brillo = QRadialGradient(QPointF(c.x() - r * 0.3, c.y() - r * 0.62), r * 0.5)
        brillo.setColorAt(0, QColor(255, 255, 255, 90))
        brillo.setColorAt(1, QColor(255, 255, 255, 0))
        p.setBrush(brillo)
        p.drawEllipse(QPointF(c.x() - r * 0.3, c.y() - r * 0.62), r * 0.55, r * 0.32)
        p.end()

    def _dibujar_logo(self, p, c, r):
        """El logo de la app dentro de la canica, con un anillo de carga que gira."""
        t = self.logo_t
        p.save()
        p.setBrush(QColor(8, 6, 16, int(170 * t)))            # las ondas se apagan detrás del logo
        p.drawEllipse(c, r * 0.98, r * 0.98)
        anillo = QConicalGradient(c, -self.t * 300)
        anillo.setColorAt(0.0, QColor(203, 164, 255, int(230 * t)))
        anillo.setColorAt(0.35, QColor(139, 92, 246, int(120 * t)))
        anillo.setColorAt(0.7, QColor(139, 92, 246, 0))
        anillo.setColorAt(1.0, QColor(203, 164, 255, int(230 * t)))
        p.setPen(QPen(anillo, r * 0.07, Qt.SolidLine, Qt.RoundCap))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(c, r * 0.8, r * 0.8)
        lado = r * 0.95 * (0.6 + 0.4 * t)
        p.setOpacity(t)
        p.drawPixmap(QRectF(c.x() - lado / 2, c.y() - lado / 2, lado, lado), self.logo,
                     QRectF(self.logo.rect()))
        p.restore()
