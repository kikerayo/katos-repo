"""Cálculos y conversiones de Kat, sin usar eval (solo números y operaciones)."""

import ast
import math
import operator
import re

_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg, ast.UAdd: operator.pos}

PALABRAS = [
    (r"\braiz cuadrada de\b|\braiz de\b", " sqrt "),
    (r"\bdividido (?:entre|por)\b|\bentre\b", " / "),
    (r"\bmultiplicado por\b|\bpor\b", " * "),
    (r"\belevado a(?:l)?\b|\bal cuadrado\b", None),
    (r"\bmas\b", " + "),
    (r"\bmenos\b", " - "),
]


def _evaluar(nodo):
    if isinstance(nodo, ast.Expression):
        return _evaluar(nodo.body)
    if isinstance(nodo, ast.Constant) and isinstance(nodo.value, (int, float)):
        return nodo.value
    if isinstance(nodo, ast.BinOp) and type(nodo.op) in _OPS:
        a, b = _evaluar(nodo.left), _evaluar(nodo.right)
        if isinstance(nodo.op, ast.Pow) and abs(b) > 100:
            raise ValueError("número demasiado grande")
        return _OPS[type(nodo.op)](a, b)
    if isinstance(nodo, ast.UnaryOp) and type(nodo.op) in _OPS:
        return _OPS[type(nodo.op)](_evaluar(nodo.operand))
    if isinstance(nodo, ast.Call) and isinstance(nodo.func, ast.Name) and nodo.func.id == "sqrt" and len(nodo.args) == 1:
        return math.sqrt(_evaluar(nodo.args[0]))
    raise ValueError("no es una cuenta")


def formato(n):
    if isinstance(n, float) and n.is_integer():
        n = int(n)
    if isinstance(n, int):
        return "{:,}".format(n).replace(",", ".")
    return ("%.4f" % n).rstrip("0").rstrip(".").replace(".", ",")


def calcular(texto):
    """'cuanto es 25 por 4' -> 100.  Devuelve el número o None si no es una cuenta."""
    t = texto
    t = re.sub(r"^(cuanto es|cuanto da|calcula|calculame|resuelve|cuanto son)\s+", "", t.strip())
    m = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*(?:%|por ciento) de\s*(\d+(?:[.,]\d+)?)", t)
    if m:
        return float(m.group(1).replace(",", ".")) * float(m.group(2).replace(",", ".")) / 100
    t = re.sub(r"(\d+(?:[.,]\d+)?)\s*al cuadrado", r"(\1)**2", t)
    t = re.sub(r"\belevado a(?:l)?\b", "**", t)
    for patron, cambio in PALABRAS:
        if cambio:
            t = re.sub(patron, cambio, t)
    t = re.sub(r"(?<=\d)\s*x\s*(?=\d)", "*", t)
    t = re.sub(r"(\d),(\d)", r"\1.\2", t)
    t = re.sub(r"\bsqrt\s+(\d+(?:\.\d+)?)", r"sqrt(\1)", t)
    if not re.search(r"\d", t) or not re.fullmatch(r"[\d\s.+\-*/%()sqrt]+", t):
        return None
    try:
        return _evaluar(ast.parse(t.strip(), mode="eval"))
    except (ValueError, SyntaxError, ZeroDivisionError, TypeError, OverflowError):
        return None


# unidad: (magnitud, factor a la unidad base)
UNIDADES = {
    "km": ("largo", 1000), "kilometros": ("largo", 1000), "kilometro": ("largo", 1000),
    "m": ("largo", 1), "metros": ("largo", 1), "metro": ("largo", 1),
    "cm": ("largo", 0.01), "centimetros": ("largo", 0.01), "centimetro": ("largo", 0.01),
    "millas": ("largo", 1609.344), "milla": ("largo", 1609.344),
    "pies": ("largo", 0.3048), "pie": ("largo", 0.3048),
    "pulgadas": ("largo", 0.0254), "pulgada": ("largo", 0.0254),
    "kg": ("peso", 1), "kilos": ("peso", 1), "kilogramos": ("peso", 1), "kilo": ("peso", 1),
    "g": ("peso", 0.001), "gramos": ("peso", 0.001),
    "libras": ("peso", 0.45359237), "libra": ("peso", 0.45359237),
    "litros": ("volumen", 1), "litro": ("volumen", 1),
    "galones": ("volumen", 3.785411784), "galon": ("volumen", 3.785411784),
}


def convertir(texto):
    """'convierte 10 km a millas' / 'cuantas libras son 5 kg' -> (valor, unidad) o None."""
    m = re.search(r"(-?\d+(?:[.,]\d+)?)\s*(?:grados\s*)?(c|f|celsius|fahrenheit)\b.*?\b(?:a|en)\s*(?:grados\s*)?"
                  r"(c|f|celsius|fahrenheit)\b", texto)
    if m:
        v = float(m.group(1).replace(",", "."))
        de, a = m.group(2)[0], m.group(3)[0]
        if de == a:
            return v, "°" + a.upper()
        return (v * 9 / 5 + 32, "°F") if de == "c" else ((v - 32) * 5 / 9, "°C")
    nombres = "|".join(sorted(UNIDADES, key=len, reverse=True))
    m = re.search(r"(-?\d+(?:[.,]\d+)?)\s*(%s)\b.*?\b(?:a|en)\s+(%s)\b" % (nombres, nombres), texto)
    if not m:
        m2 = re.search(r"cuant[oa]s\s+(%s)\s+(?:son|hay en|tiene)\s+(-?\d+(?:[.,]\d+)?)\s*(%s)\b" % (nombres, nombres), texto)
        if not m2:
            return None
        a, v, de = m2.group(1), m2.group(2), m2.group(3)
    else:
        v, de, a = m.group(1), m.group(2), m.group(3)
    if UNIDADES[de][0] != UNIDADES[a][0]:
        return None
    return float(v.replace(",", ".")) * UNIDADES[de][1] / UNIDADES[a][1], a
