"""Punto de entrada de Kat.

Uso: kat-asistente                 (la primera vez: golpes en la barra y configuración)
     kat-asistente 'qué hora es'   (preguntar directo)
     kat-asistente --demo N        (repite N veces la animación de salir de la barra)
     kat-asistente --primera-vez   (vuelve a ver la llegada y la configuración)
"""

import sys

from . import APP_ID, VERSION


def demostrar(v, veces):
    """Kat sale de la barra, saluda, vuelve a meterse... 'veces' veces; la última se queda abierta."""
    from PySide6.QtCore import QTimer

    def ronda(n):
        v.aparecer()
        v._decir("¡Hola! Esta es mi animación (%d de %d)." % (n, veces))
        if n < veces:
            QTimer.singleShot(2600, lambda: v.volver_a_barra(lambda: QTimer.singleShot(700, lambda: ronda(n + 1))))
    ronda(1)


def llegada(v):
    """La primera vez: Kat golpea la barra desde dentro, sale y pide configurarla."""
    from PySide6.QtCore import QPoint
    from PySide6.QtGui import QGuiApplication

    from katui import sonido

    from . import barra
    from .golpes import GolpesBarra

    pantalla = QGuiApplication.primaryScreen()
    _lado, _inicio, final = barra.posiciones(pantalla.geometry(), pantalla.availableGeometry(),
                                             v.width(), v.height())
    centro = QPoint(final.x() + v.width() // 2, final.y() + v.height() // 2)
    v._golpes = GolpesBarra(centro, sonar=sonido.reproducir)

    def salir():
        v.aparecer()
        v.configurar_primera_vez()
    v._golpes.empezar(al_terminar=salir)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    if "--texto" in argv:                      # sin ventana, para la terminal y las pruebas
        from . import comandos
        frase = " ".join(argv[argv.index("--texto") + 1:])
        r = comandos.responder(frase)
        print(r.texto)
        return 0 if r.resultado.estado != "fallo" else 1
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaKat

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    pregunta = " ".join(a for a in argv if not a.startswith("-") and not a.isdigit())
    especial = "--demo" in argv or "--primera-vez" in argv
    from . import unica
    if not especial and unica.avisar(pregunta):
        return 0                               # ya había una Kat: ella sale y responde
    app.setQuitOnLastWindowClosed(False)       # escondida dentro de una app, Kat sigue viva
    v = VentanaKat()
    v._buzon = unica.Buzon(v.llamar)
    if "--demo" in argv:                       # demostración: sale de la barra y vuelve, N veces
        i = argv.index("--demo")
        veces = int(argv[i + 1]) if i + 1 < len(argv) and argv[i + 1].isdigit() else 2
        demostrar(v, veces)
        return app.exec()
    from . import perfil
    if "--primera-vez" in argv or (perfil.primera_vez() and not pregunta):
        llegada(v)
        return app.exec()
    v.mostrar_en_esquina()
    if pregunta:
        v.preguntar(pregunta)
    return app.exec()
