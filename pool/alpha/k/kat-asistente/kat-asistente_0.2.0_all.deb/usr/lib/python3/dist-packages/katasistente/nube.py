"""Kat Cloud AI: respuestas de una IA en la nube (Groq), OPCIONAL.

- Solo se usa si el usuario lo activa y pone su propia clave de Groq
  (gratis en https://console.groq.com/keys). Kat nunca crea cuentas ni claves.
- Solo se envían las preguntas que Kat no sabe responder sola.
- La clave se guarda en la carpeta de configuración del usuario
  (~/.config/katos/asistente/nube.json, con permisos solo para él), o se
  toma de la variable de entorno GROQ_API_KEY.
- Si se acaba el límite gratuito del día, se avisa y Kat sigue con lo suyo.
"""

import json
import os
import re
import urllib.error
import urllib.request

from katui import plataforma

URL = "https://api.groq.com/openai/v1/chat/completions"
# Groq retira modelos con el tiempo (16/11/2026: ya no existía llama-3.3-70b-versatile).
# Si uno ya no existe, Kat prueba el siguiente y recuerda el que funcionó.
MODELOS = ["openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"]
MODELO = MODELOS[0]
HISTORIAL = 12             # mensajes anteriores que se envían (6 preguntas con su respuesta)
SISTEMA = (
    "Eres Kat, la asistente de Kat OS. Responde SIEMPRE en español, en 2 a 4 frases, amable y clara, "
    "para alguien que no es experto. Escribe texto normal: NADA de Markdown (sin **, #, listas ni tablas).\n"
    "Datos reales de Kat OS (no añadas otros):\n"
    "- Kat OS Desktop es un sistema operativo independiente en versión alpha (1.0.0-alpha), en desarrollo.\n"
    "- Está basado en Debian 13 con el escritorio Plasma, con identidad y apps propias Kat: Kat Files, "
    "Kat Store (apps de Flathub y de Kat Studios, como KatLauncher), Kat Settings, Kat Security, "
    "Kat Update Center, Kat Bienvenida, KatMoji, Kat Compat (abre programas de Windows con Wine), "
    "KatSafety (avisos de sismos y desastres), Kat Rostro (desbloqueo con la cara), Kat Phone ID "
    "(desbloqueo con un botón en el teléfono) y tú, Kat.\n"
    "- Las apps y el sistema de Kat se actualizan solos desde su repositorio firmado. Se descarga gratis en "
    "https://kikerayo.github.io/katos/ y pide un PC de 64 bits con 4 GB de RAM.\n"
    "- Lo hace su autor de forma independiente. NO sabes su nombre: nunca inventes nombres de personas, "
    "empresas, fechas ni cifras sobre Kat OS.\n"
    "- Tú, Kat, eres una canica con orejas de gato. Sin la nube sabes: abrir apps, hora, clima, cuentas, "
    "conversiones, temporizadores, volumen, modo oscuro/claro, buscar en internet y en Kat Store.\n"
    "Acciones: si la persona te pide HACER algo de esa lista en su equipo, responde en una frase qué vas a "
    "hacer y añade al final una línea aparte exactamente así: ORDEN: <orden>. Formas válidas: «abre <app o "
    "programa>», «busca <app> en la tienda», «avísame en <n> minutos», «volumen al <n>», «sube el volumen», "
    "«baja el volumen», «silencia», «modo oscuro», «modo claro», «bloquea la pantalla», «clima en <ciudad>», "
    "«busca en internet <texto>». Kat la hace de verdad. Una sola ORDEN y solo si te lo pidieron; "
    "nunca digas que hiciste algo que no está en esa lista.\n"
    "Usa la conversación anterior para entender a qué se refiere la persona (por ejemplo «¿y en inglés?»). "
    "Si no sabes algo con seguridad, dilo claramente en vez de inventarlo."
)


def sistema(ahora=None):
    """Las instrucciones de Kat con la fecha y hora actuales (para «qué día es», «cuánto falta para…»)."""
    import datetime
    ahora = ahora or datetime.datetime.now()
    dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
    return SISTEMA + "\nAhora es %s %s a las %s." % (dias[ahora.weekday()], ahora.strftime("%d/%m/%Y"),
                                                     ahora.strftime("%H:%M"))


class ErrorNube(RuntimeError):
    """Fallo al hablar con la IA (sin internet, clave mala...). El mensaje es para el usuario."""


class LimiteDiario(ErrorNube):
    """Se acabaron los tokens gratuitos del día."""


def _archivo():
    return os.path.join(plataforma.carpeta_config("asistente"), "nube.json")


def leer_config():
    try:
        with open(_archivo(), encoding="utf-8") as f:
            datos = json.load(f)
    except (OSError, ValueError):
        datos = {}
    clave = os.environ.get("GROQ_API_KEY") or datos.get("clave", "")
    return {"activado": bool(datos.get("activado")) and bool(clave), "clave": clave,
            "modelo": datos.get("modelo") or MODELO, "sonidos": datos.get("sonidos", True)}


def guardar_config(activado, clave, modelo=MODELO, sonidos=None):
    ruta = _archivo()
    if sonidos is None:                      # conservar la opción de sonidos si no se cambia
        sonidos = leer_config().get("sonidos", True)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump({"activado": bool(activado), "clave": (clave or "").strip(), "modelo": modelo,
                   "sonidos": bool(sonidos)}, f)
    try:
        os.chmod(ruta, 0o600)             # solo el usuario puede leer su clave
    except OSError:
        pass


def disponible():
    return leer_config()["activado"]


class _ModeloRetirado(ErrorNube):
    pass


def preguntar(frase, historial=(), config=None, abrir=urllib.request.urlopen):
    """Pregunta a la IA. historial: [(rol, texto)] de la conversación (rol: user/assistant)."""
    config = config or leer_config()
    if not config["clave"]:
        raise ErrorNube("Falta la clave de Groq")
    candidatos = [config["modelo"]] + [m for m in MODELOS if m != config["modelo"]]
    for modelo in candidatos:
        try:
            texto = _preguntar_a(modelo, frase, historial, config["clave"], abrir)
        except _ModeloRetirado:
            continue
        if modelo != config["modelo"] and config.get("guardar", True) and leer_config()["clave"] == config["clave"]:
            guardar_config(True, config["clave"], modelo)      # recordar el que funciona
        return texto
    raise ErrorNube("Ningún modelo de IA de la lista existe ya en Groq; hay que actualizar Kat")


def limpiar(texto):
    """Deja texto normal: quita el 'pensamiento' (<think>…</think>) y el formato Markdown
    (**negritas**, # títulos, `código`, listas), que la ventana mostraría tal cual."""
    texto = re.sub(r"(?s)<think>.*?</think>", "", texto or "")
    texto = re.sub(r"\*\*(.+?)\*\*|__(.+?)__", lambda m: m.group(1) or m.group(2), texto)
    texto = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"\1", texto)
    texto = re.sub(r"`([^`]*)`", r"\1", texto)
    texto = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", texto)
    texto = re.sub(r"(?m)^\s*[-*+]\s+", "• ", texto)
    texto = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r"\1 (\2)", texto)
    return re.sub(r"\n{3,}", "\n\n", texto).strip()


def _preguntar_a(modelo, frase, historial, clave, abrir):
    mensajes = [{"role": "system", "content": sistema()}]
    mensajes += [{"role": rol, "content": texto} for rol, texto in list(historial)[-HISTORIAL:]]
    mensajes.append({"role": "user", "content": frase})
    pedido = {"model": modelo, "messages": mensajes, "max_tokens": 800, "temperature": 0.5}
    if modelo.startswith("openai/gpt-oss"):
        pedido["reasoning_effort"] = "low"        # piensa poco: responde rápido y gasta menos
    cuerpo = json.dumps(pedido).encode("utf-8")
    peticion = urllib.request.Request(URL, data=cuerpo, method="POST", headers={
        "Authorization": "Bearer " + clave, "Content-Type": "application/json", "User-Agent": "KatOS/0.1"})
    try:
        with abrir(peticion, timeout=30) as r:
            datos = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detalle = ""
        try:
            detalle = e.read().decode("utf-8", "replace").lower()
        except Exception:
            pass
        if e.code == 429:
            if "per day" in detalle or "tpd" in detalle or "rpd" in detalle:
                raise LimiteDiario("Se acabó el límite gratuito de hoy de Kat Cloud AI") from e
            raise ErrorNube("Demasiadas preguntas seguidas; espera unos segundos") from e
        if e.code == 401:
            raise ErrorNube("La clave de Groq no es válida; revísala en ⚙") from e
        if e.code == 404 or "model_decommissioned" in detalle or "does not exist" in detalle:
            raise _ModeloRetirado(modelo) from e
        raise ErrorNube("Groq respondió con error %d" % e.code) from e
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise ErrorNube("Sin conexión con Kat Cloud AI") from e
    except ValueError as e:
        raise ErrorNube("Respuesta de la IA que no se entiende") from e
    try:
        texto = limpiar(datos["choices"][0]["message"]["content"])
    except (KeyError, IndexError, AttributeError, TypeError) as e:
        raise ErrorNube("Respuesta de la IA vacía") from e
    if not texto:
        raise ErrorNube("La IA no dio respuesta; intenta de nuevo")
    return texto
