"""La voz de Kat: dice sus respuestas en voz alta (texto a voz, sin internet).

- Kat OS: espeak-ng (voces en español). Si hay voces Piper instaladas en
  /usr/share/katos/voces/*.onnx y el programa piper, también se ofrecen.
- Windows (vista previa): las voces del sistema (p. ej. Microsoft Helena).
El texto se pasa por la entrada estándar, nunca como argumento: así ningún
texto puede convertirse en una orden.
"""

import glob
import os
import shutil
import subprocess
import tempfile

from katui import plataforma

LARGO_MAX = 600
PRUEBA = "¡Hola! Soy Kat, tu asistente. Así sonará mi voz."
CARPETA_PIPER = "/usr/share/katos/voces"

# espeak-ng: (id, nombre bonito)
ESPEAK = [
    ("espeak:es+f3", "Kat (femenina, España)"),
    ("espeak:es-419+f2", "Kat latina (femenina)"),
    ("espeak:es+m3", "Kat grave (masculina)"),
]

_actual = None


def _sin_ventana():
    return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if plataforma.ES_WINDOWS else {}


def _voces_windows():
    orden = ("Add-Type -AssemblyName System.Speech; "
             "(New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() | "
             "% { $_.VoiceInfo.Name + '|' + $_.VoiceInfo.Culture }")
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", orden], capture_output=True, text=True,
                           timeout=15, encoding="utf-8", errors="replace", **_sin_ventana())
    except (OSError, subprocess.TimeoutExpired):
        return []
    voces = []
    for linea in r.stdout.splitlines():
        nombre, _, cultura = linea.strip().partition("|")
        if nombre:
            voces.append(("sapi:" + nombre, "%s (%s)" % (nombre.replace("Microsoft ", "").replace(" Desktop", ""),
                                                         cultura)))
    voces.sort(key=lambda v: (0 if "(es" in v[1] else 1, v[1]))      # las de español primero
    return voces


def voces():
    """[(id, nombre)] de las voces que hay en este equipo (español primero)."""
    if plataforma.ES_WINDOWS:
        return _voces_windows()
    lista = []
    if shutil.which("piper"):
        for modelo in sorted(glob.glob(os.path.join(CARPETA_PIPER, "*.onnx"))):
            nombre = os.path.basename(modelo)[:-5]
            lista.append(("piper:" + nombre, "Kat natural: %s" % nombre))
    if shutil.which("espeak-ng"):
        lista += ESPEAK
    return lista


def _orden(voz):
    """(orden, usa_archivo_temporal) para decir algo con esa voz, o (None, False)."""
    tipo, _, nombre = (voz or "").partition(":")
    if tipo == "sapi" and plataforma.ES_WINDOWS:
        script = ("Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                  "try { $s.SelectVoice('%s') } catch {}; $s.Rate = 1; "
                  "[Console]::InputEncoding = [Text.Encoding]::UTF8; $s.Speak([Console]::In.ReadToEnd())"
                  % nombre.replace("'", ""))
        return ["powershell", "-NoProfile", "-Command", script], False
    if tipo == "espeak" and shutil.which("espeak-ng"):
        return ["espeak-ng", "-v", nombre, "-s", "160", "-p", "58", "--stdin"], False
    if tipo == "piper" and shutil.which("piper"):
        modelo = os.path.join(CARPETA_PIPER, os.path.basename(nombre) + ".onnx")
        if os.path.isfile(modelo):
            return ["piper", "--model", modelo, "--output_file"], True
    return None, False


def decir(texto, voz):
    """Dice el texto (sin bloquear). Devuelve True si empezó a hablar."""
    global _actual
    texto = (texto or "").strip()[:LARGO_MAX]
    orden, archivo = _orden(voz)
    if not texto or not orden:
        return False
    callar()
    try:
        if archivo:                                        # piper escribe un WAV y luego se reproduce
            salida = os.path.join(tempfile.gettempdir(), "kat-voz.wav")
            r = subprocess.run(orden + [salida], input=texto.encode("utf-8"), capture_output=True, timeout=60)
            if r.returncode != 0:
                return False
            reproductor = shutil.which("pw-play") or shutil.which("paplay") or shutil.which("aplay")
            if not reproductor:
                return False
            _actual = subprocess.Popen([reproductor, salida], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True
        _actual = subprocess.Popen(orden, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, **_sin_ventana())
        _actual.stdin.write(texto.encode("utf-8"))
        _actual.stdin.close()
        return True
    except (OSError, subprocess.TimeoutExpired):
        return False


def hablando():
    return _actual is not None and _actual.poll() is None


def callar():
    global _actual
    if _actual is not None and _actual.poll() is None:
        try:
            _actual.terminate()
        except OSError:
            pass
    _actual = None
