"""Kat en pantalla: SOLO la canica flotante.

- Sale de la barra de tareas (del lado donde esté) y vuelve a meterse al cerrarla.
- Un clic en la canica: si tienes micrófono, Kat te escucha y se abre un panel
  con la transcripción de lo que dijiste y su respuesta (que además dice en voz
  alta); si no, el panel trae una caja de texto para escribirle.
- Clic derecho: escribir, Kat Cloud AI, volver a configurarla o esconderla.
- Se arrastra con el ratón. Cuando abre una app, el logo aparece dentro y
  luego Kat se mete en la ventana de esa app; sale de ahí cuando la cierras
  o cuando vuelves a llamarla.
"""

from PySide6.QtCore import QEasingCurve, QParallelAnimationGroup, QPoint, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QColor, QGuiApplication, QIcon, QPainter, QPainterPath
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QMenu, QPushButton, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import plataforma, recursos
from katui.estilo import COLORES

from . import barra, comandos, oido, perfil, ventanas, voz
from .orbe import ESCUCHANDO, HABLANDO, PENSANDO, REPOSO, Orbe

COLOR_ESTADO = {res.HECHO: COLORES["texto"], res.FALLO: COLORES["error"], res.NO_DISPONIBLE: COLORES["aviso"]}


class ConfigNube(QDialog):
    """Activar Kat Cloud AI (Groq). La clave la crea y la pega el usuario."""

    def __init__(self, padre=None):
        super().__init__(padre)
        from . import nube
        self.nube = nube
        self.setWindowTitle("Kat Cloud AI")
        self.setMinimumWidth(420)
        config = nube.leer_config()
        caja = QVBoxLayout(self)
        texto = QLabel(
            "<b>Kat Cloud AI (opcional)</b><br>Con una clave gratuita de Groq, Kat puede responder "
            "preguntas libres y entender tu voz. <b>Privacidad:</b> solo se envían a Groq las preguntas que "
            "Kat no sabe responder sola y tu voz cuando tocas la canica para hablar; lo demás se queda en "
            "tu equipo.<br><br>"
            "1. Crea tu clave gratis en <a href='https://console.groq.com/keys' style='color:%s'>"
            "console.groq.com/keys</a><br>2. Pégala aquí:" % COLORES["violeta_claro"])
        texto.setWordWrap(True)
        texto.setOpenExternalLinks(True)
        caja.addWidget(texto)
        self.clave = QLineEdit(config["clave"])
        self.clave.setEchoMode(QLineEdit.Password)
        self.clave.setPlaceholderText("gsk_…")
        caja.addWidget(self.clave)
        self.activar = QCheckBox("Usar Kat Cloud AI")
        self.activar.setChecked(config["activado"])
        caja.addWidget(self.activar)
        self.sonidos = QCheckBox("Sonidos de Kat")
        self.sonidos.setChecked(config.get("sonidos", True))
        caja.addWidget(self.sonidos)
        self.estado = QLabel("")
        self.estado.setWordWrap(True)
        caja.addWidget(self.estado)
        fila = QHBoxLayout()
        probar = QPushButton("Probar")
        probar.clicked.connect(self._probar)
        guardar = QPushButton("Guardar")
        guardar.setStyleSheet("background:%s;color:white;border:none;border-radius:8px;padding:8px 18px;"
                              % COLORES["violeta"])
        guardar.clicked.connect(self._guardar)
        fila.addWidget(probar)
        fila.addStretch(1)
        fila.addWidget(guardar)
        caja.addLayout(fila)

    def _probar(self):
        clave = self.clave.text().strip()
        if not clave:
            self.estado.setText("Pega primero tu clave.")
            return
        self.estado.setText("Probando…")
        config = {"clave": clave, "modelo": self.nube.MODELO, "activado": True}
        from katui.qt import en_segundo_plano

        def probar():
            try:
                return "✔ Funciona: " + self.nube.preguntar("Di hola en 5 palabras.", config=config)
            except self.nube.ErrorNube as e:
                return "✖ %s" % e
        en_segundo_plano(probar, al_terminar=lambda t: self.estado.setText(str(t)))

    def _guardar(self):
        if self.activar.isChecked() and not self.clave.text().strip():
            self.estado.setText("Para activarla hace falta la clave.")
            return
        self.nube.guardar_config(self.activar.isChecked(), self.clave.text(), sonidos=self.sonidos.isChecked())
        self.accept()


def _etiqueta(tam="11pt", color=None):
    l = QLabel("")
    l.setWordWrap(True)
    l.setStyleSheet("font-size:%s;background:transparent;color:%s;" % (tam, color or COLORES["texto"]))
    return l


class PanelKat(QWidget):
    """El panel junto a la canica: lo que dijiste, lo que responde Kat y (sin micrófono) la caja de texto."""

    def __init__(self, kat):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle("Kat")
        self.setFixedWidth(340)
        caja = QVBoxLayout(self)
        caja.setContentsMargins(18, 12, 18, 16)
        caja.setSpacing(8)
        self.caja = caja
        arriba = QHBoxLayout()
        nombre = QLabel("Kat")
        nombre.setStyleSheet("font-size:12pt;font-weight:700;color:%s;background:transparent;"
                             % COLORES["violeta_claro"])
        self.marca_nube = QLabel("")
        self.marca_nube.setStyleSheet("font-size:8pt;background:transparent;color:%s;" % COLORES["texto_suave"])
        boton = ("QPushButton{background:transparent;border:none;font-size:%s;color:%s;}"
                 "QPushButton:hover{color:white;}")
        ajustes = QPushButton("⚙")
        ajustes.setFixedSize(26, 26)
        ajustes.setToolTip("Kat Cloud AI y sonidos")
        ajustes.setStyleSheet(boton % ("12pt", COLORES["texto_suave"]))
        ajustes.clicked.connect(kat._config_nube)
        cerrar = QPushButton("×")
        cerrar.setFixedSize(26, 26)
        cerrar.setToolTip("Cerrar el panel (Esc)")
        cerrar.setStyleSheet(boton % ("15pt", COLORES["texto_suave"]))
        cerrar.clicked.connect(self.hide)
        arriba.addWidget(nombre)
        arriba.addWidget(self.marca_nube)
        arriba.addStretch(1)
        arriba.addWidget(ajustes)
        arriba.addWidget(cerrar)
        caja.addLayout(arriba)

        self.tu = _etiqueta("10pt", COLORES["texto_suave"])          # transcripción de lo que dijiste
        self.tu.hide()
        caja.addWidget(self.tu)
        self.dice = _etiqueta("11.5pt")                                # respuesta de Kat
        caja.addWidget(self.dice)
        self.boton_web = QPushButton("Buscar en internet")
        self.boton_web.setStyleSheet("QPushButton{background:%s;border:none;border-radius:12px;padding:6px 14px;"
                                     "color:white;font-weight:600;}" % COLORES["violeta"])
        self.boton_web.hide()
        caja.addWidget(self.boton_web, 0, Qt.AlignLeft)
        self.escuchando = QPushButton("✓  Ya terminé de hablar")
        self.escuchando.setStyleSheet(self.boton_web.styleSheet())
        self.escuchando.hide()
        caja.addWidget(self.escuchando, 0, Qt.AlignHCenter)
        self.entrada = QLineEdit()
        self.entrada.setPlaceholderText("Escríbele a Kat…")
        self.entrada.setStyleSheet("QLineEdit{background:%s;border:1px solid %s;border-radius:16px;padding:8px 14px;"
                                   "font-size:11pt;} QLineEdit:focus{border-color:%s;}"
                                   % (COLORES["tarjeta"], COLORES["borde"], COLORES["violeta"]))
        self.entrada.hide()
        caja.addWidget(self.entrada)
        self.aviso = _etiqueta("7.5pt", COLORES["texto_suave"])     # letra pequeña (límites de la IA...)
        self.aviso.hide()
        caja.addWidget(self.aviso)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        forma = QPainterPath()
        forma.addRoundedRect(self.rect().adjusted(1, 1, -1, -1), 22, 22)
        p.fillPath(forma, QColor(16, 13, 25, 240))
        p.setPen(QColor(COLORES["borde"]))
        p.drawPath(forma)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.hide()
        else:
            super().keyPressEvent(e)


class VentanaKat(QWidget):
    """La canica de Kat (sola, sin cuadro). Controla el panel, el micrófono y la voz."""

    TAM = 210

    def __init__(self):
        super().__init__(None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowTitle("Kat")
        self.resize(self.TAM, self.TAM)
        caja = QVBoxLayout(self)
        caja.setContentsMargins(0, 0, 0, 0)
        self.orbe = Orbe(self.TAM - 10)
        self.orbe.setStyleSheet("background: transparent;")
        self.orbe.setToolTip("Toca para hablar con Kat · clic derecho: más opciones")
        caja.addWidget(self.orbe)
        # la × aparece al pasar el cursor por encima de Kat
        self.equis = QPushButton("×", self)
        self.equis.setFixedSize(30, 30)
        self.equis.setToolTip("Cerrar a Kat")
        self.equis.setCursor(Qt.PointingHandCursor)
        self.equis.setStyleSheet("QPushButton{background:rgba(16,13,25,220);border:1px solid %s;border-radius:15px;"
                                 "color:%s;font-size:14pt;padding:0;} QPushButton:hover{background:%s;color:white;}"
                                 % (COLORES["borde"], COLORES["texto_suave"], COLORES["error"]))
        self.equis.move(self.TAM - 52, 30)
        self.equis.clicked.connect(self.salir)
        self.equis.hide()
        self.perfil = perfil.leer()
        self.orbe.poner_diseno(perfil.DISENOS[self.perfil["diseno"]][1])

        self.panel = PanelKat(self)
        # atajos (el resto del código y las pruebas los usan)
        self.dice, self.entrada, self.aviso = self.panel.dice, self.panel.entrada, self.panel.aviso
        self.boton_web, self.marca_nube = self.panel.boton_web, self.panel.marca_nube
        self.entrada.returnPressed.connect(lambda: self.preguntar(self.entrada.text()))
        self.boton_web.clicked.connect(self._buscar_web)
        self.panel.escuchando.clicked.connect(self.terminar_escucha)

        self._pendiente_web = None
        self._temporizadores = []
        self.historial = []
        self._marcar_nube()
        self._volver = QTimer(self)
        self._volver.setSingleShot(True)
        self._volver.timeout.connect(self._fin_de_hablar)
        self._inicio = None
        self._animacion = None
        self._arrastre = None
        self._movido = False
        self.primera = None
        self.musica = None
        self.grabadora = None
        self._limite_escucha = QTimer(self)
        self._limite_escucha.setSingleShot(True)
        self._limite_escucha.timeout.connect(self.terminar_escucha)
        self.dentro = None                    # {"nombre", "punto", "proceso"} si está metida en una ventana
        self._vigilar = QTimer(self)
        self._vigilar.timeout.connect(self._revisar_app)

    # --- el panel -----------------------------------------------------------------------
    def _colocar_panel(self):
        self.panel.adjustSize()
        libre = QGuiApplication.primaryScreen().availableGeometry()
        g = self.frameGeometry()
        w, h = self.panel.width(), self.panel.height()
        x = g.left() - w - 6
        if x < libre.left():
            x = g.right() + 6
        y = g.bottom() - h - 10
        x = max(libre.left() + 4, min(x, libre.right() - w - 4))
        y = max(libre.top() + 4, min(y, libre.bottom() - h - 4))
        self.panel.move(x, y)

    def mostrar_panel(self):
        self._colocar_panel()
        self.panel.show()
        self.panel.raise_()
        QTimer.singleShot(0, self._colocar_panel)          # tras ajustar su alto

    def moveEvent(self, e):
        super().moveEvent(e)
        if self.panel.isVisible():
            self._colocar_panel()

    # --- tocar la canica ----------------------------------------------------------------
    def tocar(self):
        if self.primera is not None:
            self.mostrar_panel()
            return
        if self.grabadora is not None:
            self.terminar_escucha()
            return
        if self.perfil.get("microfono") and oido.hay_microfono() is not False:
            self.empezar_escucha()
        else:
            self.modo_texto()

    def modo_texto(self, mensaje=None):
        self.panel.escuchando.hide()
        if mensaje:
            self._decir(mensaje, COLORES["aviso"], hablar=False)
        elif not self.dice.text():
            self.dice.setText("¿En qué te ayudo?")
        self.entrada.show()
        self.mostrar_panel()
        self.panel.activateWindow()
        self.entrada.setFocus()

    def empezar_escucha(self):
        voz.callar()
        self.grabadora = oido.Grabadora()
        if not self.grabadora.empezar():
            self.grabadora = None
            self.modo_texto("No pude usar el micrófono; escríbeme aquí.")
            return
        self._sonar_si("kat-escuchar")
        self.orbe.poner_estado(ESCUCHANDO)
        self.panel.tu.setText("🎤 Te escucho… toca la canica cuando termines")
        self.panel.tu.show()
        self.dice.setText("")
        self.panel.escuchando.show()
        self.mostrar_panel()
        self._limite_escucha.start(oido.SEGUNDOS_MAX * 1000)

    def terminar_escucha(self):
        if self.grabadora is None:
            return
        self._limite_escucha.stop()
        g, self.grabadora = self.grabadora, None
        ruta = g.terminar()
        self.panel.escuchando.hide()
        if not ruta:
            self.orbe.poner_estado(REPOSO)
            self.modo_texto("No te escuché. Inténtalo otra vez o escríbeme.")
            return
        self.panel.tu.setText("Entendiendo lo que dijiste…")
        self.orbe.poner_estado(PENSANDO)

        def entender():
            try:
                return oido.transcribir(ruta)
            except Exception as e:                      # ErrorNube u otro: se muestra, no se esconde
                return e
        from katui.qt import en_segundo_plano
        en_segundo_plano(entender, al_terminar=self._entendido)

    def _entendido(self, texto):
        if not isinstance(texto, str):
            self.orbe.poner_estado(REPOSO)
            self.panel.tu.hide()
            self.modo_texto(str(getattr(texto, "mensaje", "") or texto))
            return
        self.preguntar(texto)

    # --- conversar ------------------------------------------------------------------------
    def preguntar(self, texto):
        texto = (texto or "").strip()
        if not texto:
            return
        self.entrada.clear()
        self._sonar_si("kat-aceptar")
        self.dice_pregunta = texto
        self.boton_web.hide()
        self.panel.tu.setText("Tú: «%s»" % texto)
        self.panel.tu.show()
        self.dice.setStyleSheet("font-size:11.5pt;background:transparent;color:%s;" % COLORES["texto_suave"])
        self.dice.setText("…")
        self.orbe.poner_estado(PENSANDO)
        if not self.panel.isVisible():
            self.mostrar_panel()
        historial = list(self.historial)

        def pensar():                       # en segundo plano: el clima y la IA usan internet
            try:
                return comandos.responder(texto, historial)
            except Exception as e:          # nunca dejar a Kat colgada: mostrar el error real
                return comandos.Respuesta("Algo falló al hacer eso: %s" % e, res.fallo(str(e)))
        from katui.qt import en_segundo_plano
        en_segundo_plano(pensar, al_terminar=self._responder)

    def _responder(self, r):
        if isinstance(r, res.Resultado):            # error inesperado en el hilo
            r = comandos.Respuesta("Algo falló: %s" % r.mensaje, r)
        self.ultima = r
        self._sonar_si("kat-error" if r.resultado.estado == res.FALLO else "kat-responder")
        self._decir(r.texto, COLOR_ESTADO[r.resultado.estado])
        self.aviso.setText(r.aviso)
        self.aviso.setVisible(bool(r.aviso))
        # Toda la conversación (no solo lo de la nube): así la IA entiende «¿y mañana?» tras «qué clima hace».
        self.historial += [("user", self.dice_pregunta), ("assistant", r.texto)]
        self.historial = self.historial[-12:]
        if r.buscar_web:
            self._pendiente_web = r.buscar_web
            self.boton_web.show()
        if getattr(r, "app", None) and r.resultado.estado == res.HECHO:
            self._abriendo_app(r.app, getattr(r, "proceso", None))
        if r.temporizador:
            aviso = QTimer(self)
            aviso.setSingleShot(True)
            minutos = r.temporizador / 60
            aviso.timeout.connect(lambda: self._sonar(minutos))
            aviso.start(int(r.temporizador * 1000))
            self._temporizadores.append(aviso)
        if self.panel.isVisible():
            QTimer.singleShot(0, self._colocar_panel)

    def _decir(self, texto, color=None, hablar=True):
        self.dice.setStyleSheet("font-size:11.5pt;background:transparent;color:%s;" % (color or COLORES["texto"]))
        self.dice.setText(texto)
        self.orbe.poner_estado(HABLANDO)
        con_voz = hablar and bool(self.perfil.get("voz")) and voz.decir(texto, self.perfil["voz"])
        # con voz: Kat "habla" mientras suena; sin voz: un ratito según el largo del texto
        self._volver.start(min(20000, 1200 + 70 * len(texto)) if con_voz else min(4000, 900 + 35 * len(texto)))

    def _fin_de_hablar(self):
        if voz.hablando():
            self._volver.start(300)
            return
        self.orbe.poner_estado(REPOSO)

    def _sonar(self, minutos):
        from PySide6.QtWidgets import QApplication
        QApplication.beep()
        if not self.isVisible():
            self.aparecer()
        cuanto = ("%d segundos" % round(minutos * 60)) if minutos < 1 else (
            "%g minuto%s" % (minutos, "" if minutos == 1 else "s"))
        self.mostrar_panel()
        self._decir("⏰ ¡Tiempo! Ya pasaron %s." % cuanto)

    def _marcar_nube(self):
        from . import nube
        self.marca_nube.setText("· Cloud AI" if nube.disponible() else "")

    def _config_nube(self):
        ConfigNube(self.panel).exec()
        self._marcar_nube()

    def _buscar_web(self):
        if self._pendiente_web:
            r = comandos.buscar_en_internet(self._pendiente_web)
            self.boton_web.hide()
            self._decir(r.texto, COLOR_ESTADO[r.resultado.estado])

    def _menu(self, punto):
        m = QMenu(self)
        m.addAction("⌨️  Escribirle a Kat", self.modo_texto)
        m.addAction("⚙  Kat Cloud AI y sonidos…", self._config_nube)
        m.addAction("🎨  Configurarme otra vez", self.configurar_primera_vez)
        m.addSeparator()
        m.addAction("Esconder a Kat", self.salir)
        m.exec(punto)

    # --- salir de la barra y volver a ella ------------------------------------------
    def _animar(self, desde, hasta, opacidad, ms, curva, al_terminar=None):
        if self._animacion is not None:
            self._animacion.stop()
        grupo = QParallelAnimationGroup(self)
        mover = QPropertyAnimation(self, b"pos")
        mover.setDuration(ms)
        mover.setStartValue(desde)
        mover.setEndValue(hasta)
        mover.setEasingCurve(curva)
        brillo = QPropertyAnimation(self, b"windowOpacity")
        brillo.setDuration(int(ms * 0.75))
        brillo.setStartValue(opacidad[0])
        brillo.setEndValue(opacidad[1])
        grupo.addAnimation(mover)
        grupo.addAnimation(brillo)
        if al_terminar:
            grupo.finished.connect(al_terminar)
        self._animacion = grupo
        grupo.start()

    def aparecer(self):
        """Kat (la canica) sale de la barra de tareas y se queda junto a ella."""
        pantalla = QGuiApplication.primaryScreen()
        _lado, self._inicio, final = barra.posiciones(pantalla.geometry(), pantalla.availableGeometry(),
                                                      self.width(), self.height())
        self.setWindowOpacity(0.0)
        self.move(self._inicio)
        self.show()
        self.raise_()
        self.orbe.crecer()
        self._animar(self._inicio, final, (0.0, 1.0), 520, QEasingCurve.OutCubic)
        self._sonar_si("kat-escuchar")

    mostrar_en_esquina = aparecer

    def volver_a_barra(self, al_terminar=None):
        """Kat se mete otra vez en la barra de tareas (y luego se esconde)."""
        self.panel.hide()
        if not self.isVisible() or self._inicio is None:
            self.hide()
            if al_terminar:
                al_terminar()
            return
        self.orbe.encoger()

        def fin():
            self.hide()
            self.setWindowOpacity(1.0)
            if al_terminar:
                al_terminar()
        self._animar(self.pos(), self._inicio, (1.0, 0.0), 340, QEasingCurve.InCubic, fin)

    def salir(self):
        """Cerrar a Kat: se desintegra en bits que vuelan a la barra de tareas.
        Con temporizadores pendientes solo se esconde (para poder avisar después)."""
        self.cerrar_en_bits(None if self._temporizadores else self.close)

    def cerrar_en_bits(self, al_terminar=None):
        from .particulas import Desintegrar
        self.panel.hide()
        self.equis.hide()
        if not self.isVisible():
            if al_terminar:
                al_terminar()
            return
        pantalla = QGuiApplication.primaryScreen()
        _lado, inicio, _final = barra.posiciones(pantalla.geometry(), pantalla.availableGeometry(),
                                                 self.width(), self.height())
        self._inicio = inicio
        g = pantalla.geometry()
        destino = QPoint(min(max(inicio.x() + self.width() // 2, g.left() + 20), g.right() - 20),
                         min(max(inicio.y() + self.height() // 2, g.top() + 20), g.bottom() - 20))
        imagen = self.orbe.grab().toImage()
        origen = self.orbe.mapToGlobal(QPoint(0, 0))
        self._bits = Desintegrar(imagen, origen, destino)
        self.hide()

        def fin():
            self._bits = None
            if al_terminar:
                al_terminar()
        self._bits.empezar(fin)

    def _abriendo_app(self, clave, proceso=None):
        """El logo de la app dentro de la canica mientras carga; después Kat se mete en su ventana."""
        programa, nombre, _ = comandos.APPS[clave]
        ruta = recursos.icono(programa)
        icono = QIcon(ruta) if ruta else QIcon.fromTheme(programa)
        if not icono.isNull():
            self.orbe.mostrar_logo(icono.pixmap(256, 256))

        def listo():
            self.orbe.quitar_logo()
            QTimer.singleShot(150, lambda: self.meterse_en_app(nombre, proceso))
        QTimer.singleShot(1500, listo)

    # --- meterse en la ventana de una app y salir de ella --------------------------
    def meterse_en_app(self, nombre, proceso, intentos=4):
        """Kat vuela hacia la ventana de la app, se encoge y desaparece dentro."""
        punto = ventanas.centro_de(nombre)
        if punto is None and intentos > 0 and plataforma.ES_WINDOWS:
            QTimer.singleShot(450, lambda: self.meterse_en_app(nombre, proceso, intentos - 1))
            return                                           # la ventana aún no aparece: esperar un poco
        punto = punto or ventanas.centro_probable()
        self.panel.hide()
        self.orbe.encoger()
        destino = punto - QPoint(self.width() // 2, self.height() // 2)

        def dentro():
            self.hide()
            self.setWindowOpacity(1.0)
            self.dentro = {"nombre": nombre, "punto": punto, "proceso": proceso}
            if proceso is not None:
                self._vigilar.start(600)                     # al cerrarse la app, Kat sale
        self._animar(self.pos(), destino, (1.0, 0.0), 460, QEasingCurve.InBack, dentro)

    def _revisar_app(self):
        d = self.dentro
        if d is None or d["proceso"] is None or d["proceso"].poll() is not None:
            self._vigilar.stop()
            if d is not None:
                self.salir_de_app()

    def salir_de_app(self):
        """Kat sale de la ventana donde estaba (o de donde estaba, si ya se cerró)."""
        d, self.dentro = self.dentro, None
        self._vigilar.stop()
        if d is None:
            self.aparecer()
            return
        punto = ventanas.centro_de(d["nombre"]) or d["punto"]
        pantalla = QGuiApplication.primaryScreen()
        _lado, self._inicio, final = barra.posiciones(pantalla.geometry(), pantalla.availableGeometry(),
                                                      self.width(), self.height())
        desde = punto - QPoint(self.width() // 2, self.height() // 2)
        self.setWindowOpacity(0.0)
        self.move(desde)
        self.show()
        self.raise_()
        self.orbe.crecer(0.2)
        self._animar(desde, final, (0.0, 1.0), 620, QEasingCurve.OutCubic)
        self._sonar_si("kat-escuchar")

    def llamar(self, pregunta=""):
        """Te llaman otra vez (otra Kat avisó): sale de la ventana donde estaba, o de la barra."""
        if self.dentro is not None:
            self.salir_de_app()
        elif not self.isVisible():
            self.aparecer()
        else:
            self.raise_()
        if pregunta:
            self.preguntar(pregunta)

    def _sonar_si(self, nombre):
        """Sonidos de Kat (se pueden apagar en ⚙)."""
        from . import nube
        if nube.leer_config().get("sonidos", True):
            from katui import sonido
            sonido.reproducir(nombre)

    # --- la primera vez ----------------------------------------------------------------
    def configurar_primera_vez(self, voces=None):
        """Palabra, micrófono, voz y diseño, con la música de Kat bajito y con eco."""
        from katui import musica
        from katui.qt import en_segundo_plano
        from . import nube
        from .primera import PrimeraVez
        if self.primera is not None:
            self.mostrar_panel()
            return
        for w in (self.entrada, self.panel.tu, self.panel.escuchando, self.boton_web):
            w.hide()
        self.primera = PrimeraVez(voces=voces or [], tiene_clave=bool(nube.leer_config()["clave"]))
        self.primera.probar_voz.connect(lambda v: voz.decir(voz.PRUEBA, v))
        self.primera.probar_diseno.connect(lambda clave: self.orbe.poner_diseno(perfil.DISENOS[clave][1]))
        self.primera.terminado.connect(self._primera_lista)
        self.panel.caja.insertWidget(self.panel.caja.indexOf(self.aviso), self.primera)
        self.dice.setText("")
        self.dice.hide()
        if voces is None:                                   # buscar las voces sin congelar la ventana
            en_segundo_plano(voz.voces, al_terminar=self._voces_listas)
        self.mostrar_panel()
        self.musica = musica.Musica("kat-eco", volumen=0.3)
        self.musica.empezar()

    def _voces_listas(self, lista):
        if self.primera is not None:
            self.primera.poner_voces(lista if isinstance(lista, list) else [])
            QTimer.singleShot(0, self._colocar_panel)

    def _primera_lista(self, datos):
        self.perfil = datos
        voz.callar()
        if self.musica:
            self.musica.parar()
        self.primera.hide()
        self.primera.deleteLater()
        self.primera = None
        self.dice.show()
        modo = "toca la canica y háblame" if datos["microfono"] else "toca la canica y escríbeme"
        self._decir("¡Listo! Ya soy tu Kat. Cuando me necesites, %s." % modo)
        self._sonar_si("kat-responder")
        QTimer.singleShot(0, self._colocar_panel)

    # --- ratón y teclado ---------------------------------------------------------------
    def enterEvent(self, e):
        if self.primera is None:
            self.equis.show()
            self.equis.raise_()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self.equis.hide()
        super().leaveEvent(e)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.salir()
        else:
            super().keyPressEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._arrastre = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            self._movido = False
        elif e.button() == Qt.RightButton:
            self._menu(e.globalPosition().toPoint())

    def mouseMoveEvent(self, e):
        if self._arrastre is not None and e.buttons() & Qt.LeftButton:
            nueva = e.globalPosition().toPoint() - self._arrastre
            if self._movido or (nueva - self.pos()).manhattanLength() > 6:
                self._movido = True
                self.move(nueva)

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self._arrastre is not None and not self._movido:
            self.tocar()
        self._arrastre = None

    def closeEvent(self, evento):
        if self.musica:
            self.musica.parar()
        voz.callar()
        if self.grabadora is not None:
            self.grabadora.cancelar()
            self.grabadora = None
        self.panel.close()
        self._vigilar.stop()
        super().closeEvent(evento)
        from PySide6.QtWidgets import QApplication
        if not QApplication.quitOnLastWindowClosed():
            QApplication.quit()                    # Kat se cerró de verdad: terminar el programa
