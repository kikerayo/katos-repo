"""El clima con Open-Meteo (https://open-meteo.com): gratis, sin cuenta ni clave.

Solo se envía el nombre de la ciudad que preguntas (para encontrarla en el
mapa) y sus coordenadas (para pedir el tiempo).
"""

import json
import urllib.error
import urllib.parse
import urllib.request

GEO = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=es&name="
TIEMPO = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
          "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto")

CODIGOS = {0: "despejado", 1: "casi despejado", 2: "parcialmente nublado", 3: "nublado", 45: "con niebla",
           48: "con niebla helada", 51: "con llovizna ligera", 53: "con llovizna", 55: "con llovizna fuerte",
           61: "con lluvia ligera", 63: "con lluvia", 65: "con lluvia fuerte", 71: "con nieve ligera",
           73: "con nieve", 75: "con nieve fuerte", 80: "con chubascos", 81: "con chubascos fuertes",
           82: "con chubascos muy fuertes", 95: "con tormenta", 96: "con tormenta y granizo",
           99: "con tormenta fuerte y granizo"}


class SinConexion(RuntimeError):
    pass


def _pedir(url):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "KatOS/0.1"}),
                                    timeout=15) as r:
            return json.loads(r.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        raise SinConexion("no pude conectarme al servicio del clima") from e


def clima(ciudad):
    """Devuelve el texto con el clima actual de la ciudad, o None si no existe esa ciudad."""
    lugares = _pedir(GEO + urllib.parse.quote(ciudad)).get("results") or []
    if not lugares:
        return None
    lugar = lugares[0]
    datos = _pedir(TIEMPO % (lugar["latitude"], lugar["longitude"]))["current"]
    nombre = lugar.get("name", ciudad)
    pais = lugar.get("country", "")
    estado = CODIGOS.get(datos.get("weather_code"), "")
    return "En %s%s hace %.0f °C%s (se siente como %.0f °C) y viento de %.0f km/h." % (
        nombre, ", %s" % pais if pais else "", datos["temperature_2m"], ", " + estado if estado else "",
        datos["apparent_temperature"], datos["wind_speed_10m"])
