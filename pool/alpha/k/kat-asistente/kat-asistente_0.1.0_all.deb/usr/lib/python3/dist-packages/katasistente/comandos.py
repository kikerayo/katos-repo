"""Lo que Kat entiende y hace (versión 0.1, sin IA: reglas en español).

Cada orden devuelve una Respuesta: el texto que dice Kat y el Resultado real
de la acción (hecho / falló / no disponible aquí). Si no entiende, lo dice.
"""

import datetime
import os
import random
import re
import shutil
import subprocess
import sys
import unicodedata

from katui import acciones as res
from katui import plataforma

PROYECTO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# clave: (programa en Kat OS, nombre bonito, palabras que la nombran)
APPS = {
    "files": ("kat-files", "Kat Files", ["archivos", "explorador", "files", "carpetas", "documentos"]),
    "store": ("kat-store", "Kat Store", ["tienda", "store", "apps"]),
    "settings": ("kat-settings", "Kat Settings", ["ajustes", "configuracion", "settings", "panel de control"]),
    "security": ("kat-security", "Kat Security", ["seguridad", "security", "antivirus"]),
    "update": ("kat-update", "Kat Update Center", ["actualizaciones", "update", "actualizar"]),
    "devcenter": ("kat-devcenter", "Kat Developer Center", ["developer", "desarrollo", "devcenter"]),
    "bienvenida": ("kat-bienvenida", "Kat Bienvenida", ["bienvenida"]),
    "moji": ("kat-moji", "KatMoji", ["emojis", "emoji", "katmoji", "caritas"]),
    "safety": ("kat-safety", "KatSafety", ["safety", "emergencia", "alertas", "sismos", "desastres"]),
    "rostro": ("kat-rostro", "Kat Rostro", ["rostro", "reconocimiento facial", "mi cara", "face id"]),
    "telefono": ("kat-telefono", "Kat Phone ID", ["phone id", "telefono", "celular", "movil"]),
    "navegador": ("firefox-esr", "Firefox", ["navegador", "firefox", "internet"]),
}

CHISTES = [
    "¿Qué le dice un gato a otro gato? ¡Miau-ravilloso verte!",
    "¿Por qué los gatos son buenos programadores? Porque siempre encuentran el ratón.",
    "Mi lenguaje de programación favorito es Python… aunque los gatos preferimos atrapar bugs.",
    "¿Cómo se llama un gato que va a la playa? Michi-relax.",
]


class Respuesta:
    def __init__(self, texto, resultado=None, temporizador=None, buscar_web=None, aviso="", nube=False, app=None,
                 proceso=None):
        self.texto = texto
        self.app = app                        # clave de APPS si Kat abrió una app (muestra su logo)
        self.proceso = proceso                # su proceso: Kat se mete en la ventana hasta que se cierre
        self.resultado = resultado or res.hecho()
        self.temporizador = temporizador      # segundos: la ventana avisa cuando pasen
        self.buscar_web = buscar_web          # frase que Kat ofrece buscar en internet
        self.aviso = aviso                    # nota en letra pequeña (p. ej. límite de la IA)
        self.nube = nube                      # True si respondió Kat Cloud AI

    def __repr__(self):
        return "Respuesta(%r, %s)" % (self.texto, self.resultado.estado)


def normalizar(texto):
    t = unicodedata.normalize("NFD", (texto or "").lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[¿?¡!.,;]", " ", t).strip()


# --- acciones reales ---------------------------------------------------------
def _lanzar(cmd, env=None):
    """Abre el programa y devuelve su proceso (o None si no se pudo)."""
    try:
        return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env,
                                **({"start_new_session": True} if not plataforma.ES_WINDOWS else {}))
    except OSError:
        return None


def abrir_app(clave):
    programa, nombre, _ = APPS[clave]
    if shutil.which(programa):
        ok = _lanzar([programa])
        return Respuesta("Abriendo %s." % nombre, res.hecho() if ok else res.fallo("no se pudo abrir"), app=clave,
                         proceso=ok)
    # En Windows (vista previa): abrir la versión de prueba de la app Kat del proyecto.
    script = os.path.join(PROYECTO, programa, "bin", programa)
    if plataforma.ES_WINDOWS and os.path.isfile(script):
        python = sys.executable.replace("python.exe", "pythonw.exe")
        rutas = [os.path.join(PROYECTO, programa)] + [os.path.join(PROYECTO, c) for c in
                                                       ("kat-ui", "kat-store", "kat-update", "kat-core")]
        env = dict(os.environ, PYTHONPATH=os.pathsep.join(rutas))
        ok = _lanzar([python, script], env)
        return Respuesta("Abriendo %s (vista previa)." % nombre, res.hecho() if ok else res.fallo("no se pudo abrir"),
                         app=clave, proceso=ok)
    return Respuesta("%s está en Kat OS." % nombre, res.no_disponible("solo en Kat OS"))


def buscar_en_tienda(texto):
    if shutil.which("kat-store"):
        ok = _lanzar(["kat-store", "--buscar", texto])
    elif plataforma.ES_WINDOWS and os.path.isfile(os.path.join(PROYECTO, "kat-store", "bin", "kat-store")):
        python = sys.executable.replace("python.exe", "pythonw.exe")
        env = dict(os.environ, PYTHONPATH=os.pathsep.join(os.path.join(PROYECTO, c) for c in
                                                          ("kat-store", "kat-ui", "kat-core")))
        ok = _lanzar([python, os.path.join(PROYECTO, "kat-store", "bin", "kat-store"), "--buscar", texto], env)
    else:
        return Respuesta("Kat Store está en Kat OS.", res.no_disponible("solo en Kat OS"))
    return Respuesta("Busco «%s» en Kat Store para que elijas cuál instalar." % texto,
                     res.hecho() if ok else res.fallo("no se pudo abrir Kat Store"))


def espacio_libre():
    uso = shutil.disk_usage(os.path.expanduser("~"))
    return Respuesta("Te quedan %.0f GB libres de %.0f GB en tu disco." % (uso.free / 1024 ** 3, uso.total / 1024 ** 3))


def memoria_en_uso():
    """Porcentaje de RAM en uso, real (Linux: /proc/meminfo; Windows: GlobalMemoryStatusEx)."""
    if plataforma.ES_LINUX:
        datos = {}
        with open("/proc/meminfo") as f:
            for linea in f:
                k, v = linea.split(":")
                datos[k] = int(v.split()[0])
        total = datos["MemTotal"]
        return round(100 * (total - datos.get("MemAvailable", 0)) / total), total / 1024 ** 2
    import ctypes

    class E(ctypes.Structure):
        _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong)] + \
                   [(n, ctypes.c_ulonglong) for n in ("a", "b", "c", "d", "e", "f", "g")]
    e = E()
    e.dwLength = ctypes.sizeof(E)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(e))
    return e.dwMemoryLoad, e.a / 1024 ** 3


def volumen(cambio=None, valor=None, silencio=None):
    try:
        from katsettings import sonido
    except ImportError:
        return Respuesta("El volumen se controla en Kat OS.", res.no_disponible("solo en Kat OS"))
    if silencio is not None:
        r = sonido.silenciar(silencio)
        return Respuesta("Listo, %s." % ("silenciado" if silencio else "sonido activado")
                         if r.ok else "No pude cambiar el sonido.", r)
    actual = sonido.leer_volumen()
    if actual is None:
        return Respuesta("El volumen se controla en Kat OS.", res.no_disponible("solo en Kat OS"))
    nuevo = valor if valor is not None else actual[0] + cambio
    r = sonido.poner_volumen(nuevo)
    return Respuesta("Volumen al %d %%." % max(0, min(150, nuevo)) if r.ok else "No pude cambiar el volumen.", r)


def tema(modo):
    from katui import escritorio
    r = escritorio.cambiar_apariencia(modo, escritorio.acento_actual() or "violeta")
    if r.ok:
        return Respuesta("Listo, modo %s." % modo, r)
    if r.estado == res.NO_DISPONIBLE:
        return Respuesta("El modo %s se aplica en Kat OS." % modo, r)
    return Respuesta("No pude cambiar el tema.", r)


def bloquear():
    if not plataforma.ES_LINUX:
        return Respuesta("Bloquear la pantalla lo hago en Kat OS.", res.no_disponible("solo en Kat OS"))
    r = res.ejecutar(["loginctl", "lock-session"])
    return Respuesta("Pantalla bloqueada." if r.ok else "No pude bloquear la pantalla.", r)


def nota_seguridad():
    try:
        from katsecurity import comprobaciones
    except ImportError:
        return Respuesta("La revisión de seguridad está en Kat Security (Kat OS).", res.no_disponible("solo en Kat OS"))
    lista = comprobaciones.revisar()
    n = comprobaciones.nota(lista)
    if n is None:
        return Respuesta("Aquí no puedo revisar la seguridad: lo hago en Kat OS.", res.no_disponible("solo en Kat OS"))
    malas = [c.nombre for c in lista if c.estado in (comprobaciones.MAL, comprobaciones.AVISO)]
    extra = " Revisa: %s." % ", ".join(malas) if malas else " Todo en orden."
    return Respuesta("Tu nota de seguridad es %d de 100.%s" % (n, extra))


def buscar_en_internet(texto):
    import urllib.parse
    import webbrowser
    url = "https://duckduckgo.com/?q=" + urllib.parse.quote(texto)
    ok = webbrowser.open(url)
    return Respuesta("Busco «%s» en internet." % texto, res.hecho() if ok else res.fallo("no hay navegador"))


def abrir_programa(pedido):
    from . import programas
    prog = programas.buscar(pedido)
    if prog is None:
        return None
    ok = programas.abrir(prog)
    return Respuesta("Abriendo %s." % prog[0], res.hecho() if ok else res.fallo("no se pudo abrir"))


def ciudad_del_sistema():
    """La ciudad de la zona horaria del equipo (America/Tegucigalpa -> Tegucigalpa), o None."""
    zona = None
    try:
        zona = os.path.realpath("/etc/localtime").split("zoneinfo/")[1]
    except (IndexError, OSError):
        pass
    if zona and "/" in zona:
        return zona.split("/")[-1].replace("_", " ")
    return None


def clima_de(ciudad):
    from . import clima
    if not ciudad:
        return Respuesta("¿De qué ciudad? Por ejemplo: «clima en Tegucigalpa».")
    try:
        texto = clima.clima(ciudad)
    except clima.SinConexion:
        return Respuesta("No pude consultar el clima: revisa tu internet.", res.fallo("sin conexión"))
    if texto is None:
        return Respuesta("No encontré la ciudad «%s»." % ciudad, res.fallo("ciudad desconocida"))
    return Respuesta(texto)


def temporizador(cantidad, unidad):
    segundos = cantidad * {"s": 1, "m": 60, "h": 3600}[unidad[0]]
    if not 0 < segundos <= 24 * 3600:
        return Respuesta("Puedo poner temporizadores de hasta 24 horas.", res.fallo("fuera de rango"))
    nombre = {"s": "segundo", "m": "minuto", "h": "hora"}[unidad[0]]
    return Respuesta("Listo, te aviso en %d %s%s. Deja mi ventana abierta." % (cantidad, nombre, "" if cantidad == 1 else "s"),
                     temporizador=segundos)


# --- entender la frase -------------------------------------------------------
AYUDA = ("Puedo: abrir apps («abre archivos», «abre spotify»), cuentas («cuánto es 15% de 300»), "
         "conversiones («10 km a millas»), el clima («clima en Tegucigalpa»), temporizadores "
         "(«avísame en 5 minutos»), buscar en internet o en la tienda, la hora y la fecha, espacio y "
         "memoria, volumen, modo oscuro o claro, bloquear la pantalla, tu nota de seguridad y chistes. "
         "Todavía no entiendo la voz ni preguntas libres: eso llegará con Kat Local AI.")


def responder(frase, historial=()):
    """Primero lo que Kat sabe hacer sola (con acciones reales); si no, Kat Cloud AI si está activada."""
    r = responder_local(frase)
    if r.buscar_web is None:
        return r
    from . import nube
    if not nube.disponible():
        return r
    try:
        texto = nube.preguntar(frase, historial)
    except nube.LimiteDiario as e:
        r.aviso = "%s. Vuelve mañana; mientras tanto respondo lo que sé hacer sola." % e
        return r
    except nube.ErrorNube as e:
        r.aviso = "Kat Cloud AI: %s." % e
        return r
    return Respuesta(texto, nube=True)


def responder_local(frase):
    from . import calculo
    original = (frase or "").strip()
    t = normalizar(frase)
    if not t:
        return Respuesta("Escríbeme algo y te ayudo. Prueba «qué puedes hacer».")

    m = re.search(r"\b(?:busca|buscar|googlea|investiga)\s+(?:en (?:internet|google|la web)\s+)?(.+?)"
                  r"(?:\s+en\s+(?:internet|google|la web))?$", t)
    if m and re.search(r"\b(internet|google|la web|googlea|investiga)\b", t):
        return buscar_en_internet(m.group(1).strip())

    m = re.search(r"\b(?:temporizador|alarma|avisame|recuerdame|cronometro)\b\D*?(\d+)\s*(segundos?|minutos?|horas?|seg|min|h)\b", t)
    if m:
        return temporizador(int(m.group(1)), m.group(2))

    m = re.search(r"\b(?:clima|tiempo hace|temperatura|va a llover|llueve)\b(?:.*?\b(?:en|de)\s+(.+))?", t)
    if m:
        ciudad = None
        # la ciudad tal como se escribió (con mayúsculas y acentos): lo que va tras el último "en"/"de"
        mo = re.search(r"(?i)\b(?:en|de)\s+([^¿?¡!.]+?)\s*[¿?¡!.]*$", original)
        if m.group(1) and mo and normalizar(mo.group(1)) not in ("hoy", "manana", "aqui", "ahora"):
            ciudad = mo.group(1).strip()
        return clima_de(ciudad or ciudad_del_sistema())

    conversion = calculo.convertir(t)
    if conversion:
        valor, unidad = conversion
        return Respuesta("Son %s %s." % (calculo.formato(round(valor, 4)), unidad))
    if re.search(r"\d", t) and not re.search(r"\b(volumen|temporizador|minutos?)\b", t):
        resultado = calculo.calcular(t)
        if resultado is not None:
            return Respuesta("Da %s." % calculo.formato(round(resultado, 6) if isinstance(resultado, float) else resultado))

    m = re.search(r"\b(?:busca|buscar|instala|instalar|descarga|descargar)\s+(.+?)(?:\s+en\s+(?:la\s+)?(?:tienda|store|kat store))?$", t)
    if m and not re.search(r"\b(archivo|archivos)\b", t):
        return buscar_en_tienda(m.group(1).strip())

    m = re.search(r"\b(?:abre|abrir|abreme|inicia|lanza|ejecuta|muestra|muestrame)\b\s+(?:el |la |los |las |mi |mis )?(.+)", t)
    if m:
        pedido = m.group(1)
        for clave, (_, _, palabras) in APPS.items():
            if any(re.search(r"\b%s\b" % re.escape(p), pedido) for p in palabras):
                return abrir_app(clave)
        abierto = abrir_programa(pedido)
        if abierto:
            return abierto
        return Respuesta("No encontré ningún programa llamado «%s»." % m.group(1), res.fallo("app desconocida"))

    if re.search(r"\b(silencia|silenciar|mute|calla)\b", t):
        return volumen(silencio=True)
    if re.search(r"\bquita(r)? (el )?silencio\b|\bactiva(r)? (el )?sonido\b", t):
        return volumen(silencio=False)
    m = re.search(r"\bvolumen (?:al |a )?(\d{1,3})\b", t)
    if m:
        return volumen(valor=int(m.group(1)))
    if re.search(r"\b(sube|subir|aumenta|mas)\b.*\bvolumen\b|\bvolumen\b.*\b(arriba|mas)\b", t):
        return volumen(cambio=10)
    if re.search(r"\b(baja|bajar|disminuye|menos)\b.*\bvolumen\b|\bvolumen\b.*\b(abajo|menos)\b", t):
        return volumen(cambio=-10)

    if re.search(r"\b(modo|tema) oscuro\b", t):
        return tema("oscuro")
    if re.search(r"\b(modo|tema) claro\b", t):
        return tema("claro")

    if re.search(r"\b(bloquea|bloquear|bloqueame)\b", t):
        return bloquear()
    if re.search(r"\bque hora\b|\bla hora\b|^hora$", t):
        return Respuesta("Son las %s." % datetime.datetime.now().strftime("%H:%M"))
    if re.search(r"\bque dia\b|\bfecha\b|\bque fecha\b", t):
        dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
        meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre",
                 "octubre", "noviembre", "diciembre"]
        h = datetime.date.today()
        return Respuesta("Hoy es %s %d de %s de %d." % (dias[h.weekday()], h.day, meses[h.month - 1], h.year))
    if re.search(r"\b(espacio|disco|almacenamiento)\b", t):
        return espacio_libre()
    if re.search(r"\b(memoria|ram)\b", t):
        pct, total = memoria_en_uso()
        return Respuesta("Estás usando el %d %% de tu memoria (%.0f GB en total)." % (pct, total))
    if re.search(r"\bnota\b|\bque tan segur|\bestoy segur|\bseguridad\b", t):
        return nota_seguridad()
    if re.search(r"\bchiste\b|\bhazme reir\b", t):
        return Respuesta(random.choice(CHISTES))
    if re.search(r"\b(ayuda|que puedes|que sabes|que haces|comandos)\b", t):
        return Respuesta(AYUDA)
    if re.search(r"\b(gracias|thank)\b", t):
        return Respuesta("¡De nada! 🐾")
    if re.search(r"\b(hola|buenas|hey|que tal|buenos dias|buenas tardes|buenas noches)\b", t):
        return Respuesta("¡Hola! Soy Kat 🐱. Pregúntame «qué puedes hacer».")
    if re.search(r"\b(quien eres|como te llamas|tu nombre)\b", t):
        return Respuesta("Soy Kat, la asistente de Kat OS. Vivo en esta orbe con orejas.")
    return Respuesta("Eso todavía no lo sé responder yo sola (llegará con Kat Local AI). "
                     "¿Lo busco en internet?", res.no_disponible("no lo entiendo aún"), buscar_web=original)
