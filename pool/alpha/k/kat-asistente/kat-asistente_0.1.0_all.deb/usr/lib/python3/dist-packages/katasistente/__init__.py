"""Kat, el asistente de Kat OS (Kat Assistant): una orbe animada con orejas de gato.

Versión 0.1: entiende órdenes escritas en español y las ejecuta de verdad
(abrir apps Kat, hora, espacio, volumen, tema, buscar en Kat Store,
bloquear, nota de seguridad). Lo que no sabe hacer lo dice: la voz y la
inteligencia artificial (Kat Local AI) llegarán en otra versión.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Asistente"
