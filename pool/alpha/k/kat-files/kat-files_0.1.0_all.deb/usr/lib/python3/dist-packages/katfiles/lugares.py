"""Lugares de la barra lateral: carpetas personales y discos.

Usa Qt (QStandardPaths, QStorageInfo), que da las carpetas correctas en
Linux (en español: "Escritorio", "Documentos"...) y en Windows.
"""

import os

from PySide6.QtCore import QStandardPaths, QStorageInfo

from katui import plataforma

CARPETAS = [
    ("Inicio", QStandardPaths.HomeLocation, "kat-cuenta", "user-home"),
    ("Escritorio", QStandardPaths.DesktopLocation, None, "user-desktop"),
    ("Documentos", QStandardPaths.DocumentsLocation, None, "folder-documents"),
    ("Descargas", QStandardPaths.DownloadLocation, None, "folder-download"),
    ("Imágenes", QStandardPaths.PicturesLocation, None, "folder-pictures"),
    ("Música", QStandardPaths.MusicLocation, None, "folder-music"),
    ("Videos", QStandardPaths.MoviesLocation, None, "folder-videos"),
]

FS_IGNORADOS = {b"tmpfs", b"devtmpfs", b"proc", b"sysfs", b"squashfs", b"overlay", b"efivarfs", b"cgroup2",
                b"securityfs", b"debugfs", b"tracefs", b"fusectl", b"configfs", b"pstore", b"bpf", b"mqueue",
                b"hugetlbfs", b"autofs", b"binfmt_misc", b"ramfs", b"nsfs", b"9p", b"drvfs"}


def carpetas_personales():
    """[(nombre, ruta, icono_kat, icono_tema)] que existen, sin repetir (si falta una, apunta a Inicio)."""
    salida, vistas = [], set()
    inicio = QStandardPaths.writableLocation(QStandardPaths.HomeLocation)
    for nombre, tipo, kat, tema in CARPETAS:
        ruta = QStandardPaths.writableLocation(tipo)
        if not ruta or not os.path.isdir(ruta):
            continue
        if ruta in vistas or (ruta == inicio and nombre != "Inicio"):
            continue
        vistas.add(ruta)
        salida.append((nombre, os.path.normpath(ruta), kat, tema))
    return salida


def discos():
    """[(nombre, ruta, libre, total)] de los discos/particiones que interesan al usuario."""
    salida = []
    for v in QStorageInfo.mountedVolumes():
        if not (v.isValid() and v.isReady()):
            continue
        ruta = v.rootPath()
        if plataforma.ES_LINUX:
            if ruta != "/" and not ruta.startswith(("/media/", "/run/media/", "/mnt/")):
                continue
            if ruta != "/" and bytes(v.fileSystemType()) in FS_IGNORADOS:
                continue
            nombre = "Kat OS (sistema)" if ruta == "/" else (v.displayName() or os.path.basename(ruta))
        else:
            letra = ruta.rstrip("\\/")
            nombre = "%s (%s)" % (v.name() or "Disco local", letra)
        salida.append((nombre, os.path.normpath(ruta), v.bytesAvailable(), v.bytesTotal()))
    return salida
