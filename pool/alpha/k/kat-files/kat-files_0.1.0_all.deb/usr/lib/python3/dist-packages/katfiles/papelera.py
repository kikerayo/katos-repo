"""Papelera de reciclaje.

- Mover a la papelera: QFile.moveToTrash de Qt, que usa la Papelera de
  reciclaje de Windows o la papelera estándar de Linux (la misma que Plasma).
- Ver, restaurar y vaciar: estándar freedesktop (~/.local/share/Trash) en Linux.
  En Windows esas tres cosas las hace la Papelera de reciclaje de Windows.
"""

import os
import shutil
from urllib.parse import unquote

from katui import acciones, plataforma


def carpeta():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "Trash")


def mover(rutas):
    from PySide6.QtCore import QFile
    errores = []
    for r in rutas:
        ok, _destino = QFile.moveToTrash(r)
        if not ok:
            errores.append(os.path.basename(r))
    if errores:
        return acciones.fallo("No se pudieron mandar a la papelera: %s" % ", ".join(errores[:3]))
    n = len(rutas)
    return acciones.hecho("%d elemento%s en la papelera" % (n, "" if n == 1 else "s"))


class Elemento:
    def __init__(self, nombre, ruta, original, fecha):
        self.nombre = nombre          # nombre dentro de la papelera
        self.ruta = ruta              # .../Trash/files/<nombre>
        self.original = original      # dónde estaba
        self.fecha = fecha            # "2026-11-16T19:00:00"


def leer_info(texto):
    """Lee un .trashinfo -> (ruta original, fecha)."""
    original = fecha = ""
    for linea in texto.splitlines():
        if linea.startswith("Path="):
            original = unquote(linea[5:])
        elif linea.startswith("DeletionDate="):
            fecha = linea[13:]
    return original, fecha


def listar():
    """Elementos en la papelera (Linux) o None en Windows."""
    if not plataforma.ES_LINUX:
        return None
    base = carpeta()
    archivos = os.path.join(base, "files")
    salida = []
    try:
        nombres = os.listdir(archivos)
    except OSError:
        return []
    for n in nombres:
        original, fecha = "", ""
        try:
            with open(os.path.join(base, "info", n + ".trashinfo"), encoding="utf-8") as f:
                original, fecha = leer_info(f.read())
        except OSError:
            pass
        salida.append(Elemento(n, os.path.join(archivos, n), original, fecha))
    salida.sort(key=lambda e: e.fecha, reverse=True)
    return salida


def restaurar(elementos):
    errores, hechos = [], 0
    for e in elementos:
        if not e.original:
            errores.append("«%s»: no se sabe de dónde vino" % e.nombre)
            continue
        destino_dir = os.path.dirname(e.original)
        try:
            os.makedirs(destino_dir, exist_ok=True)
            from .operaciones import nombre_libre
            final = os.path.join(destino_dir, nombre_libre(destino_dir, os.path.basename(e.original), "restaurado"))
            shutil.move(e.ruta, final)
            info = os.path.join(carpeta(), "info", e.nombre + ".trashinfo")
            if os.path.exists(info):
                os.remove(info)
            hechos += 1
        except OSError as ex:
            errores.append("«%s»: %s" % (e.nombre, ex.strerror))
    if errores:
        return acciones.fallo("%d restaurados; problemas: %s" % (hechos, "; ".join(errores[:3])))
    return acciones.hecho("%d elemento%s restaurado%s" % (hechos, "" if hechos == 1 else "s", "" if hechos == 1 else "s"))


def vaciar():
    if not plataforma.ES_LINUX:
        return acciones.no_disponible("En Windows se vacía desde la Papelera de reciclaje")
    base = carpeta()
    n = 0
    for sub in ("files", "info"):
        ruta = os.path.join(base, sub)
        if not os.path.isdir(ruta):
            continue
        for nombre in os.listdir(ruta):
            p = os.path.join(ruta, nombre)
            try:
                shutil.rmtree(p) if os.path.isdir(p) and not os.path.islink(p) else os.remove(p)
                if sub == "files":
                    n += 1
            except OSError as e:
                return acciones.fallo("No se pudo vaciar: %s" % e.strerror)
    return acciones.hecho("Papelera vaciada (%d elemento%s)" % (n, "" if n == 1 else "s"))
