"""Kat Files: el explorador de archivos de Kat OS.

- operaciones.py: copiar, mover, renombrar, carpetas nuevas, tamaños (Python puro).
- papelera.py:    papelera de reciclaje (estándar freedesktop en Linux).
- lugares.py:     carpetas personales y discos (Qt, funciona en Linux y Windows).
- ventana.py:     la interfaz.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Files"
