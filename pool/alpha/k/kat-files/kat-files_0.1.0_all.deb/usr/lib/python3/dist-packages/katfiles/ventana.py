"""Ventana de Kat Files: barra lateral con lugares, barra de dirección,
vista de iconos o de detalles, menú contextual y papelera.

Todo lo que toca archivos (pegar, papelera, borrar) va en segundo plano y
muestra su resultado real en la barra de estado.
"""

import os
import subprocess
import sys

from PySide6.QtCore import (
    QDir, QFileInfo, QMimeData, QObject, QProcess, QRunnable, QSize, Qt, QThreadPool, QUrl, Signal,
)
from PySide6.QtGui import QDesktopServices, QIcon, QImage, QImageReader, QKeySequence, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QDialog, QFileSystemModel, QFormLayout, QFrame, QHBoxLayout,
    QHeaderView, QInputDialog, QLabel, QLineEdit, QListView, QListWidget, QListWidgetItem, QMainWindow,
    QMenu, QMessageBox, QPushButton, QSplitter, QStackedWidget, QToolButton, QTreeView, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import plataforma, recursos
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import VERSION, lugares, operaciones, papelera

IMAGENES = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg", ".ico"}
TAM_MINI = 128
CORTAR_KDE = "application/x-kde-cutselection"


def _icono(nombre_kat, tema=None):
    ruta = recursos.icono(nombre_kat) if nombre_kat else None
    if ruta:
        return QIcon(ruta)
    return QIcon.fromTheme(tema or "folder")


# --- miniaturas de imágenes (en segundo plano) -----------------------------
class _Emisor(QObject):
    lista = Signal(str, QImage)


class _CargarMini(QRunnable):
    def __init__(self, ruta, emisor):
        super().__init__()
        self.ruta, self.emisor = ruta, emisor

    def run(self):
        lector = QImageReader(self.ruta)
        lector.setAutoTransform(True)
        tam = lector.size()
        if tam.isValid() and (tam.width() > TAM_MINI or tam.height() > TAM_MINI):
            lector.setScaledSize(tam.scaled(TAM_MINI, TAM_MINI, Qt.KeepAspectRatio))
        img = lector.read()
        self.emisor.lista.emit(self.ruta, img)


class ModeloArchivos(QFileSystemModel):
    def __init__(self):
        super().__init__()
        self.miniaturas = True
        self._cache, self._pendientes = {}, set()
        self._emisor = _Emisor()
        self._emisor.lista.connect(self._mini_lista)
        self._pool = QThreadPool()
        self._pool.setMaxThreadCount(2)

    def data(self, index, rol_=Qt.DisplayRole):
        if rol_ == Qt.DecorationRole and self.miniaturas and index.column() == 0:
            ruta = self.filePath(index)
            if os.path.splitext(ruta)[1].lower() in IMAGENES:
                icono = self._cache.get(ruta)
                if icono is not None:
                    return icono
                if ruta not in self._pendientes:
                    self._pendientes.add(ruta)
                    self._pool.start(_CargarMini(ruta, self._emisor))
        return super().data(index, rol_)

    def cerrar(self):
        self.miniaturas = False
        self._pool.clear()
        self._pool.waitForDone(3000)

    def _mini_lista(self, ruta, img):
        self._pendientes.discard(ruta)
        if img.isNull():
            return
        self._cache[ruta] = QIcon(QPixmap.fromImage(img))
        if len(self._cache) > 600:                # no llenar la memoria
            self._cache.pop(next(iter(self._cache)))
        i = self.index(ruta)
        if i.isValid():
            self.dataChanged.emit(i, i, [Qt.DecorationRole])


# --- diálogo de propiedades -------------------------------------------------
class Propiedades(QDialog):
    def __init__(self, ruta, padre=None):
        super().__init__(padre)
        info = QFileInfo(ruta)
        self.setWindowTitle("Propiedades de %s" % (info.fileName() or ruta))
        self.setMinimumWidth(420)
        f = QFormLayout(self)
        f.addRow("Nombre:", QLabel(info.fileName() or ruta))
        ubic = QLabel(info.absolutePath())
        ubic.setTextInteractionFlags(Qt.TextSelectableByMouse)
        ubic.setWordWrap(True)
        f.addRow("Ubicación:", ubic)
        tipo = "Carpeta" if info.isDir() else ("Archivo %s" % info.suffix().upper() if info.suffix() else "Archivo")
        if info.isSymLink():
            tipo += " (enlace a %s)" % info.symLinkTarget()
        f.addRow("Tipo:", QLabel(tipo))
        self.tamano = QLabel("Calculando…" if info.isDir() else operaciones.formato_tamano(info.size()))
        f.addRow("Tamaño:", self.tamano)
        f.addRow("Modificado:", QLabel(info.lastModified().toString("d/M/yyyy HH:mm")))
        cerrar = QPushButton("Cerrar")
        cerrar.clicked.connect(self.accept)
        f.addRow("", cerrar)
        self._cancelado = False
        if info.isDir():
            def fin(r):
                if not self._cancelado:
                    total, archivos, carpetas = r
                    self.tamano.setText("%s  (%d archivos, %d carpetas)" % (operaciones.formato_tamano(total),
                                                                             archivos, carpetas))
            en_segundo_plano(operaciones.tamano_total, ruta, lambda: self._cancelado, al_terminar=fin)
        self.finished.connect(lambda _: setattr(self, "_cancelado", True))


# --- página de la papelera -----------------------------------------------
class PaginaPapelera(QWidget):
    def __init__(self, ventana):
        super().__init__()
        self.ventana = ventana
        caja = QVBoxLayout(self)
        caja.setContentsMargins(16, 12, 16, 12)
        caja.addWidget(rol(QLabel("Papelera"), "titulo"))
        self.aviso = rol(QLabel(""), "subtitulo")
        self.aviso.setWordWrap(True)
        caja.addWidget(self.aviso)
        self.lista = QTreeWidget()
        self.lista.setHeaderLabels(["Nombre", "Estaba en", "Borrado"])
        self.lista.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lista.setRootIsDecorated(False)
        self.lista.header().setSectionResizeMode(1, QHeaderView.Stretch)
        caja.addWidget(self.lista, 1)
        fila = QHBoxLayout()
        self.restaurar = QPushButton("Restaurar")
        self.restaurar.clicked.connect(self._restaurar)
        self.vaciar = QPushButton("Vaciar papelera")
        self.vaciar.clicked.connect(self._vaciar)
        self.abrir_windows = QPushButton("Abrir la Papelera de reciclaje de Windows")
        self.abrir_windows.clicked.connect(lambda: QProcess.startDetached("explorer.exe", ["shell:RecycleBinFolder"]))
        fila.addWidget(self.restaurar)
        fila.addStretch(1)
        fila.addWidget(self.abrir_windows)
        fila.addWidget(self.vaciar)
        caja.addLayout(fila)

    def cargar(self):
        self.lista.clear()
        elementos = papelera.listar()
        if elementos is None:
            self.aviso.setText("En Windows, Kat Files manda los archivos a la Papelera de reciclaje de Windows. "
                               "Para verlos, restaurarlos o vaciarla, ábrela con el botón de abajo.")
            for b in (self.restaurar, self.vaciar):
                b.setEnabled(False)
            self.abrir_windows.setVisible(True)
            return
        self.abrir_windows.setVisible(False)
        self.aviso.setText("%d elemento%s. Puedes restaurarlos a donde estaban o vaciar la papelera."
                           % (len(elementos), "" if len(elementos) == 1 else "s"))
        for e in elementos:
            item = QTreeWidgetItem([e.nombre, os.path.dirname(e.original) if e.original else "?",
                                    e.fecha.replace("T", " ")])
            item.setData(0, Qt.UserRole, e)
            self.lista.addTopLevelItem(item)
        self.restaurar.setEnabled(bool(elementos))
        self.vaciar.setEnabled(bool(elementos))

    def _restaurar(self):
        elegidos = [i.data(0, Qt.UserRole) for i in self.lista.selectedItems()]
        if not elegidos:
            self.ventana.estado.mostrar(res.fallo("Elige qué restaurar"))
            return
        self.ventana.estado.mostrar(papelera.restaurar(elegidos))
        self.cargar()

    def _vaciar(self):
        if QMessageBox.question(self, "Vaciar papelera",
                                "¿Borrar para siempre todo lo que hay en la papelera?\nNo se puede deshacer.") \
                != QMessageBox.Yes:
            return
        self.ventana.estado.mostrar(papelera.vaciar())
        self.cargar()


# --- ventana principal -----------------------------------------------------
class VentanaFiles(QMainWindow):
    def __init__(self, ruta_inicial=None):
        super().__init__()
        self.setWindowTitle("Kat Files")
        self.setWindowIcon(_icono("kat-files", "system-file-manager"))
        self.resize(1100, 680)
        self.atras_pila, self.adelante_pila = [], []
        self.actual = None
        self._cortar_interno = False

        self.modelo = ModeloArchivos()
        self.modelo.setRootPath("")
        self.modelo.setReadOnly(False)            # permite arrastrar y soltar
        self._filtro_base = QDir.AllEntries | QDir.NoDotAndDotDot | QDir.AllDirs
        self.modelo.setFilter(self._filtro_base)
        self.modelo.setNameFilterDisables(False)
        # La carpeta se lee en segundo plano: contar cuando termina de cargar.
        self.modelo.directoryLoaded.connect(lambda _r: self._contar())
        self.modelo.rowsInserted.connect(lambda *_: self._contar())
        self.modelo.rowsRemoved.connect(lambda *_: self._contar())

        central = QWidget()
        raiz = QVBoxLayout(central)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)
        raiz.addWidget(self._barra())
        divisor = QSplitter()
        divisor.addWidget(self._lateral())
        divisor.addWidget(self._vistas())
        divisor.setStretchFactor(1, 1)
        divisor.setSizes([230, 870])
        raiz.addWidget(divisor, 1)
        self.setCentralWidget(central)

        self.estado = EtiquetaResultado()
        self.cuenta = QLabel("")
        self.libre = QLabel("")
        self.statusBar().addWidget(self.cuenta)
        self.statusBar().addWidget(self.estado, 1)
        self.statusBar().addPermanentWidget(self.libre)
        self._atajos()
        self.ir(ruta_inicial or os.path.expanduser("~"), historial=False)

    # --- construcción ---------------------------------------------------
    def _barra(self):
        barra = rol(QFrame(), "lateral")
        fila = QHBoxLayout(barra)
        fila.setContentsMargins(8, 6, 8, 6)

        def boton(texto, consejo, accion):
            b = QToolButton()
            b.setText(texto)
            b.setToolTip(consejo)
            b.setMinimumSize(34, 32)
            b.clicked.connect(accion)
            fila.addWidget(b)
            return b

        self.b_atras = boton("←", "Atrás (Alt+←)", self.atras)
        self.b_adelante = boton("→", "Adelante (Alt+→)", self.adelante)
        boton("↑", "Subir una carpeta (Retroceso)", self.subir)
        boton("⟳", "Actualizar (F5)", self.actualizar)
        self.direccion = QLineEdit()
        self.direccion.setPlaceholderText("Escribe una ruta y pulsa Enter")
        self.direccion.returnPressed.connect(lambda: self.ir(self.direccion.text().strip()))
        fila.addWidget(self.direccion, 1)
        self.busqueda = QLineEdit()
        self.busqueda.setPlaceholderText("Buscar aquí (Enter: también en subcarpetas)")
        self.busqueda.setClearButtonEnabled(True)
        self.busqueda.setMaximumWidth(300)
        self.busqueda.textChanged.connect(self._filtrar)
        self.busqueda.returnPressed.connect(self._buscar_profundo)
        fila.addWidget(self.busqueda)
        boton("▦", "Vista de iconos", lambda: self.poner_vista(0))
        boton("☰", "Vista de detalles", lambda: self.poner_vista(1))
        nueva = rol(QPushButton("+ Carpeta"), "principal")
        nueva.setToolTip("Carpeta nueva (Ctrl+Mayús+N)")
        nueva.clicked.connect(self.nueva_carpeta)
        fila.addWidget(nueva)
        return barra

    def _lateral(self):
        self.lugares = QListWidget()
        self.lugares.setIconSize(QSize(20, 20))
        self.lugares.setMinimumWidth(190)
        self.lugares.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.lugares.setTextElideMode(Qt.ElideRight)
        self.lugares.itemClicked.connect(self._lugar_elegido)
        self._llenar_lugares()
        return self.lugares

    def _titulo_lateral(self, texto):
        item = QListWidgetItem(texto.upper())
        item.setFlags(Qt.NoItemFlags)
        item.setForeground(Qt.gray)
        self.lugares.addItem(item)

    def _llenar_lugares(self):
        self.lugares.clear()
        self._titulo_lateral("Lugares")
        proveedor = self.modelo.iconProvider()
        for nombre, ruta, kat, tema in lugares.carpetas_personales():
            icono = _icono(kat, tema)
            if icono.isNull():                    # Windows no tiene iconos de tema: usar los del sistema
                icono = proveedor.icon(QFileInfo(ruta))
            item = QListWidgetItem(icono, nombre)
            item.setData(Qt.UserRole, ruta)
            self.lugares.addItem(item)
        item = QListWidgetItem(_icono("kat-papelera-vacia", "user-trash"), "Papelera")
        item.setData(Qt.UserRole, "::papelera")
        self.lugares.addItem(item)
        self._titulo_lateral("Discos")
        for nombre, ruta, libre, total in lugares.discos():
            item = QListWidgetItem(_icono("kat-almacenamiento", "drive-harddisk"), nombre)
            item.setData(Qt.UserRole, ruta)
            item.setToolTip("%s libres de %s" % (operaciones.formato_tamano(libre), operaciones.formato_tamano(total)))
            self.lugares.addItem(item)

    def _vistas(self):
        self.pila = QStackedWidget()
        self.iconos = QListView()
        self.iconos.setViewMode(QListView.IconMode)
        self.iconos.setIconSize(QSize(64, 64))
        self.iconos.setGridSize(QSize(116, 108))
        self.iconos.setResizeMode(QListView.Adjust)
        self.iconos.setWordWrap(True)
        self.iconos.setUniformItemSizes(True)
        self.detalles = QTreeView()
        self.detalles.setRootIsDecorated(False)
        self.detalles.setSortingEnabled(True)
        self.detalles.sortByColumn(0, Qt.AscendingOrder)
        self.detalles.setUniformRowHeights(True)
        self.detalles.setItemsExpandable(False)
        for v in (self.iconos, self.detalles):
            v.setModel(self.modelo)
            v.setSelectionMode(QAbstractItemView.ExtendedSelection)
            v.setEditTriggers(QAbstractItemView.NoEditTriggers)
            v.setDragDropMode(QAbstractItemView.DragDrop)
            v.setDefaultDropAction(Qt.MoveAction)
            v.setContextMenuPolicy(Qt.CustomContextMenu)
            v.customContextMenuRequested.connect(self._menu)
            v.activated.connect(self._activar)
        self.detalles.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.detalles.selectionModel().selectionChanged.connect(self._seleccion)
        self.iconos.selectionModel().selectionChanged.connect(self._seleccion)
        self.pila.addWidget(self.iconos)
        self.pila.addWidget(self.detalles)
        self.pagina_papelera = PaginaPapelera(self)
        self.pila.addWidget(self.pagina_papelera)
        self.resultados = QTreeWidget()
        self.resultados.setHeaderLabels(["Nombre", "Carpeta"])
        self.resultados.setRootIsDecorated(False)
        self.resultados.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.resultados.itemActivated.connect(lambda it: self._abrir_ruta(it.data(0, Qt.UserRole)))
        self.pila.addWidget(self.resultados)
        self._vista = 0
        return self.pila

    def _atajos(self):
        pares = [
            (QKeySequence.Copy, lambda: self.copiar(False)), (QKeySequence.Cut, lambda: self.copiar(True)),
            (QKeySequence.Paste, self.pegar), (Qt.Key_Delete, self.a_papelera),
            (QKeySequence("Shift+Del"), self.borrar_definitivo), (Qt.Key_F2, self.renombrar),
            (Qt.Key_F5, self.actualizar), (QKeySequence("Alt+Left"), self.atras),
            (QKeySequence("Alt+Right"), self.adelante), (Qt.Key_Backspace, self.subir),
            (QKeySequence("Ctrl+L"), lambda: (self.direccion.setFocus(), self.direccion.selectAll())),
            (QKeySequence("Ctrl+F"), lambda: self.busqueda.setFocus()),
            (QKeySequence("Ctrl+H"), self.alternar_ocultos), (QKeySequence("Ctrl+Shift+N"), self.nueva_carpeta),
            (QKeySequence("Alt+Return"), self.propiedades),
        ]
        self._atajos_vivos = []
        for tecla, accion in pares:
            s = QShortcut(QKeySequence(tecla), self)
            s.setContext(Qt.WindowShortcut)
            s.activated.connect(accion)
            self._atajos_vivos.append(s)

    def closeEvent(self, evento):
        # Esperar a las miniaturas que se estén cargando: si la ventana se borra
        # con hilos trabajando, el programa se cierra con un error de memoria.
        self.modelo.cerrar()
        super().closeEvent(evento)

    # --- navegación --------------------------------------------------------
    def vista(self):
        return self.iconos if self._vista == 0 else self.detalles

    def poner_vista(self, n):
        self._vista = n
        self.modelo.miniaturas = n == 0
        if self.actual and self.actual != "::papelera":
            self.pila.setCurrentIndex(n)

    def ir(self, ruta, historial=True):
        if ruta == "::papelera":
            if historial and self.actual:
                self.atras_pila.append(self.actual)
                self.adelante_pila.clear()
            self.actual = ruta
            self.direccion.setText("Papelera")
            self.pila.setCurrentWidget(self.pagina_papelera)
            self.pagina_papelera.cargar()
            self._botones()
            return
        ruta = os.path.expanduser(ruta)
        if not os.path.isdir(ruta):
            if os.path.isfile(ruta):
                self._abrir_ruta(ruta)
            else:
                self.estado.mostrar(res.fallo("No existe la carpeta «%s»" % ruta))
            self.direccion.setText(self.actual if self.actual != "::papelera" else "Papelera")
            return
        if not os.access(ruta, os.R_OK | os.X_OK):
            self.estado.mostrar(res.fallo("No tienes permiso para abrir «%s»" % ruta))
            return
        ruta = os.path.normpath(os.path.abspath(ruta))
        if historial and self.actual and self.actual != ruta:
            self.atras_pila.append(self.actual)
            self.adelante_pila.clear()
        self.actual = ruta
        self.busqueda.blockSignals(True)
        self.busqueda.clear()
        self.busqueda.blockSignals(False)
        self.modelo.setNameFilters([])
        indice = self.modelo.setRootPath(ruta)
        for v in (self.iconos, self.detalles):
            v.setRootIndex(indice)
            v.clearSelection()
        self.pila.setCurrentIndex(self._vista)
        self.direccion.setText(ruta)
        self.setWindowTitle("%s — Kat Files" % (os.path.basename(ruta) or ruta))
        self.estado.mostrar(None)
        self._botones()
        self._contar()

    def _botones(self):
        self.b_atras.setEnabled(bool(self.atras_pila))
        self.b_adelante.setEnabled(bool(self.adelante_pila))

    def atras(self):
        if self.atras_pila:
            self.adelante_pila.append(self.actual)
            self.ir(self.atras_pila.pop(), historial=False)

    def adelante(self):
        if self.adelante_pila:
            self.atras_pila.append(self.actual)
            self.ir(self.adelante_pila.pop(), historial=False)

    def subir(self):
        if self.direccion.hasFocus() or self.busqueda.hasFocus():
            return
        if self.actual and self.actual != "::papelera":
            padre = os.path.dirname(self.actual)
            if padre and padre != self.actual:
                self.ir(padre)

    def actualizar(self):
        if self.actual == "::papelera":
            self.pagina_papelera.cargar()
        elif self.actual:
            self.ir(self.actual, historial=False)
        self._llenar_lugares()

    def _lugar_elegido(self, item):
        ruta = item.data(Qt.UserRole)
        if ruta:
            self.ir(ruta)

    # --- abrir -------------------------------------------------------------
    def _activar(self, indice):
        self._abrir_ruta(self.modelo.filePath(indice))

    def _abrir_ruta(self, ruta):
        if not ruta:
            return
        if os.path.isdir(ruta):
            self.ir(ruta)
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(ruta)):
            self.estado.mostrar(res.fallo("No hay ningún programa para abrir «%s»" % os.path.basename(ruta)))

    # --- selección ----------------------------------------------------------
    def seleccion(self):
        indices = self.vista().selectionModel().selectedRows(0) if self._vista == 1 else \
            self.vista().selectionModel().selectedIndexes()
        rutas = []
        for i in indices:
            r = self.modelo.filePath(i)
            if r not in rutas:
                rutas.append(r)
        return rutas

    def _seleccion(self, *_):
        self._contar()

    def _contar(self):
        if not self.actual or self.actual == "::papelera":
            return
        raiz = self.vista().rootIndex()
        total = self.modelo.rowCount(raiz)
        sel = self.seleccion()
        texto = "%d elemento%s" % (total, "" if total == 1 else "s")
        if sel:
            tam = sum(os.path.getsize(r) for r in sel if os.path.isfile(r))
            texto += "  ·  %d seleccionado%s%s" % (len(sel), "" if len(sel) == 1 else "s",
                                                   ("  (%s)" % operaciones.formato_tamano(tam)) if tam else "")
        self.cuenta.setText(texto + "   ")
        try:
            import shutil
            uso = shutil.disk_usage(self.actual)
            self.libre.setText("%s libres" % operaciones.formato_tamano(uso.free))
        except OSError:
            self.libre.setText("")

    # --- búsqueda ------------------------------------------------------------
    def _filtrar(self, texto):
        texto = texto.strip()
        self.modelo.setNameFilters(["*%s*" % texto] if texto else [])
        if self.actual and self.actual != "::papelera":
            self.pila.setCurrentIndex(self._vista)

    def _buscar_profundo(self):
        texto = self.busqueda.text().strip()
        if not texto or not self.actual or self.actual == "::papelera":
            return
        base = self.actual
        self.estado.trabajando("Buscando «%s» en %s y sus subcarpetas…" % (texto, base))

        def fin(hallados):
            if isinstance(hallados, res.Resultado):
                self.estado.mostrar(hallados)
                return
            self.resultados.clear()
            for ruta in hallados:
                item = QTreeWidgetItem([os.path.basename(ruta), os.path.dirname(ruta)])
                item.setIcon(0, self.modelo.iconProvider().icon(QFileInfo(ruta)))
                item.setData(0, Qt.UserRole, ruta)
                self.resultados.addTopLevelItem(item)
            self.pila.setCurrentWidget(self.resultados)
            self.estado.mostrar(res.hecho("%d resultado%s para «%s»" % (len(hallados), "" if len(hallados) == 1
                                                                        else "s", texto)))
        en_segundo_plano(operaciones.buscar, base, texto, al_terminar=fin)

    # --- portapapeles ----------------------------------------------------------
    def copiar(self, cortar):
        if self.direccion.hasFocus() or self.busqueda.hasFocus():
            (self.direccion if self.direccion.hasFocus() else self.busqueda).copy()
            return
        rutas = self.seleccion()
        if not rutas:
            return
        datos = QMimeData()
        datos.setUrls([QUrl.fromLocalFile(r) for r in rutas])
        datos.setText("\n".join(rutas))
        if cortar:
            datos.setData(CORTAR_KDE, b"1")
        QApplication.clipboard().setMimeData(datos)
        self._cortar_interno = cortar
        self.estado.mostrar(res.hecho("%d elemento%s %s" % (len(rutas), "" if len(rutas) == 1 else "s",
                                                           "para mover" if cortar else "copiado" +
                                                           ("" if len(rutas) == 1 else "s"))))

    def pegar(self):
        if self.direccion.hasFocus() or self.busqueda.hasFocus():
            (self.direccion if self.direccion.hasFocus() else self.busqueda).paste()
            return
        if not self.actual or self.actual == "::papelera":
            return
        datos = QApplication.clipboard().mimeData()
        rutas = [u.toLocalFile() for u in datos.urls() if u.isLocalFile()] if datos else []
        if not rutas:
            self.estado.mostrar(res.fallo("No hay nada copiado"))
            return
        mover = bool(datos.data(CORTAR_KDE) == b"1") or self._cortar_interno
        destino = self.actual
        self.estado.trabajando("%s %d elemento%s…" % ("Moviendo" if mover else "Copiando", len(rutas),
                                                     "" if len(rutas) == 1 else "s"))

        def fin(r):
            resultado = r[0] if isinstance(r, tuple) else r
            self.estado.mostrar(resultado)
            if mover and resultado.ok:
                QApplication.clipboard().clear()
                self._cortar_interno = False
        en_segundo_plano(operaciones.pegar, rutas, destino, mover, al_terminar=fin)

    # --- crear, renombrar, borrar ---------------------------------------------
    def nueva_carpeta(self):
        if not self.actual or self.actual == "::papelera":
            return
        nombre, ok = QInputDialog.getText(self, "Carpeta nueva", "Nombre de la carpeta:", text="Carpeta nueva")
        if not ok:
            return
        r, ruta = operaciones.nueva_carpeta(self.actual, nombre.strip())
        self.estado.mostrar(r)
        if ruta:
            i = self.modelo.index(ruta)
            self.vista().setCurrentIndex(i)

    def renombrar(self):
        sel = self.seleccion()
        if len(sel) != 1:
            if sel:
                self.estado.mostrar(res.fallo("Elige un solo elemento para renombrar"))
            return
        viejo = os.path.basename(sel[0])
        nuevo, ok = QInputDialog.getText(self, "Renombrar", "Nombre nuevo:", text=viejo)
        if ok and nuevo != viejo:
            r, _ = operaciones.renombrar(sel[0], nuevo)
            self.estado.mostrar(r)

    def a_papelera(self):
        if self.direccion.hasFocus() or self.busqueda.hasFocus():
            return
        sel = self.seleccion()
        if sel:
            self.estado.mostrar(papelera.mover(sel))

    def borrar_definitivo(self):
        sel = self.seleccion()
        if not sel:
            return
        if QMessageBox.question(self, "Borrar para siempre",
                                "¿Borrar %d elemento%s para siempre?\nNo irá a la papelera y no se puede deshacer."
                                % (len(sel), "" if len(sel) == 1 else "s")) != QMessageBox.Yes:
            return
        self.estado.trabajando("Borrando…")
        en_segundo_plano(operaciones.borrar_definitivo, sel, al_terminar=self.estado.mostrar)

    def alternar_ocultos(self):
        filtro = self.modelo.filter()
        self.modelo.setFilter(filtro ^ QDir.Hidden)
        visibles = bool(self.modelo.filter() & QDir.Hidden)
        self.estado.mostrar(res.hecho("Archivos ocultos %s" % ("visibles" if visibles else "escondidos")))

    def propiedades(self):
        sel = self.seleccion()
        ruta = sel[0] if sel else self.actual
        if ruta and ruta != "::papelera":
            Propiedades(ruta, self).exec()

    # "Abrir terminal aquí" vuelve cuando exista Kat Terminal (regla: las apps
    # Kat no abren apps de Plasma/KDE como Konsole).

    def copiar_ruta(self):
        sel = self.seleccion() or [self.actual]
        QApplication.clipboard().setText("\n".join(sel))
        self.estado.mostrar(res.hecho("Ruta copiada"))

    # --- menú contextual ---------------------------------------------------
    def _menu(self, punto):
        v = self.vista()
        indice = v.indexAt(punto)
        if indice.isValid() and not v.selectionModel().isSelected(indice):
            v.setCurrentIndex(indice)
        sel = self.seleccion() if indice.isValid() else []
        m = QMenu(self)
        if sel:
            m.addAction("Abrir", lambda: [self._abrir_ruta(r) for r in sel])
            m.addSeparator()
            m.addAction("Copiar\tCtrl+C", lambda: self.copiar(False))
            m.addAction("Cortar\tCtrl+X", lambda: self.copiar(True))
        m.addAction("Pegar\tCtrl+V", self.pegar)
        if sel:
            m.addSeparator()
            if len(sel) == 1:
                m.addAction("Renombrar\tF2", self.renombrar)
            m.addAction("Mover a la papelera\tSupr", self.a_papelera)
            m.addAction("Borrar para siempre\tMayús+Supr", self.borrar_definitivo)
        else:
            m.addAction("Carpeta nueva\tCtrl+Mayús+N", self.nueva_carpeta)
            m.addAction("Mostrar u ocultar archivos ocultos\tCtrl+H", self.alternar_ocultos)
        m.addSeparator()
        m.addAction("Copiar ruta", self.copiar_ruta)
        m.addAction("Propiedades\tAlt+Enter", self.propiedades)
        m.exec(v.viewport().mapToGlobal(punto))
