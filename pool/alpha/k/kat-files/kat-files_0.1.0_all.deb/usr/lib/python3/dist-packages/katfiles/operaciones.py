"""Operaciones con archivos, en Python puro (iguales en Linux y Windows).

Todas devuelven un Resultado de katui (hecho / falló con motivo) y nunca
sobrescriben nada: si el nombre ya existe se usa "nombre (copia).ext".
"""

import os
import re
import shutil

from katui import acciones

PROHIBIDOS_WINDOWS = set('<>:"/\\|?*')
RESERVADOS_WINDOWS = {"CON", "PRN", "AUX", "NUL"} | {"COM%d" % i for i in range(1, 10)} | \
                     {"LPT%d" % i for i in range(1, 10)}


def validar_nombre(nombre):
    """Devuelve None si el nombre sirve, o el motivo si no."""
    if not nombre or not nombre.strip():
        return "El nombre está vacío"
    if nombre in (".", ".."):
        return "Ese nombre está reservado"
    if "/" in nombre or "\0" in nombre:
        return "El nombre no puede llevar '/'"
    if os.name == "nt":
        if set(nombre) & PROHIBIDOS_WINDOWS:
            return "El nombre no puede llevar ninguno de estos: < > : \" / \\ | ? *"
        if nombre.split(".")[0].upper() in RESERVADOS_WINDOWS:
            return "Windows reserva ese nombre"
        if nombre.endswith((" ", ".")):
            return "El nombre no puede terminar en espacio o punto"
    if len(nombre.encode("utf-8")) > 255:
        return "El nombre es demasiado largo"
    return None


def nombre_libre(carpeta, nombre, sufijo="copia"):
    """'foto.png' -> 'foto (copia).png', 'foto (copia 2).png'... el primero que no exista."""
    if not os.path.lexists(os.path.join(carpeta, nombre)):
        return nombre
    base, ext = os.path.splitext(nombre)
    if os.path.isdir(os.path.join(carpeta, nombre)):
        base, ext = nombre, ""
    base = re.sub(r" \(%s( \d+)?\)$" % sufijo, "", base)
    n = 1
    while True:
        candidato = "%s (%s%s)%s" % (base, sufijo, "" if n == 1 else " %d" % n, ext)
        if not os.path.lexists(os.path.join(carpeta, candidato)):
            return candidato
        n += 1


def _dentro_de(hijo, padre):
    hijo, padre = os.path.realpath(hijo), os.path.realpath(padre)
    return hijo == padre or hijo.startswith(padre.rstrip(os.sep) + os.sep)


def nueva_carpeta(carpeta, nombre="Carpeta nueva"):
    error = validar_nombre(nombre)
    if error:
        return acciones.fallo(error), None
    nombre = nombre_libre(carpeta, nombre, "nueva")
    ruta = os.path.join(carpeta, nombre)
    try:
        os.mkdir(ruta)
    except OSError as e:
        return acciones.fallo("No se pudo crear la carpeta: %s" % e.strerror), None
    return acciones.hecho("Carpeta «%s» creada" % nombre), ruta


def renombrar(ruta, nuevo):
    nuevo = nuevo.strip() if nuevo else nuevo
    error = validar_nombre(nuevo)
    if error:
        return acciones.fallo(error), ruta
    destino = os.path.join(os.path.dirname(ruta), nuevo)
    if os.path.normcase(destino) == os.path.normcase(ruta) and destino == ruta:
        return acciones.hecho("Sin cambios"), ruta
    if os.path.lexists(destino) and os.path.normcase(destino) != os.path.normcase(ruta):
        return acciones.fallo("Ya existe «%s» en esta carpeta" % nuevo), ruta
    try:
        os.rename(ruta, destino)
    except OSError as e:
        return acciones.fallo("No se pudo renombrar: %s" % e.strerror), ruta
    return acciones.hecho("Renombrado a «%s»" % nuevo), destino


def tamano_total(ruta, cancelar=None):
    """(bytes, archivos, carpetas) de un archivo o carpeta, sin seguir enlaces."""
    if os.path.isfile(ruta) or os.path.islink(ruta):
        try:
            return os.lstat(ruta).st_size, 1, 0
        except OSError:
            return 0, 0, 0
    total = archivos = carpetas = 0
    for raiz, dirs, nombres in os.walk(ruta, onerror=lambda e: None):
        if cancelar and cancelar():
            break
        carpetas += len(dirs)
        for n in nombres:
            try:
                total += os.lstat(os.path.join(raiz, n)).st_size
                archivos += 1
            except OSError:
                pass
    return total, archivos, carpetas


def formato_tamano(b):
    for unidad in ("bytes", "KB", "MB", "GB", "TB"):
        if b < 1024 or unidad == "TB":
            return ("%d %s" % (b, unidad)) if unidad == "bytes" else ("%.1f %s" % (b, unidad))
        b /= 1024.0


def pegar(origenes, destino, mover=False, progreso=None, cancelar=None):
    """Copia (o mueve) 'origenes' dentro de la carpeta 'destino'.

    progreso(hechos, total, nombre) se llama tras cada elemento.
    Devuelve (Resultado, rutas_nuevas).
    """
    if not os.path.isdir(destino):
        return acciones.fallo("El destino no es una carpeta"), []
    nuevas, errores = [], []
    total = len(origenes)
    for i, origen in enumerate(origenes):
        if cancelar and cancelar():
            errores.append("cancelado por ti")
            break
        nombre = os.path.basename(os.path.normpath(origen))
        if not os.path.lexists(origen):
            errores.append("«%s» ya no existe" % nombre)
            continue
        if os.path.isdir(origen) and _dentro_de(destino, origen):
            errores.append("no se puede poner «%s» dentro de sí misma" % nombre)
            continue
        misma_carpeta = os.path.realpath(os.path.dirname(os.path.normpath(origen))) == os.path.realpath(destino)
        if mover and misma_carpeta:
            nuevas.append(origen)          # mover al mismo sitio: no hace nada
            continue
        final = os.path.join(destino, nombre_libre(destino, nombre))
        try:
            if mover:
                shutil.move(origen, final)
            elif os.path.isdir(origen) and not os.path.islink(origen):
                shutil.copytree(origen, final, symlinks=True)
            else:
                shutil.copy2(origen, final, follow_symlinks=False)
            nuevas.append(final)
        except (OSError, shutil.Error) as e:
            errores.append("«%s»: %s" % (nombre, getattr(e, "strerror", None) or e))
        if progreso:
            progreso(i + 1, total, nombre)
    verbo = "movido" if mover else "copiado"
    if errores:
        hechos = len(nuevas)
        return acciones.fallo("%d %s, %d con problemas: %s" % (hechos, verbo + ("s" if hechos != 1 else ""),
                                                                len(errores), "; ".join(errores[:3]))), nuevas
    return acciones.hecho("%d elemento%s %s%s" % (len(nuevas), "" if len(nuevas) == 1 else "s", verbo,
                                                  "" if len(nuevas) == 1 else "s")), nuevas


def borrar_definitivo(rutas):
    errores = []
    for r in rutas:
        try:
            if os.path.isdir(r) and not os.path.islink(r):
                shutil.rmtree(r)
            else:
                os.remove(r)
        except OSError as e:
            errores.append("«%s»: %s" % (os.path.basename(r), e.strerror))
    if errores:
        return acciones.fallo("No se pudo borrar: " + "; ".join(errores[:3]))
    return acciones.hecho("%d elemento%s borrado%s para siempre" % (len(rutas), "" if len(rutas) == 1 else "s",
                                                                     "" if len(rutas) == 1 else "s"))


def buscar(carpeta, texto, limite=2000, cancelar=None):
    """Busca 'texto' (sin distinguir mayúsculas) en los nombres, dentro de subcarpetas."""
    texto = texto.lower()
    hallados = []
    for raiz, dirs, nombres in os.walk(carpeta, onerror=lambda e: None):
        if cancelar and cancelar():
            break
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        for n in dirs + nombres:
            if texto in n.lower():
                hallados.append(os.path.join(raiz, n))
                if len(hallados) >= limite:
                    return hallados
    return hallados
