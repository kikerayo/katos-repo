"""Punto de entrada de Kat Files.  Uso: kat-files [carpeta]"""

import os
import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtCore import QUrl
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaFiles

    ruta = None
    for a in argv:
        if not a.startswith("-"):
            ruta = QUrl(a).toLocalFile() if a.startswith("file:") else a
            break
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Files")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaFiles(os.path.abspath(ruta) if ruta else None)
    v.show()
    try:
        from katcore.cliente import KatCoreCliente
        KatCoreCliente().registrar_app(APP_ID, VERSION)
    except Exception:
        pass
    codigo = app.exec()
    v.modelo.cerrar()
    del v            # borrar la ventana antes que la aplicación (cierre limpio)
    return codigo
