"""Ventana de Kat Update Center.

Arriba el estado (al día / hay actualizaciones / falta reiniciar) y los
botones; abajo pestañas con lo pendiente del sistema, de las apps, el
historial y el registro en vivo de lo que se está haciendo.
"""

from PySide6.QtCore import QProcess, Qt
from PySide6.QtGui import QFont, QIcon
from PySide6.QtWidgets import (
    QCheckBox, QFrame, QHBoxLayout, QHeaderView, QLabel, QMessageBox, QPlainTextEdit, QPushButton,
    QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import plataforma, recursos
from katui import sistema as ajustes
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import VERSION, sistema

try:                                     # las apps (Flatpak) las comparte con Kat Store
    from katstore import flatpak
except ImportError:                      # pragma: no cover - sin Kat Store instalado
    flatpak = None


def _icono(nombre):
    ruta = recursos.icono(nombre)
    return QIcon(ruta) if ruta else QIcon.fromTheme("system-software-update")


def _arbol(columnas):
    t = QTreeWidget()
    t.setHeaderLabels(columnas)
    t.setRootIsDecorated(False)
    t.header().setSectionResizeMode(0, QHeaderView.Stretch)
    return t


class VentanaUpdate(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kat Update Center")
        self.setWindowIcon(_icono("kat-update"))
        self.resize(980, 680)
        self.cola = []
        self.proceso = None
        self.errores = []

        caja = QVBoxLayout(self)
        caja.setContentsMargins(24, 20, 24, 16)

        # --- estado ------------------------------------------------------
        tarjeta = rol(QFrame(), "tarjeta")
        t = QHBoxLayout(tarjeta)
        t.setContentsMargins(20, 16, 20, 16)
        icono = QLabel()
        icono.setPixmap(_icono("kat-update").pixmap(72, 72))
        t.addWidget(icono)
        textos = QVBoxLayout()
        self.estado_titulo = rol(QLabel("Comprobando…"), "titulo")
        self.estado_sub = rol(QLabel(""), "subtitulo")
        self.estado_sub.setWordWrap(True)
        textos.addWidget(self.estado_titulo)
        textos.addWidget(self.estado_sub)
        t.addLayout(textos, 1)
        botones = QVBoxLayout()
        self.b_buscar = QPushButton("Buscar actualizaciones")
        self.b_actualizar = rol(QPushButton("Actualizar todo"), "principal")
        self.b_reiniciar = QPushButton("Reiniciar ahora")
        self.b_buscar.clicked.connect(self.buscar)
        self.b_actualizar.clicked.connect(self.actualizar)
        self.b_reiniciar.clicked.connect(self.reiniciar)
        for b in (self.b_buscar, self.b_actualizar, self.b_reiniciar):
            b.setMinimumWidth(190)
            botones.addWidget(b)
        t.addLayout(botones)
        caja.addWidget(tarjeta)

        self.resultado = EtiquetaResultado()
        caja.addWidget(self.resultado)
        if not sistema.disponible():
            aviso = rol(QLabel("ⓘ  Vista previa en %s: aquí no hay actualizaciones de Kat OS que buscar ni aplicar."
                               % plataforma.nombre()), "aviso")
            aviso.setWordWrap(True)
            caja.addWidget(aviso)

        # --- pestañas ------------------------------------------------------
        self.pestanas = QTabWidget()
        self.t_sistema = _arbol(["Paquete", "Versión instalada", "Versión nueva", "Tipo"])
        self.t_apps = _arbol(["App", "Versión nueva"])
        self.t_historial = QTreeWidget()
        self.t_historial.setHeaderLabels(["Fecha", "Cambios"])
        self.t_historial.header().setSectionResizeMode(1, QHeaderView.Stretch)
        self.registro = QPlainTextEdit()
        self.registro.setReadOnly(True)
        self.registro.setFont(QFont("monospace"))
        self.registro.setMaximumBlockCount(5000)
        self.pestanas.addTab(self.t_sistema, "Sistema")
        self.pestanas.addTab(self.t_apps, "Apps")
        self.pestanas.addTab(self.t_historial, "Historial")
        self.pestanas.addTab(self.registro, "Registro en vivo")
        caja.addWidget(self.pestanas, 1)

        self.auto = QCheckBox("Instalar las actualizaciones de seguridad automáticamente (recomendado)")
        self.auto.clicked.connect(self._auto)
        caja.addWidget(self.auto)
        nota = rol(QLabel("Las actualizaciones nunca reemplazan la configuración propia de Kat OS."), "subtitulo")
        caja.addWidget(nota)
        self.recargar()

    # --- leer el estado ---------------------------------------------------------
    def recargar(self):
        self._ocupado(False)
        au = ajustes.actualizaciones_automaticas()
        self.auto.setChecked(bool(au))
        self.auto.setEnabled(au is not None or sistema.disponible())

        def leer():
            apps = flatpak.actualizaciones() if flatpak else None
            return sistema.pendientes(), apps, sistema.reinicio_pendiente(), sistema.historial()
        en_segundo_plano(leer, al_terminar=self._mostrar)

    def _mostrar(self, datos):
        if isinstance(datos, res.Resultado):
            self.resultado.mostrar(datos)
            return
        pendientes, apps, reinicio, historial = datos
        self.t_sistema.clear()
        for p in pendientes or []:
            it = QTreeWidgetItem([p.nombre, p.vieja or "—", p.nueva, "Seguridad" if p.seguridad else ("Kat OS" if p.de_kat else "Mejora")])
            if p.seguridad:
                it.setForeground(3, Qt.GlobalColor.yellow)
            self.t_sistema.addTopLevelItem(it)
        self.t_apps.clear()
        for a in apps or []:
            self.t_apps.addTopLevelItem(QTreeWidgetItem([a["id"], a["version"] or "nueva versión"]))
        self.t_historial.clear()
        for tr in historial or []:
            padre = QTreeWidgetItem([tr.fecha, "%d cambio%s" % (len(tr.cambios), "" if len(tr.cambios) == 1 else "s")])
            for tipo, nombre in tr.cambios[:200]:
                padre.addChild(QTreeWidgetItem(["", "%s: %s" % (tipo, nombre)]))
            self.t_historial.addTopLevelItem(padre)

        n_sis, n_apps = len(pendientes or []), len(apps or [])
        seguridad = sum(1 for p in pendientes or [] if p.seguridad)
        self.b_reiniciar.setVisible(bool(reinicio))
        if pendientes is None and apps is None:
            self.estado_titulo.setText("Vista previa")
            self.estado_sub.setText("Las actualizaciones se gestionan en Kat OS.")
        elif reinicio:
            self.estado_titulo.setText("Reinicia para terminar")
            self.estado_sub.setText("Se actualizó %s. Reinicia cuando puedas para usar lo nuevo." % ", ".join(reinicio[:4]))
        elif n_sis or n_apps:
            self.estado_titulo.setText("Hay actualizaciones")
            partes = []
            if n_sis:
                partes.append("%d del sistema%s" % (n_sis, " (%d de seguridad)" % seguridad if seguridad else ""))
            if n_apps:
                partes.append("%d de apps" % n_apps)
            self.estado_sub.setText(" · ".join(partes))
        else:
            self.estado_titulo.setText("✔ Todo al día")
            self.estado_sub.setText("No hay actualizaciones pendientes.")
        ultima = sistema.ultima_busqueda()
        if ultima and pendientes is not None:
            self.estado_sub.setText(self.estado_sub.text() + "\nÚltima búsqueda: %s" % ultima)
        self.b_actualizar.setEnabled(bool(n_sis or n_apps) and self.proceso is None)

    # --- ejecutar órdenes con el registro en vivo --------------------------------
    def _ocupado(self, si):
        self.b_buscar.setEnabled(not si and sistema.disponible())
        self.b_actualizar.setEnabled(not si and sistema.disponible())
        self.b_reiniciar.setEnabled(not si)

    def _encolar(self, pasos, al_final):
        """pasos: [(descripción, [orden...])]. Se ejecutan uno tras otro."""
        self.cola = list(pasos)
        self.errores = []
        self._al_final = al_final
        self._ocupado(True)
        self.pestanas.setCurrentWidget(self.registro)
        self._siguiente()

    def _siguiente(self):
        if not self.cola:
            self.proceso = None
            r = res.fallo("; ".join(self.errores)) if self.errores else self._al_final
            self.resultado.mostrar(r)
            self.recargar()
            return
        descripcion, orden = self.cola.pop(0)
        self.resultado.trabajando(descripcion + "…")
        self.registro.appendPlainText("\n▶ %s\n$ %s" % (descripcion, " ".join(orden)))
        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)
        p.readyReadStandardOutput.connect(
            lambda: self.registro.appendPlainText(bytes(p.readAllStandardOutput()).decode("utf-8", "replace").rstrip()))

        def fin(codigo, _estado):
            if orden[0] == "pkexec" and codigo in (126, 127):   # cancelaste o no autorizado
                self.errores.append("%s: no se dio la contraseña de administrador" % descripcion)
                self.cola = []                    # sin permiso no tiene sentido seguir
            elif codigo != 0:
                self.errores.append("%s falló (código %d, mira el Registro en vivo)" % (descripcion, codigo))
            self.registro.appendPlainText("■ terminado con código %d" % codigo)
            self._siguiente()

        def error(_e):
            if p.error() == QProcess.FailedToStart:
                self.errores.append("%s: no se pudo iniciar %s" % (descripcion, orden[0]))
                self._siguiente()
        p.finished.connect(fin)
        p.errorOccurred.connect(error)
        self.proceso = p
        p.start(orden[0], orden[1:])

    def buscar(self):
        if not sistema.disponible():
            self.resultado.mostrar(res.no_disponible("Solo se buscan actualizaciones en Kat OS"))
            return
        self._encolar([("Buscando actualizaciones del sistema", sistema.orden_buscar())],
                      res.hecho("Búsqueda terminada"))

    def actualizar(self):
        if not sistema.disponible():
            self.resultado.mostrar(res.no_disponible("Solo se actualiza en Kat OS"))
            return
        pasos = []
        if self.t_sistema.topLevelItemCount():
            pasos.append(("Actualizando el sistema", sistema.orden_actualizar()))
        if self.t_apps.topLevelItemCount() and flatpak and flatpak.disponible():
            pasos.append(("Actualizando las apps", ["flatpak", "update", "--system", "--noninteractive", "-y"]))
        if not pasos:
            self.resultado.mostrar(res.hecho("No hay nada que actualizar"))
            return
        self._encolar(pasos, res.hecho("Actualización terminada"))

    def reiniciar(self):
        if QMessageBox.question(self, "Reiniciar", "¿Reiniciar el equipo ahora?\nGuarda tu trabajo antes.") \
                != QMessageBox.Yes:
            return
        r = res.ejecutar(["systemctl", "reboot"]) if plataforma.ES_LINUX else \
            res.no_disponible("Solo se reinicia desde Kat OS")
        self.resultado.mostrar(r)

    def _auto(self, si):
        self.resultado.trabajando()
        en_segundo_plano(ajustes.cambiar_actualizaciones, si,
                         al_terminar=lambda r: (self.resultado.mostrar(r), self.recargar()))

    def closeEvent(self, evento):
        if self.proceso is not None and self.proceso.state() != QProcess.NotRunning:
            QMessageBox.information(self, "Kat Update Center",
                                    "Hay una actualización en marcha. Espera a que termine antes de cerrar.")
            evento.ignore()
            return
        super().closeEvent(evento)
