"""Punto de entrada de Kat Update Center."""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaUpdate

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Update Center")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaUpdate()
    v.show()
    try:
        from katcore.cliente import KatCoreCliente
        KatCoreCliente().registrar_app(APP_ID, VERSION)
    except Exception:
        pass
    return app.exec()
