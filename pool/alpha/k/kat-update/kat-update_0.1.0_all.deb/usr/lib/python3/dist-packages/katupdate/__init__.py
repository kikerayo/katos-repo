"""Kat Update Center: actualizaciones del sistema (APT) y de las apps (Flatpak).

Las actualizaciones del sistema pasan por kat-ayudante, que usa
--force-confold: nunca reemplazan la configuración propia de Kat OS.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.UpdateCenter"
