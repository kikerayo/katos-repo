"""Actualizaciones del sistema (APT): qué hay pendiente, historial y reinicio.

Leer no necesita permisos. Buscar y aplicar se hacen con
'pkexec /usr/lib/katos/kat-ayudante sistema buscar|actualizar' (lo lanza la ventana).
"""

import os
import re
import subprocess
import time

from katui import plataforma

AYUDANTE = "/usr/lib/katos/kat-ayudante"
HISTORIAL = "/var/log/apt/history.log"
REINICIO = "/var/run/reboot-required"
MARCA_BUSQUEDA = "/var/lib/apt/periodic/update-success-stamp"
LISTAS = "/var/lib/apt/lists"

_LINEA = re.compile(r"^(?P<nombre>[^/\s]+)/(?P<origen>\S+)\s+(?P<nueva>\S+)\s+(?P<arq>\S+)"
                    r"(?:\s+\[upgradable from:\s*(?P<vieja>[^\]]+)\])?")


class Paquete:
    def __init__(self, nombre, nueva, vieja, origen):
        self.nombre, self.nueva, self.vieja, self.origen = nombre, nueva, vieja, origen

    @property
    def seguridad(self):
        return "security" in self.origen

    @property
    def de_kat(self):
        """Apps y piezas de Kat OS (vienen del repositorio de Kat OS)."""
        return self.nombre.startswith("kat-") or self.nombre == "katos-archive-keyring"

    def __repr__(self):
        return "Paquete(%s %s -> %s)" % (self.nombre, self.vieja, self.nueva)


def disponible():
    return plataforma.ES_LINUX and plataforma.tiene("apt") and os.path.exists(AYUDANTE)


def interpretar_pendientes(texto):
    """Salida de 'apt list --upgradable' -> [Paquete]: seguridad primero, luego las de Kat OS."""
    salida = []
    for linea in texto.splitlines():
        m = _LINEA.match(linea.strip())
        if m:
            salida.append(Paquete(m.group("nombre"), m.group("nueva"), (m.group("vieja") or "").strip(),
                                  m.group("origen")))
    salida.sort(key=lambda p: (not p.seguridad, not p.de_kat, p.nombre))      # seguridad, luego Kat
    return salida


def pendientes():
    """[Paquete] o None si aquí no hay APT."""
    if not (plataforma.ES_LINUX and plataforma.tiene("apt")):
        return None
    r = subprocess.run(["apt", "list", "--upgradable"], capture_output=True, text=True, timeout=60,
                       env=dict(os.environ, LANG="C.UTF-8", LC_ALL="C.UTF-8"))
    return interpretar_pendientes(r.stdout) if r.returncode == 0 else []


class Transaccion:
    def __init__(self, fecha, orden, cambios):
        self.fecha = fecha            # "2026-11-16  19:00:00"
        self.orden = orden            # "apt-get -y upgrade --with-new-pkgs"
        self.cambios = cambios        # [("Actualizado", "firefox-esr")...]

    def __repr__(self):
        return "Transaccion(%s, %d cambios)" % (self.fecha, len(self.cambios))


_TIPOS = {"Install": "Instalado", "Upgrade": "Actualizado", "Remove": "Quitado", "Purge": "Borrado",
          "Downgrade": "Versión anterior", "Reinstall": "Reinstalado"}


def interpretar_historial(texto):
    """/var/log/apt/history.log -> [Transaccion], la más reciente primero."""
    trans, actual = [], None
    for linea in texto.splitlines():
        if linea.startswith("Start-Date:"):
            actual = Transaccion(linea.split(":", 1)[1].strip(), "", [])
            trans.append(actual)
        elif actual is None:
            continue
        elif linea.startswith("Commandline:"):
            actual.orden = linea.split(":", 1)[1].strip()
        else:
            clave, _, resto = linea.partition(":")
            if clave in _TIPOS:
                # "pkg:amd64 (1.0, 1.1), otro:all (2.0)" -> nombres
                for nombre in re.findall(r"(?:^|\),\s*)([a-z0-9][a-z0-9+.-]*)(?::[a-z0-9]+)?\s*\(", resto.strip()):
                    actual.cambios.append((_TIPOS[clave], nombre))
    trans.reverse()
    return trans


def historial(n=30):
    if not plataforma.ES_LINUX:
        return None
    try:
        with open(HISTORIAL, encoding="utf-8", errors="replace") as f:
            return interpretar_historial(f.read())[:n]
    except OSError:
        return []


def reinicio_pendiente():
    """Lista de paquetes que piden reiniciar, [] si nada, None si no se sabe."""
    if not plataforma.ES_LINUX:
        return None
    if not os.path.exists(REINICIO):
        return []
    try:
        with open(REINICIO + ".pkgs", encoding="utf-8") as f:
            return sorted(set(f.read().split())) or ["sistema"]
    except OSError:
        return ["sistema"]


def ultima_busqueda():
    """Fecha legible de la última vez que se buscaron actualizaciones, o None."""
    for ruta in (MARCA_BUSQUEDA, LISTAS):
        try:
            return time.strftime("%d/%m/%Y %H:%M", time.localtime(os.path.getmtime(ruta)))
        except OSError:
            continue
    return None


def orden_buscar():
    return ["pkexec", AYUDANTE, "sistema", "buscar"]


def orden_actualizar():
    return ["pkexec", AYUDANTE, "sistema", "actualizar"]
