// Barra con el estilo Kat: título, valor y una barra violeta redondeada.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami

ColumnLayout {
    id: barra
    property string titulo
    property string detalle
    property real fraccion: 0      // 0.0 a 1.0
    spacing: Kirigami.Units.smallSpacing

    readonly property real valor: Math.max(0, Math.min(1, isNaN(fraccion) ? 0 : fraccion))
    // Violeta Kat; cambia a ámbar y rojo cuando se acerca al límite.
    readonly property color colorBarra: valor >= 0.9 ? "#ef4444" : (valor >= 0.75 ? "#f59e0b" : "#8b5cf6")

    RowLayout {
        Layout.fillWidth: true
        PlasmaComponents.Label { text: barra.titulo; Layout.fillWidth: true }
        PlasmaComponents.Label { text: barra.detalle; opacity: 0.8 }
    }

    Rectangle {
        Layout.fillWidth: true
        implicitHeight: Kirigami.Units.smallSpacing * 2
        radius: height / 2
        color: Qt.rgba(1, 1, 1, 0.12)

        Rectangle {
            width: parent.width * barra.valor
            height: parent.height
            radius: parent.radius
            color: barra.colorBarra
            Behavior on width { NumberAnimation { duration: 400; easing.type: Easing.OutCubic } }
        }
    }
}
