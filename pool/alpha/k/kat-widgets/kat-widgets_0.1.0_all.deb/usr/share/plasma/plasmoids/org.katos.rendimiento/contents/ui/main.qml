// Kat Rendimiento: CPU y memoria. Los datos vienen de Kat Core (katd)
// a través de "katctl stats --json", cada 2 segundos.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    readonly property string orden: "katctl stats --json"
    property var datos: null
    property string fallo: ""

    readonly property real cpu: datos ? datos.cpu_percent : 0
    readonly property real memUsada: datos ? datos.mem_used : 0
    readonly property real memTotal: datos ? datos.mem_total : 1

    function gb(bytes) { return (bytes / 1073741824).toFixed(1) + " GB" }

    toolTipMainText: "Kat Rendimiento"
    toolTipSubText: datos ? ("CPU " + Math.round(cpu) + " % · Memoria " + gb(memUsada) + " de " + gb(memTotal))
                          : (fallo || "Cargando…")

    P5Support.DataSource {
        id: ejecutor
        engine: "executable"
        connectedSources: []
        onNewData: function (fuente, salida) {
            disconnectSource(fuente)
            if (salida["exit code"] === 0) {
                try {
                    root.datos = JSON.parse(salida["stdout"])
                    root.fallo = ""
                } catch (e) {
                    root.fallo = "Respuesta no válida de Kat Core"
                }
            } else {
                root.datos = null
                root.fallo = "Kat Core no responde"
            }
        }
    }

    Timer {
        interval: 2000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: ejecutor.connectSource(root.orden)
    }

    // En el panel: solo el porcentaje de CPU.
    compactRepresentation: PlasmaComponents.Label {
        text: root.datos ? "CPU " + Math.round(root.cpu) + " %" : "CPU –"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        MouseArea {
            anchors.fill: parent
            onClicked: root.expanded = !root.expanded
        }
    }

    fullRepresentation: ColumnLayout {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 15
        Layout.minimumWidth: Kirigami.Units.gridUnit * 11
        spacing: Kirigami.Units.smallSpacing * 2

        RowLayout {
            spacing: Kirigami.Units.smallSpacing
            Kirigami.Icon {
                source: "utilities-system-monitor"
                Layout.preferredWidth: Kirigami.Units.iconSizes.small
                Layout.preferredHeight: Kirigami.Units.iconSizes.small
            }
            PlasmaComponents.Label {
                text: "Rendimiento"
                font.bold: true
                Layout.fillWidth: true
            }
        }

        PlasmaComponents.Label {
            visible: root.fallo !== ""
            text: root.fallo
            color: Kirigami.Theme.negativeTextColor
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }

        BarraKat {
            visible: root.fallo === ""
            titulo: "CPU"
            detalle: Math.round(root.cpu) + " %"
            fraccion: root.cpu / 100
            Layout.fillWidth: true
        }

        BarraKat {
            visible: root.fallo === ""
            titulo: "Memoria"
            detalle: root.gb(root.memUsada) + " de " + root.gb(root.memTotal)
            fraccion: root.memUsada / root.memTotal
            Layout.fillWidth: true
        }
    }
}
