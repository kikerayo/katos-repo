// Kat Almacenamiento: espacio del disco del sistema (/).
// Datos de Kat Core (katd) con "katctl stats --json", cada 30 segundos.
import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    readonly property string orden: "katctl stats --json"
    property var datos: null
    property string fallo: ""

    readonly property real usado: datos ? datos.disk_used : 0
    readonly property real total: datos ? datos.disk_total : 1

    function gb(bytes) { return (bytes / 1073741824).toFixed(1) + " GB" }

    toolTipMainText: "Kat Almacenamiento"
    toolTipSubText: datos ? (gb(total - usado) + " libres de " + gb(total)) : (fallo || "Cargando…")

    P5Support.DataSource {
        id: ejecutor
        engine: "executable"
        connectedSources: []
        onNewData: function (fuente, salida) {
            disconnectSource(fuente)
            if (salida["exit code"] === 0) {
                try {
                    root.datos = JSON.parse(salida["stdout"])
                    root.fallo = ""
                } catch (e) {
                    root.fallo = "Respuesta no válida de Kat Core"
                }
            } else {
                root.datos = null
                root.fallo = "Kat Core no responde"
            }
        }
    }

    Timer {
        interval: 30000
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: ejecutor.connectSource(root.orden)
    }

    compactRepresentation: PlasmaComponents.Label {
        text: root.datos ? root.gb(root.total - root.usado) + " libres" : "Disco –"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        MouseArea {
            anchors.fill: parent
            onClicked: root.expanded = !root.expanded
        }
    }

    fullRepresentation: ColumnLayout {
        Layout.preferredWidth: Kirigami.Units.gridUnit * 15
        Layout.minimumWidth: Kirigami.Units.gridUnit * 11
        spacing: Kirigami.Units.smallSpacing * 2

        RowLayout {
            spacing: Kirigami.Units.smallSpacing
            Kirigami.Icon {
                source: "drive-harddisk"
                Layout.preferredWidth: Kirigami.Units.iconSizes.small
                Layout.preferredHeight: Kirigami.Units.iconSizes.small
            }
            PlasmaComponents.Label {
                text: "Almacenamiento"
                font.bold: true
                Layout.fillWidth: true
            }
        }

        PlasmaComponents.Label {
            visible: root.fallo !== ""
            text: root.fallo
            color: Kirigami.Theme.negativeTextColor
            wrapMode: Text.WordWrap
            Layout.fillWidth: true
        }

        BarraKat {
            visible: root.fallo === ""
            titulo: "Disco del sistema"
            detalle: root.gb(root.usado) + " de " + root.gb(root.total)
            fraccion: root.usado / root.total
            Layout.fillWidth: true
        }

        PlasmaComponents.Label {
            visible: root.fallo === "" && root.datos !== null
            text: root.gb(root.total - root.usado) + " libres"
            opacity: 0.8
        }
    }
}
