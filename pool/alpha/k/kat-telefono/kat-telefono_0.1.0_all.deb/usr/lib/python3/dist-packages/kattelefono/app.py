"""Punto de entrada de Kat Phone ID.  Uso: kat-telefono [--servicio | --version]"""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    if "--servicio" in argv:              # lo arranca la sesión de Kat OS (autostart) o la app
        from . import servidor
        return servidor.servicio()
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Phone ID")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    from .ventana import VentanaTelefono
    v = VentanaTelefono()
    v.show()
    return app.exec()
