"""El pequeño servidor web de Kat Phone ID (solo responde a la red de casa).

  GET  /        la web del teléfono (pagina.html)
  POST /reto    da un reto al azar, válido 30 s y de un solo uso
  POST /abrir   {"reto", "firma"}: si la firma es buena y la pantalla está bloqueada, desbloquea
"""

import ipaddress
import json
import os
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import PUERTO, pantalla, vinculo

VIDA_RETO = 30            # segundos
MAX_RETOS = 16
MAX_FALLOS = 5
ESPERA = 300              # segundos de castigo tras MAX_FALLOS firmas malas
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
ARCHIVOS = {                 # lo único que se sirve (nada de rutas libres)
    "/": ("pagina.html", "text/html; charset=utf-8"),
    "/index.html": ("pagina.html", "text/html; charset=utf-8"),
    "/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json; charset=utf-8"),
    "/icono-192.png": ("icono-192.png", "image/png"),
    "/icono-512.png": ("icono-512.png", "image/png"),
    "/apple-touch-icon.png": ("icono-180.png", "image/png"),
}
CABECERAS = {
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Content-Security-Policy": "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                               "connect-src 'self'; img-src 'self' data:; manifest-src 'self'; base-uri 'none'; form-action 'none'",
}


class Guardia:
    """Retos de un solo uso y límite de intentos fallidos."""

    def __init__(self, reloj=time.monotonic):
        self.reloj = reloj
        self.retos = {}
        self.fallos = 0
        self.castigo_hasta = 0.0
        self.cerrojo = threading.Lock()

    def castigado(self):
        return self.reloj() < self.castigo_hasta

    def nuevo_reto(self):
        with self.cerrojo:
            ahora = self.reloj()
            self.retos = {r: t for r, t in self.retos.items() if t > ahora}
            if len(self.retos) >= MAX_RETOS:
                self.retos.pop(min(self.retos, key=self.retos.get))
            reto = secrets.token_hex(16)
            self.retos[reto] = ahora + VIDA_RETO
            return reto

    def usar_reto(self, reto):
        with self.cerrojo:
            expira = self.retos.pop(reto, None) if isinstance(reto, str) else None
            return expira is not None and expira > self.reloj()

    def fallo(self):
        with self.cerrojo:
            self.fallos += 1
            if self.fallos >= MAX_FALLOS:
                self.castigo_hasta = self.reloj() + ESPERA
                self.fallos = 0
                self.retos.clear()

    def acierto(self):
        with self.cerrojo:
            self.fallos = 0


def ip_local():
    """La IP de este equipo en la red de casa (sin enviar nada: UDP no conecta de verdad)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.254.254.254", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def de_casa(ip):
    try:
        d = ipaddress.ip_address(ip)
    except ValueError:
        return False
    if d.version == 6 and d.ipv4_mapped:
        d = d.ipv4_mapped
    return d.is_private or d.is_loopback


class Manejador(BaseHTTPRequestHandler):
    server_version = "KatPhoneID"
    sys_version = ""

    def log_message(self, *args):          # sin registros en la terminal
        pass

    def _responder(self, codigo, cuerpo, tipo="application/json; charset=utf-8"):
        if isinstance(cuerpo, dict):
            cuerpo = json.dumps(cuerpo, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        for k, v in CABECERAS.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(cuerpo)

    def _permitido(self):
        if not de_casa(self.client_address[0]):
            self._responder(403, {"error": "Solo desde la red de casa"})
            return False
        return True

    def do_GET(self):
        if not self._permitido():
            return
        archivo = ARCHIVOS.get(self.path.split("?")[0])
        if not archivo:
            self._responder(404, {"error": "No existe"})
            return
        with open(os.path.join(WEB, archivo[0]), "rb") as f:
            self._responder(200, f.read(), archivo[1])

    def do_POST(self):
        if not self._permitido():
            return
        srv = self.server
        if not vinculo.activado(srv.ruta):
            self._responder(403, {"error": "Phone ID está apagado en el PC"})
            return
        if srv.guardia.castigado():
            self._responder(429, {"error": "Demasiados intentos fallidos: espera unos minutos"})
            return
        if self.path == "/reto":
            self._responder(200, {"reto": srv.guardia.nuevo_reto()})
            return
        if self.path != "/abrir":
            self._responder(404, {"error": "No existe"})
            return
        try:
            largo = int(self.headers.get("Content-Length", "0"))
            datos = json.loads(self.rfile.read(min(largo, 1024)) or b"{}")
            reto, firma = datos.get("reto"), datos.get("firma")
        except (ValueError, AttributeError):
            self._responder(400, {"error": "Petición rara"})
            return
        if not srv.guardia.usar_reto(reto):
            self._responder(400, {"error": "El reto caducó: vuelve a tocar el botón"})
            return
        if not vinculo.comprobar(reto, firma, srv.ruta):
            srv.guardia.fallo()
            srv.evento("Intento con una firma incorrecta desde %s" % self.client_address[0])
            self._responder(401, {"error": "Este teléfono no está vinculado: vuelve a escanear el QR"})
            return
        srv.guardia.acierto()
        estado = srv.bloqueada()
        if estado is None:
            srv.evento("Teléfono comprobado (vista previa: en Kat OS se desbloquearía)")
            self._responder(200, {"ok": True, "mensaje": "Vista previa: tu teléfono está bien vinculado. "
                                                          "En Kat OS ahora se desbloquearía."})
        elif not estado:
            self._responder(200, {"ok": False, "mensaje": "La pantalla no está bloqueada"})
        else:
            r = srv.desbloquear()
            if r.ok:
                srv.evento("Kat OS se desbloqueó con tu teléfono (%s)" % self.client_address[0], avisar=True)
                self._responder(200, {"ok": True, "mensaje": "¡Desbloqueado!"})
            else:
                self._responder(500, {"ok": False, "mensaje": "No se pudo desbloquear: %s" % r.mensaje})


class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, puerto=PUERTO, ruta=None, al_evento=None, bloqueada=pantalla.bloqueada,
                 desbloquear=pantalla.desbloquear, direccion="0.0.0.0"):
        super().__init__((direccion, puerto), Manejador)
        self.ruta, self.al_evento = ruta, al_evento
        self.bloqueada, self.desbloquear = bloqueada, desbloquear
        self.guardia = Guardia()

    def evento(self, texto, avisar=False):
        if avisar:
            pantalla.avisar(texto)
        if self.al_evento:
            try:
                self.al_evento(texto)
            except Exception:
                pass

    def en_hilo(self):
        h = threading.Thread(target=self.serve_forever, name="kat-telefono", daemon=True)
        h.start()
        return h


def enlace(clave_texto, ip=None, puerto=PUERTO):
    """El enlace del QR: la clave va tras '#', así el navegador nunca la envía por la red."""
    return "http://%s:%d/#k=%s" % (ip or ip_local(), puerto, clave_texto)


def servicio(ruta=None):
    """Modo servicio (Kat OS): escucha mientras Phone ID esté activado."""
    if not vinculo.activado(ruta):
        return 0
    try:
        srv = Servidor(ruta=ruta)
    except OSError:
        return 0                          # ya hay otro servicio escuchando
    srv.en_hilo()
    try:
        while vinculo.activado(ruta):
            time.sleep(10)
    finally:
        srv.shutdown()
        srv.server_close()
    return 0
