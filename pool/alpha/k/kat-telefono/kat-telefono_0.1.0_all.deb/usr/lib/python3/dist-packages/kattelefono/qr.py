"""Códigos QR hechos por Kat (sin librerías externas).

Modo byte, corrección de errores nivel M, versiones 1 a 10 (hasta 213 bytes),
con la máscara que menos penaliza según la norma ISO/IEC 18004.
Uso:  matriz = qr.crear("http://...")   -> lista de filas de True (negro) / False
"""

# corrección M por versión: (códigos de corrección por bloque, [(bloques, datos por bloque), ...])
BLOQUES_M = {
    1: (10, [(1, 16)]), 2: (16, [(1, 28)]), 3: (26, [(1, 44)]), 4: (18, [(2, 32)]),
    5: (24, [(2, 43)]), 6: (16, [(4, 27)]), 7: (18, [(4, 31)]), 8: (22, [(2, 38), (2, 39)]),
    9: (22, [(3, 36), (2, 37)]), 10: (26, [(4, 43), (1, 44)]),
}
ALINEACION = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
              7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}
NIVEL_M = 0          # bits de formato del nivel M


class Demasiado(ValueError):
    pass


# --- Reed-Solomon en GF(256) -------------------------------------------------
def _mul(a, b):
    r = 0
    for i in range(7, -1, -1):
        r = (r << 1) ^ ((r >> 7) * 0x11D)
        r ^= ((b >> i) & 1) * a
    return r


def _divisor(grado):
    res = [0] * (grado - 1) + [1]
    raiz = 1
    for _ in range(grado):
        for j in range(len(res)):
            res[j] = _mul(res[j], raiz)
            if j + 1 < len(res):
                res[j] ^= res[j + 1]
        raiz = _mul(raiz, 0x02)
    return res


def _resto(datos, divisor):
    res = [0] * len(divisor)
    for b in datos:
        factor = b ^ res.pop(0)
        res.append(0)
        for i, coef in enumerate(divisor):
            res[i] ^= _mul(coef, factor)
    return res


# --- datos ----------------------------------------------------------------------
def _capacidad(version):
    return sum(n * d for n, d in BLOQUES_M[version][1])


def _version_para(n_bytes):
    for v in range(1, 11):
        bits_cuenta = 8 if v < 10 else 16
        if 4 + bits_cuenta + 8 * n_bytes <= 8 * _capacidad(v):
            return v
    raise Demasiado("el texto es demasiado largo para un QR de Kat (%d bytes)" % n_bytes)


def _codigos(datos, version):
    bits = []

    def poner(valor, largo):
        bits.extend((valor >> i) & 1 for i in range(largo - 1, -1, -1))
    poner(0b0100, 4)
    poner(len(datos), 8 if version < 10 else 16)
    for b in datos:
        poner(b, 8)
    total = 8 * _capacidad(version)
    poner(0, min(4, total - len(bits)))
    poner(0, (-len(bits)) % 8)
    palabras = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    relleno = 0
    while len(palabras) < _capacidad(version):
        palabras.append((0xEC, 0x11)[relleno % 2])
        relleno += 1
    # repartir en bloques, calcular la corrección y entrelazar
    ec, grupos = BLOQUES_M[version]
    divisor = _divisor(ec)
    bloques, pos = [], 0
    for n, d in grupos:
        for _ in range(n):
            bloque = palabras[pos:pos + d]
            pos += d
            bloques.append((bloque, _resto(bloque, divisor)))
    salida = []
    for i in range(max(len(b) for b, _ in bloques)):
        salida.extend(b[i] for b, _ in bloques if i < len(b))
    for i in range(ec):
        salida.extend(c[i] for _, c in bloques)
    return salida


# --- dibujar la matriz -------------------------------------------------------------
class _Matriz:
    def __init__(self, version):
        self.v = version
        self.n = 17 + 4 * version
        self.m = [[False] * self.n for _ in range(self.n)]
        self.fija = [[False] * self.n for _ in range(self.n)]

    def poner(self, x, y, negro):
        self.m[y][x] = bool(negro)
        self.fija[y][x] = True

    def patrones(self):
        n = self.n
        for i in range(n):
            self.poner(6, i, i % 2 == 0)
            self.poner(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        self.poner(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = ALINEACION[self.v]
        ult = len(pos) - 1
        for i, a in enumerate(pos):
            for j, b in enumerate(pos):
                if (i, j) in ((0, 0), (0, ult), (ult, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.poner(a + dx, b + dy, max(abs(dx), abs(dy)) != 1)
        self.formato(0)                  # reservar su sitio (se reescribe después)
        if self.v >= 7:
            resto = self.v
            for _ in range(12):
                resto = (resto << 1) ^ ((resto >> 11) * 0x1F25)
            bits = self.v << 12 | resto
            for i in range(18):
                bit = (bits >> i) & 1
                a, b = n - 11 + i % 3, i // 3
                self.poner(a, b, bit)
                self.poner(b, a, bit)

    def formato(self, mascara):
        n = self.n
        datos = NIVEL_M << 3 | mascara
        resto = datos
        for _ in range(10):
            resto = (resto << 1) ^ ((resto >> 9) * 0x537)
        bits = (datos << 10 | resto) ^ 0x5412

        def bit(i):
            return (bits >> i) & 1
        for i in range(6):
            self.poner(8, i, bit(i))
        self.poner(8, 7, bit(6))
        self.poner(8, 8, bit(7))
        self.poner(7, 8, bit(8))
        for i in range(9, 15):
            self.poner(14 - i, 8, bit(i))
        for i in range(8):
            self.poner(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.poner(8, n - 15 + i, bit(i))
        self.poner(8, n - 8, True)

    def colocar(self, palabras):
        n, i, total = self.n, 0, len(palabras) * 8
        derecha = n - 1
        while derecha >= 1:
            if derecha == 6:
                derecha = 5
            for vert in range(n):
                for j in range(2):
                    x = derecha - j
                    sube = ((derecha + 1) & 2) == 0
                    y = n - 1 - vert if sube else vert
                    if not self.fija[y][x] and i < total:
                        self.m[y][x] = bool((palabras[i >> 3] >> (7 - (i & 7))) & 1)
                        i += 1
            derecha -= 2

    def enmascarar(self, mascara):
        f = MASCARAS[mascara]
        for y in range(self.n):
            for x in range(self.n):
                if not self.fija[y][x] and f(x, y):
                    self.m[y][x] = not self.m[y][x]


MASCARAS = [
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
]


def _penalizacion(m):
    n, p = len(m), 0
    lineas = m + [[m[y][x] for y in range(n)] for x in range(n)]
    patron, patron_inv = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1]
    for fila in lineas:
        largo = 1
        for k in range(1, n + 1):
            if k < n and fila[k] == fila[k - 1]:
                largo += 1
            else:
                if largo >= 5:
                    p += 3 + largo - 5
                largo = 1
        bits = [int(b) for b in fila]
        for k in range(n - 10):
            if bits[k:k + 11] in (patron, patron_inv):
                p += 40
    for y in range(n - 1):
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                p += 3
    negros = sum(map(sum, m))
    p += 10 * (abs(negros * 100 // (n * n) - 50) // 5)
    return p


def crear(texto):
    """Matriz del QR (sin margen): lista de filas con True = cuadro negro."""
    datos = texto.encode("utf-8") if isinstance(texto, str) else bytes(texto)
    version = _version_para(len(datos))
    palabras = _codigos(datos, version)
    mejor = None
    for mascara in range(8):
        q = _Matriz(version)
        q.patrones()
        q.colocar(palabras)
        q.enmascarar(mascara)
        q.formato(mascara)
        puntos = _penalizacion(q.m)
        if mejor is None or puntos < mejor[0]:
            mejor = (puntos, q.m)
    return mejor[1]


def imagen(texto, tam_cuadro=8, margen=4):
    """QImage en blanco y negro del QR (necesita PySide6)."""
    from PySide6.QtGui import QColor, QImage, QPainter
    m = crear(texto)
    lado = (len(m) + 2 * margen) * tam_cuadro
    img = QImage(lado, lado, QImage.Format_RGB32)
    img.fill(QColor("white"))
    p = QPainter(img)
    for y, fila in enumerate(m):
        for x, negro in enumerate(fila):
            if negro:
                p.fillRect((x + margen) * tam_cuadro, (y + margen) * tam_cuadro, tam_cuadro, tam_cuadro,
                           QColor("black"))
    p.end()
    return img
