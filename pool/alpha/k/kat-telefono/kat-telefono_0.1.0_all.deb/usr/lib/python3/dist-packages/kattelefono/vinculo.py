"""El vínculo con tu teléfono: una clave secreta al azar, guardada solo para tu usuario.

Archivo: ~/.config/katos/katlock/telefono.json (permisos 0600).
"""

import base64
import hashlib
import hmac
import json
import os
import secrets
import time

from katui import plataforma

PREFIJO = "kat-abrir:"          # lo que firma el teléfono: PREFIJO + reto


def archivo(carpeta=None):
    return os.path.join(carpeta or plataforma.carpeta_config("katlock"), "telefono.json")


def _escribir(datos, ruta):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    temporal = ruta + ".tmp"
    with open(temporal, "w", encoding="utf-8") as f:
        json.dump(datos, f)
    try:
        os.chmod(temporal, 0o600)
    except OSError:
        pass
    os.replace(temporal, ruta)


def leer(ruta=None):
    try:
        with open(ruta or archivo(), encoding="utf-8") as f:
            d = json.load(f)
        clave = base64.urlsafe_b64decode(d["clave"] + "==")
        return d if len(clave) == 32 else None
    except (OSError, ValueError, KeyError, TypeError):
        return None


def crear(ruta=None):
    """Nueva clave (borra cualquier teléfono vinculado antes). Devuelve la clave en texto para el QR."""
    texto = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")
    _escribir({"version": 1, "clave": texto, "creado": int(time.time()), "activado": True}, ruta or archivo())
    return texto


def activar(si, ruta=None):
    d = leer(ruta)
    if d:
        d["activado"] = bool(si)
        _escribir(d, ruta or archivo())


def activado(ruta=None):
    d = leer(ruta)
    return bool(d and d.get("activado"))


def quitar(ruta=None):
    try:
        os.remove(ruta or archivo())
    except FileNotFoundError:
        pass


def firmar(clave_texto, reto):
    clave = base64.urlsafe_b64decode(clave_texto + "==")
    return hmac.new(clave, (PREFIJO + reto).encode(), hashlib.sha256).hexdigest()


def comprobar(reto, firma, ruta=None):
    d = leer(ruta)
    if not d or not d.get("activado") or not isinstance(firma, str):
        return False
    return hmac.compare_digest(firmar(d["clave"], reto), firma.lower())
