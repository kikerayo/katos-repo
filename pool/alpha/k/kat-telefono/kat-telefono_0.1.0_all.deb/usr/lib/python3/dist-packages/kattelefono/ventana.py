"""Ventana de Kat Phone ID: vincular el teléfono con un QR, activar/apagar y ver lo que pasa."""

import shutil
import socket
import time

from PySide6.QtCore import QObject, QProcess, Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QCheckBox, QFrame, QHBoxLayout, QLabel, QListWidget, QMessageBox, QPushButton,
                               QVBoxLayout, QWidget)

from katui import plataforma
from katui.estilo import rol

from . import PUERTO, VERSION, qr, servidor, vinculo

AVISO = ("Úsalo solo en la red Wi-Fi de tu casa. Quien tenga tu teléfono (desbloqueado) podría abrir tu PC "
         "mientras estés en la misma red. Tu contraseña y tu PIN siguen funcionando siempre.")


class _Puente(QObject):
    evento = Signal(str)            # del hilo del servidor a la ventana


def servicio_escuchando(puerto=PUERTO):
    s = socket.socket()
    s.settimeout(0.5)
    try:
        return s.connect_ex(("127.0.0.1", puerto)) == 0
    finally:
        s.close()


class VentanaTelefono(QWidget):
    def __init__(self, ruta=None, servidor_propio=None):
        super().__init__()
        self.setWindowTitle("Kat Phone ID")
        self.resize(560, 720)
        self.ruta = ruta
        # En Windows (vista previa) el servidor vive dentro de la ventana; en Kat OS es un servicio aparte.
        self.servidor_propio = (not plataforma.ES_LINUX) if servidor_propio is None else servidor_propio
        self.srv = None
        self.puente = _Puente()
        self.puente.evento.connect(self._anotar)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 22, 28, 22)
        lay.setSpacing(10)
        lay.addWidget(rol(QLabel("Kat Phone ID"), "titulo"))
        sub = rol(QLabel("Desbloquea tu PC tocando un botón en la web de tu teléfono. Solo en tu red de casa y "
                         "solo cuando la pantalla está bloqueada."), "subtitulo")
        sub.setWordWrap(True)
        lay.addWidget(sub)
        aviso = rol(QLabel("⚠  " + AVISO), "aviso")
        aviso.setWordWrap(True)
        lay.addWidget(aviso)

        self.estado = QLabel("")
        self.estado.setWordWrap(True)
        lay.addWidget(self.estado)

        self.caja_qr = rol(QFrame(), "tarjeta")
        cq = QVBoxLayout(self.caja_qr)
        self.qr = QLabel()
        self.qr.setAlignment(Qt.AlignCenter)
        cq.addWidget(self.qr)
        self.qr_texto = QLabel("Escanéalo con la cámara de tu teléfono (conectado al mismo Wi-Fi) y abre el "
                               "enlace. Este código lleva tu clave: no lo compartas.")
        self.qr_texto.setWordWrap(True)
        self.qr_texto.setAlignment(Qt.AlignCenter)
        cq.addWidget(self.qr_texto)
        self.b_listo = rol(QPushButton("Listo, ya lo escaneé"), "principal")
        self.b_listo.clicked.connect(self._ocultar_qr)
        cq.addWidget(self.b_listo, 0, Qt.AlignHCenter)
        self.caja_qr.hide()
        lay.addWidget(self.caja_qr)

        self.activo = QCheckBox("Phone ID activado")
        self.activo.clicked.connect(self._activar)
        lay.addWidget(self.activo)
        fila = QHBoxLayout()
        self.b_vincular = rol(QPushButton("Vincular mi teléfono"), "principal")
        self.b_vincular.clicked.connect(self._vincular)
        self.b_quitar = QPushButton("Desvincular")
        self.b_quitar.clicked.connect(self._desvincular)
        fila.addWidget(self.b_vincular)
        fila.addWidget(self.b_quitar)
        fila.addStretch(1)
        lay.addLayout(fila)

        lay.addWidget(rol(QLabel("Lo que ha pasado"), "subtitulo"))
        self.eventos = QListWidget()
        self.eventos.setMinimumHeight(90)
        lay.addWidget(self.eventos, 1)
        pie = rol(QLabel("Kat Phone ID %s · puerto %d" % (VERSION, PUERTO)), "subtitulo")
        pie.setAlignment(Qt.AlignCenter)
        lay.addWidget(pie)
        self._actualizar()
        self._encender()

    # --- servidor -----------------------------------------------------------------
    def _encender(self):
        if not vinculo.activado(self.ruta):
            self._apagar_propio()
            return
        if self.servidor_propio:
            if self.srv is None:
                try:
                    self.srv = servidor.Servidor(ruta=self.ruta, al_evento=self.puente.evento.emit)
                    self.srv.en_hilo()
                    self._anotar("Escuchando en %s:%d (vista previa: no desbloquea Windows)"
                                 % (servidor.ip_local(), PUERTO))
                except OSError as e:
                    self._anotar("No pude abrir el puerto %d: %s" % (PUERTO, e))
        elif not servicio_escuchando() and shutil.which("kat-telefono"):
            QProcess.startDetached("kat-telefono", ["--servicio"])
            self._anotar("Servicio de Phone ID encendido")

    def _apagar_propio(self):
        if self.srv is not None:
            self.srv.shutdown()
            self.srv.server_close()
            self.srv = None

    # --- acciones --------------------------------------------------------------------
    def _vincular(self):
        if vinculo.leer(self.ruta) and QMessageBox.question(
                self, "Vincular otro teléfono",
                "Ya hay un teléfono vinculado. Si vinculas otro, el anterior dejará de funcionar. ¿Seguir?"
        ) != QMessageBox.Yes:
            return
        clave = vinculo.crear(self.ruta)
        enlace = servidor.enlace(clave)
        self.qr.setPixmap(QPixmap.fromImage(qr.imagen(enlace, tam_cuadro=6)))
        self.caja_qr.show()
        self._anotar("Nuevo vínculo creado (el teléfono anterior, si había, ya no sirve)")
        self._actualizar()
        self._encender()

    def _ocultar_qr(self):
        self.qr.clear()
        self.caja_qr.hide()

    def _activar(self, si):
        vinculo.activar(si, self.ruta)
        self._anotar("Phone ID activado" if si else "Phone ID apagado: el teléfono no puede desbloquear")
        self._actualizar()
        self._encender()

    def _desvincular(self):
        if QMessageBox.question(self, "Desvincular", "¿Desvincular tu teléfono? Ya no podrá desbloquear este PC."
                                ) != QMessageBox.Yes:
            return
        vinculo.quitar(self.ruta)
        self._ocultar_qr()
        self._apagar_propio()
        self._anotar("Teléfono desvinculado")
        self._actualizar()

    # --- vista ------------------------------------------------------------------------
    def _actualizar(self):
        hay = vinculo.leer(self.ruta) is not None
        act = vinculo.activado(self.ruta)
        if not hay:
            self.estado.setText("Ningún teléfono vinculado.")
        elif act:
            self.estado.setText("✔ Teléfono vinculado y Phone ID activado.")
        else:
            self.estado.setText("Teléfono vinculado, pero Phone ID está apagado.")
        self.activo.setVisible(hay)
        self.activo.setChecked(act)
        self.b_quitar.setEnabled(hay)
        self.b_vincular.setText("Vincular otro teléfono" if hay else "Vincular mi teléfono")

    def _anotar(self, texto):
        self.eventos.insertItem(0, "%s  %s" % (time.strftime("%H:%M"), texto))

    def closeEvent(self, evento):
        self._apagar_propio()
        super().closeEvent(evento)
