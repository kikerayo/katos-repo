"""Kat Phone ID: desbloquear Kat OS con un botón en la web de tu teléfono. OPCIONAL.

Vincular: Kat muestra un QR; el teléfono abre la web de Kat y guarda una clave
secreta (va en la parte '#' del enlace, que el navegador nunca envía por la red).
Desbloquear: el PC da un reto de un solo uso, el teléfono lo firma con la clave
(HMAC-SHA256) y, si la firma es buena y la pantalla está bloqueada, se desbloquea.
Solo en la red de casa, solo con la pantalla bloqueada, con límite de intentos.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Telefono"
PUERTO = 47800
