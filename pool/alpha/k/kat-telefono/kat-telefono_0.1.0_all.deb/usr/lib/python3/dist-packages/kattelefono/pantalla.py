"""Saber si la pantalla está bloqueada y desbloquearla (logind, como `loginctl unlock-session`)."""

import os
import shutil
import subprocess

from katui import acciones as res
from katui import plataforma


def _sesion():
    return os.environ.get("XDG_SESSION_ID") or "auto"


def bloqueada():
    """True / False, o None si no se puede saber (fuera de Kat OS)."""
    if not plataforma.ES_LINUX or not shutil.which("loginctl"):
        return None
    try:
        r = subprocess.run(["loginctl", "show-session", _sesion(), "-p", "LockedHint", "--value"],
                           capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if r.returncode != 0:
        return None
    return r.stdout.strip() == "yes"


def desbloquear():
    if not plataforma.ES_LINUX or not shutil.which("loginctl"):
        return res.no_disponible("Desbloquear solo funciona en Kat OS")
    return res.ejecutar(["loginctl", "unlock-session", _sesion()], exito="Pantalla desbloqueada")


def avisar(texto):
    """Notificación en el escritorio + sonido de Kat (si se puede)."""
    if shutil.which("notify-send"):
        try:
            subprocess.Popen(["notify-send", "-a", "Kat Phone ID", "-i", "kat-telefono", "Kat Phone ID", texto])
        except OSError:
            pass
    try:
        from katui import sonido
        sonido.reproducir("kat-aceptar")
    except Exception:
        pass
