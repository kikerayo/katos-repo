"""Cliente de Kat Core para las apps Kat (y para katctl).

Uso desde una app:
    from katcore.cliente import KatCoreCliente
    kc = KatCoreCliente()
    kc.registrar_app("org.katos.Settings", "0.1.0")
    kc.evento("org.katos.Settings", "info", "Se cambió el fondo")
"""

from gi.repository import Gio, GLib

from . import BUS_NAME, INTERFACE, OBJECT_PATH

TIEMPO_ESPERA_MS = 5000


class KatCoreCliente:
    def __init__(self, conexion=None):
        self.con = conexion or Gio.bus_get_sync(Gio.BusType.SESSION, None)

    def _llamar(self, metodo, firma=None, valores=None):
        params = GLib.Variant(firma, valores) if firma else None
        res = self.con.call_sync(BUS_NAME, OBJECT_PATH, INTERFACE, metodo, params,
                                 None, Gio.DBusCallFlags.NONE, TIEMPO_ESPERA_MS, None)
        return res.unpack() if res is not None else ()

    def version(self):
        return self._llamar("Version")[0]

    def evento(self, app, nivel, mensaje):
        return self._llamar("LogEvent", "(sss)", (app, nivel, mensaje))[0]

    def eventos(self, limite=50, app=""):
        return self._llamar("RecentEvents", "(us)", (limite, app))[0]

    def registrar_app(self, app_id, version):
        self._llamar("RegisterApp", "(ss)", (app_id, version))

    def apps(self):
        return self._llamar("Apps")[0]

    def estadisticas(self):
        return self._llamar("SystemStats")[0]

    def info(self):
        return self._llamar("SystemInfo")[0]
