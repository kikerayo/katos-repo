"""Almacén de eventos y apps de katd, guardado en SQLite.

Archivo: $XDG_STATE_HOME/katos/katd.db (normalmente ~/.local/state/katos/katd.db).
"""

import os
import sqlite3
import time

NIVELES = ("info", "warning", "error")
MAX_EVENTOS = 10000          # se borran los más antiguos al pasar de aquí
MAX_TEXTO = 4000             # recorta mensajes enormes
_ID_VALIDO = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_")


class ErrorDeDatos(ValueError):
    """Datos inválidos enviados por una app (nivel desconocido, id vacío...)."""


def ruta_por_defecto():
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(os.path.expanduser("~"), ".local", "state")
    return os.path.join(base, "katos", "katd.db")


def validar_app_id(app_id):
    if not app_id or len(app_id) > 128 or not set(app_id) <= _ID_VALIDO:
        raise ErrorDeDatos("app_id inválido: usa letras, números, '.', '-' o '_' (máx. 128)")
    return app_id


class Registro:
    def __init__(self, ruta=None):
        self.ruta = ruta or ruta_por_defecto()
        if self.ruta != ":memory:":
            os.makedirs(os.path.dirname(self.ruta), exist_ok=True)
        self.db = sqlite3.connect(self.ruta)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS eventos (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                momento REAL    NOT NULL,
                app     TEXT    NOT NULL,
                nivel   TEXT    NOT NULL,
                mensaje TEXT    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS eventos_app ON eventos(app);
            CREATE TABLE IF NOT EXISTS apps (
                app_id      TEXT PRIMARY KEY,
                version     TEXT NOT NULL,
                visto_ultimo REAL NOT NULL
            );
            """
        )
        self.db.commit()

    # --- eventos --------------------------------------------------
    def agregar_evento(self, app, nivel, mensaje, momento=None):
        validar_app_id(app)
        if nivel not in NIVELES:
            raise ErrorDeDatos("nivel inválido %r; usa uno de: %s" % (nivel, ", ".join(NIVELES)))
        mensaje = (mensaje or "")[:MAX_TEXTO]
        momento = time.time() if momento is None else momento
        cur = self.db.execute(
            "INSERT INTO eventos (momento, app, nivel, mensaje) VALUES (?, ?, ?, ?)",
            (momento, app, nivel, mensaje),
        )
        nuevo_id = cur.lastrowid
        self.db.execute("DELETE FROM eventos WHERE id <= ?", (nuevo_id - MAX_EVENTOS,))
        self.db.commit()
        return nuevo_id, momento

    def eventos_recientes(self, limite=50, app=""):
        limite = max(1, min(int(limite), 1000))
        if app:
            filas = self.db.execute(
                "SELECT id, momento, app, nivel, mensaje FROM eventos WHERE app = ? "
                "ORDER BY id DESC LIMIT ?", (app, limite))
        else:
            filas = self.db.execute(
                "SELECT id, momento, app, nivel, mensaje FROM eventos ORDER BY id DESC LIMIT ?",
                (limite,))
        return [tuple(f) for f in filas]

    # --- apps -----------------------------------------------------
    def registrar_app(self, app_id, version):
        validar_app_id(app_id)
        version = (version or "")[:64] or "desconocida"
        self.db.execute(
            "INSERT INTO apps (app_id, version, visto_ultimo) VALUES (?, ?, ?) "
            "ON CONFLICT(app_id) DO UPDATE SET version = excluded.version, "
            "visto_ultimo = excluded.visto_ultimo",
            (app_id, version, time.time()),
        )
        self.db.commit()

    def apps(self):
        filas = self.db.execute("SELECT app_id, version, visto_ultimo FROM apps ORDER BY app_id")
        return [tuple(f) for f in filas]

    def cerrar(self):
        self.db.close()
