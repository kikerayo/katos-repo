"""Lectura de datos reales del sistema desde /proc y os.statvfs.

No usa programas externos: así funciona igual en la ISO, en el sistema
instalado y en las pruebas.
"""

import os
import platform


def _leer(ruta):
    with open(ruta, encoding="utf-8", errors="replace") as f:
        return f.read()


def tiempos_cpu(stat_texto=None):
    """Devuelve (ocupado, total) en ticks desde la línea 'cpu' de /proc/stat."""
    texto = stat_texto if stat_texto is not None else _leer("/proc/stat")
    for linea in texto.splitlines():
        if linea.startswith("cpu "):
            valores = [int(v) for v in linea.split()[1:]]
            inactivo = valores[3] + (valores[4] if len(valores) > 4 else 0)  # idle + iowait
            total = sum(valores[:8])  # sin guest/guest_nice (ya van dentro de user)
            return total - inactivo, total
    raise RuntimeError("/proc/stat no tiene línea 'cpu'")


def porcentaje_cpu(antes, despues):
    ocupado = despues[0] - antes[0]
    total = despues[1] - antes[1]
    if total <= 0:
        return 0.0
    return round(max(0.0, min(100.0, 100.0 * ocupado / total)), 1)


def memoria(meminfo_texto=None):
    """Devuelve (total_bytes, usada_bytes) como la calcula 'free' (total - disponible)."""
    texto = meminfo_texto if meminfo_texto is not None else _leer("/proc/meminfo")
    datos = {}
    for linea in texto.splitlines():
        clave, _, resto = linea.partition(":")
        partes = resto.split()
        if partes:
            datos[clave] = int(partes[0]) * 1024
    total = datos["MemTotal"]
    disponible = datos.get("MemAvailable", datos.get("MemFree", 0))
    return total, total - disponible


def disco(ruta="/"):
    """Devuelve (total_bytes, usado_bytes) del sistema de archivos de 'ruta'."""
    st = os.statvfs(ruta)
    total = st.f_blocks * st.f_frsize
    libre = st.f_bavail * st.f_frsize
    return total, total - libre


def tiempo_encendido(uptime_texto=None):
    texto = uptime_texto if uptime_texto is not None else _leer("/proc/uptime")
    return float(texto.split()[0])


def modelo_cpu(cpuinfo_texto=None):
    try:
        texto = cpuinfo_texto if cpuinfo_texto is not None else _leer("/proc/cpuinfo")
    except OSError:
        return "desconocido"
    for linea in texto.splitlines():
        if linea.startswith("model name"):
            return linea.split(":", 1)[1].strip()
    return platform.machine() or "desconocido"


def os_release(ruta="/etc/os-release"):
    datos = {}
    try:
        texto = _leer(ruta)
    except OSError:
        return datos
    for linea in texto.splitlines():
        clave, igual, valor = linea.partition("=")
        if igual and clave and not clave.startswith("#"):
            datos[clave.strip()] = valor.strip().strip('"')
    return datos


def info_sistema():
    rel = os_release()
    return {
        "nombre": rel.get("NAME", "Kat OS Desktop"),
        "version": rel.get("VERSION_ID", "desconocida"),
        "nombre_completo": rel.get("PRETTY_NAME", "Kat OS Desktop"),
        "kernel": platform.release(),
        "equipo": platform.node(),
        "cpu": modelo_cpu(),
        "nucleos": str(os.cpu_count() or 1),
    }
