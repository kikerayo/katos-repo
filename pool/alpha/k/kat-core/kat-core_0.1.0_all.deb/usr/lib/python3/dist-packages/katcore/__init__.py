"""Kat Core: el servicio central de Kat OS (katd).

Las apps Kat hablan con katd por D-Bus (bus de sesión) para:
  - registrar eventos (un registro común para todas las apps),
  - registrarse como app instalada (las ve Kat Developer Center),
  - leer datos del sistema (CPU, memoria, disco, versión).
"""

VERSION = "0.1.0"

BUS_NAME = "org.katos.Core"
OBJECT_PATH = "/org/katos/Core"
INTERFACE = "org.katos.Core1"
