"""katctl: herramienta de terminal para hablar con Kat Core.

Ejemplos:
    katctl version
    katctl info
    katctl stats            (o: katctl stats --json)
    katctl log org.katos.Prueba info "Hola desde la terminal"
    katctl eventos 20
    katctl apps
"""

import argparse
import json
import sys
import time

from gi.repository import GLib

from .cliente import KatCoreCliente


def _gb(n):
    return "%.1f GB" % (n / 1024 ** 3)


def main(argv=None):
    p = argparse.ArgumentParser(prog="katctl", description="Habla con Kat Core (katd).")
    sub = p.add_subparsers(dest="orden", required=True)
    sub.add_parser("version", help="versión de katd")
    sub.add_parser("info", help="datos del sistema")
    st = sub.add_parser("stats", help="CPU, memoria y disco")
    st.add_argument("--json", action="store_true", help="salida en JSON (para widgets)")
    lg = sub.add_parser("log", help="registrar un evento")
    lg.add_argument("app")
    lg.add_argument("nivel", choices=["info", "warning", "error"])
    lg.add_argument("mensaje")
    ev = sub.add_parser("eventos", help="últimos eventos")
    ev.add_argument("limite", nargs="?", type=int, default=20)
    ev.add_argument("--app", default="")
    sub.add_parser("apps", help="apps Kat registradas")
    a = p.parse_args(argv)

    try:
        kc = KatCoreCliente()
        if a.orden == "version":
            print(kc.version())
        elif a.orden == "info":
            for k, v in sorted(kc.info().items()):
                print("%-16s %s" % (k, v))
        elif a.orden == "stats":
            s = kc.estadisticas()
            if a.json:
                print(json.dumps(s))
            else:
                print("CPU       %.1f %%" % s["cpu_percent"])
                print("Memoria   %s de %s" % (_gb(s["mem_used"]), _gb(s["mem_total"])))
                print("Disco /   %s de %s" % (_gb(s["disk_used"]), _gb(s["disk_total"])))
                print("Encendido %d min" % (s["uptime"] // 60))
        elif a.orden == "log":
            print(kc.evento(a.app, a.nivel, a.mensaje))
        elif a.orden == "eventos":
            for i, t, app, nivel, msg in kc.eventos(a.limite, a.app):
                print("%d  %s  %-7s %s: %s" % (i, time.strftime("%F %T", time.localtime(t)), nivel, app, msg))
        elif a.orden == "apps":
            for app_id, ver, visto in kc.apps():
                print("%-32s %-10s %s" % (app_id, ver, time.strftime("%F %T", time.localtime(visto))))
    except GLib.Error as e:
        print("katctl: " + e.message, file=sys.stderr)
        return 1
    return 0
