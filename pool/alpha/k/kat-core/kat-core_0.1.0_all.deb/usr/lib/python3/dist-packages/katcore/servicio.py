"""katd: publica Kat Core en el bus de sesión de D-Bus.

Nombre:    org.katos.Core
Objeto:    /org/katos/Core
Interfaz:  org.katos.Core1  (ver INTROSPECCION más abajo)
"""

import signal
import sys
import time

from gi.repository import Gio, GLib

from . import BUS_NAME, INTERFACE, OBJECT_PATH, VERSION, sistema
from .registro import ErrorDeDatos, Registro

INTROSPECCION = """
<node>
  <interface name="org.katos.Core1">
    <method name="Version">
      <arg type="s" name="version" direction="out"/>
    </method>
    <method name="LogEvent">
      <arg type="s" name="app" direction="in"/>
      <arg type="s" name="level" direction="in"/>
      <arg type="s" name="message" direction="in"/>
      <arg type="t" name="id" direction="out"/>
    </method>
    <method name="RecentEvents">
      <arg type="u" name="limit" direction="in"/>
      <arg type="s" name="app" direction="in"/>
      <arg type="a(tdsss)" name="events" direction="out"/>
    </method>
    <method name="RegisterApp">
      <arg type="s" name="app_id" direction="in"/>
      <arg type="s" name="version" direction="in"/>
    </method>
    <method name="Apps">
      <arg type="a(ssd)" name="apps" direction="out"/>
    </method>
    <method name="SystemStats">
      <arg type="a{sv}" name="stats" direction="out"/>
    </method>
    <method name="SystemInfo">
      <arg type="a{ss}" name="info" direction="out"/>
    </method>
    <signal name="EventLogged">
      <arg type="t" name="id"/>
      <arg type="d" name="time"/>
      <arg type="s" name="app"/>
      <arg type="s" name="level"/>
      <arg type="s" name="message"/>
    </signal>
  </interface>
</node>
"""

ERROR_DATOS = "org.katos.Core.Error.InvalidArgs"
ERROR_INTERNO = "org.katos.Core.Error.Failed"
MUESTREO_MIN_S = 0.5   # no recalcular la CPU más seguido que esto


class KatCore:
    def __init__(self, registro):
        self.registro = registro
        self.conexion = None
        # La CPU se mide al pedirla (sin temporizador: katd no gasta nada en reposo).
        # El % es el uso medio desde la consulta anterior.
        self._cpu_antes = sistema.tiempos_cpu()
        self._cpu_momento = time.monotonic() - MUESTREO_MIN_S  # la 1.ª consulta ya mide
        self.cpu_pct = 0.0

    def _muestrear_cpu(self):
        if time.monotonic() - self._cpu_momento < MUESTREO_MIN_S:
            return
        ahora = sistema.tiempos_cpu()
        self.cpu_pct = sistema.porcentaje_cpu(self._cpu_antes, ahora)
        self._cpu_antes = ahora
        self._cpu_momento = time.monotonic()

    # --- métodos D-Bus ------------------------------------------
    def Version(self):
        return GLib.Variant("(s)", (VERSION,))

    def LogEvent(self, app, nivel, mensaje):
        nuevo_id, momento = self.registro.agregar_evento(app, nivel, mensaje)
        if self.conexion is not None:
            self.conexion.emit_signal(
                None, OBJECT_PATH, INTERFACE, "EventLogged",
                GLib.Variant("(tdsss)", (nuevo_id, momento, app, nivel, mensaje)))
        return GLib.Variant("(t)", (nuevo_id,))

    def RecentEvents(self, limite, app):
        return GLib.Variant("(a(tdsss))", (self.registro.eventos_recientes(limite, app),))

    def RegisterApp(self, app_id, version):
        self.registro.registrar_app(app_id, version)
        return None

    def Apps(self):
        return GLib.Variant("(a(ssd))", (self.registro.apps(),))

    def SystemStats(self):
        self._muestrear_cpu()
        mem_total, mem_usada = sistema.memoria()
        disco_total, disco_usado = sistema.disco("/")
        datos = {
            "cpu_percent": GLib.Variant("d", self.cpu_pct),
            "mem_total": GLib.Variant("t", mem_total),
            "mem_used": GLib.Variant("t", mem_usada),
            "disk_total": GLib.Variant("t", disco_total),
            "disk_used": GLib.Variant("t", disco_usado),
            "uptime": GLib.Variant("d", sistema.tiempo_encendido()),
        }
        return GLib.Variant("(a{sv})", (datos,))

    def SystemInfo(self):
        return GLib.Variant("(a{ss})", (sistema.info_sistema(),))

    # --- despacho ------------------------------------------------
    def atender(self, _con, _remitente, _ruta, _interfaz, metodo, parametros, invocacion):
        funcion = getattr(self, metodo, None)
        if funcion is None:
            invocacion.return_dbus_error(ERROR_INTERNO, "Método desconocido: " + metodo)
            return
        try:
            resultado = funcion(*parametros.unpack())
        except ErrorDeDatos as e:
            invocacion.return_dbus_error(ERROR_DATOS, str(e))
            return
        except Exception as e:  # nunca dejar a una app colgada esperando
            print("katd: error en %s: %r" % (metodo, e), file=sys.stderr, flush=True)
            invocacion.return_dbus_error(ERROR_INTERNO, "%s falló: %s" % (metodo, e))
            return
        invocacion.return_value(resultado)


def main():
    registro = Registro()
    core = KatCore(registro)
    bucle = GLib.MainLoop()
    info = Gio.DBusNodeInfo.new_for_xml(INTROSPECCION).interfaces[0]
    estado = {"codigo": 0, "listo": False}

    def bus_listo(conexion, _nombre):
        core.conexion = conexion
        conexion.register_object(OBJECT_PATH, info, core.atender, None, None)

    def nombre_obtenido(_con, nombre):
        estado["listo"] = True
        print("katd %s listo en %s" % (VERSION, nombre), flush=True)

    def nombre_perdido(_con, nombre):
        if estado["listo"]:
            # La sesión se cerró (el bus desapareció): salida normal.
            print("katd: la sesión terminó, cerrando", flush=True)
        else:
            print("katd: no se pudo obtener %s (¿ya hay otro katd?)" % nombre, file=sys.stderr, flush=True)
            estado["codigo"] = 1
        bucle.quit()

    Gio.bus_own_name(Gio.BusType.SESSION, BUS_NAME, Gio.BusNameOwnerFlags.NONE,
                     bus_listo, nombre_obtenido, nombre_perdido)
    for sig in (signal.SIGINT, signal.SIGTERM):
        GLib.unix_signal_add(GLib.PRIORITY_DEFAULT, sig, bucle.quit)
    bucle.run()
    registro.cerrar()
    return estado["codigo"]
