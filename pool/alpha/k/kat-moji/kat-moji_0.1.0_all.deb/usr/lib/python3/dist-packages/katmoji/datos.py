"""Los emojis de KatMoji: cargar, buscar en español y recordar los recientes."""

import json
import os
import unicodedata

from katui import plataforma

ARCHIVO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "emojis.json")
MAX_RECIENTES = 40
# un emoji que representa cada grupo (para las pestañas)
ICONOS_GRUPO = {"Caras y emociones": "😀", "Personas": "👋", "Animales y naturaleza": "🐱",
                "Comida y bebida": "🍔", "Viajes y lugares": "✈️", "Actividades": "⚽", "Objetos": "💡",
                "Símbolos": "❤️", "Banderas": "🏳️"}


class Emoji:
    __slots__ = ("caracter", "nombre", "grupo", "claves", "_texto")

    def __init__(self, caracter, nombre, grupo, claves):
        self.caracter, self.nombre, self.grupo, self.claves = caracter, nombre, grupo, claves
        self._texto = normalizar(" ".join([nombre] + claves))

    def coincide(self, palabras):
        return all(p in self._texto for p in palabras)

    def __repr__(self):
        return "Emoji(%s %s)" % (self.caracter, self.nombre)


def normalizar(t):
    t = unicodedata.normalize("NFD", (t or "").lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


class Catalogo:
    def __init__(self, archivo=ARCHIVO):
        with open(archivo, encoding="utf-8") as f:
            datos = json.load(f)
        self.version_unicode = datos.get("version_unicode", "")
        self.grupos = datos["grupos"]
        self.emojis = [Emoji(*e) for e in datos["emojis"]]
        self._por_caracter = {e.caracter: e for e in self.emojis}

    def del_grupo(self, grupo):
        return [e for e in self.emojis if e.grupo == grupo]

    def buscar(self, texto, limite=300):
        palabras = normalizar(texto).split()
        if not palabras:
            return []
        hallados = [e for e in self.emojis if e.coincide(palabras)]
        # primero los que empiezan por lo buscado en el nombre
        hallados.sort(key=lambda e: (not normalizar(e.nombre).startswith(palabras[0]), len(e.nombre)))
        return hallados[:limite]

    def por_caracter(self, caracter):
        return self._por_caracter.get(caracter)


# --- recientes -----------------------------------------------------------------
def _archivo_recientes():
    return os.path.join(plataforma.carpeta_config("katmoji"), "recientes.json")


def leer_recientes():
    try:
        with open(_archivo_recientes(), encoding="utf-8") as f:
            lista = json.load(f)
        return [x for x in lista if isinstance(x, str)][:MAX_RECIENTES]
    except (OSError, ValueError):
        return []


def agregar_reciente(caracter):
    lista = [caracter] + [x for x in leer_recientes() if x != caracter]
    with open(_archivo_recientes(), "w", encoding="utf-8") as f:
        json.dump(lista[:MAX_RECIENTES], f, ensure_ascii=False)
    return lista[:MAX_RECIENTES]
