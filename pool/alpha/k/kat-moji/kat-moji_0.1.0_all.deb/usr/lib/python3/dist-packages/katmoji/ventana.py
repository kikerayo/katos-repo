"""Ventana de KatMoji: buscador, pestañas por grupo y la cuadrícula de emojis.

Un clic copia el emoji; luego lo pegas donde quieras con Ctrl+V.
"""

from PySide6.QtCore import QRect, QSize, Qt, QTimer
from PySide6.QtGui import QFont, QGuiApplication, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QLineEdit, QListView, QListWidget, QListWidgetItem, QPushButton, QVBoxLayout,
    QWidget,
)

from katui import plataforma, recursos
from katui.estilo import COLORES, rol

from . import VERSION, datos

FUENTE_EMOJI = "Segoe UI Emoji" if plataforma.ES_WINDOWS else "Noto Color Emoji"
TAM_EMOJI = 36


class VentanaKatMoji(QWidget):
    def __init__(self, catalogo=None):
        super().__init__()
        self.catalogo = catalogo or datos.Catalogo()
        self.setWindowTitle("KatMoji")
        ruta = recursos.icono("kat-moji")
        if ruta:
            self.setWindowIcon(QIcon(ruta))
        self.resize(520, 560)

        caja = QVBoxLayout(self)
        caja.setContentsMargins(14, 14, 14, 10)
        self.buscador = QLineEdit()
        self.buscador.setPlaceholderText("Buscar emoji… (gato, corazón, fiesta, Honduras)")
        self.buscador.setClearButtonEnabled(True)
        self.buscador.textChanged.connect(self._buscar)
        caja.addWidget(self.buscador)

        pestanas = QHBoxLayout()
        pestanas.setSpacing(2)
        self.botones = {}
        fuente_boton = QFont(FUENTE_EMOJI, 15)
        for clave, icono, ayuda in [("recientes", "🕘", "Recientes")] + \
                [(g, datos.ICONOS_GRUPO.get(g, "•"), g) for g in self.catalogo.grupos]:
            b = QPushButton(icono)
            b.setFont(fuente_boton)
            b.setToolTip(ayuda)
            b.setCheckable(True)
            b.setFixedSize(46, 40)
            b.setStyleSheet("QPushButton{background:transparent;border:none;border-radius:8px;"
                            "font-family:'%s';font-size:15pt;}"
                            "QPushButton:checked{background:%s;}" % (FUENTE_EMOJI, COLORES["borde"]))
            b.clicked.connect(lambda _=False, c=clave: self.mostrar_grupo(c))
            pestanas.addWidget(b)
            self.botones[clave] = b
        caja.addLayout(pestanas)

        self.titulo = rol(QLabel(""), "subtitulo")
        caja.addWidget(self.titulo)
        self.lista = QListWidget()
        self.lista.setViewMode(QListView.IconMode)
        # Cada emoji se dibuja como imagen (no como texto): así nunca se recorta en "..."
        self.lista.setIconSize(QSize(TAM_EMOJI, TAM_EMOJI))
        self.lista.setGridSize(QSize(TAM_EMOJI + 14, TAM_EMOJI + 14))
        self._iconos = {}
        self.lista.setResizeMode(QListView.Adjust)
        self.lista.setMovement(QListView.Static)
        self.lista.setUniformItemSizes(True)
        self.lista.setMouseTracking(True)
        self.lista.itemClicked.connect(self.copiar)
        self.lista.itemEntered.connect(lambda it: self.estado.setText(it.toolTip()))
        caja.addWidget(self.lista, 1)

        self.estado = rol(QLabel("Haz clic en un emoji para copiarlo; luego pégalo con Ctrl+V."), "subtitulo")
        caja.addWidget(self.estado)
        pie = rol(QLabel("KatMoji %s · %d emojis (Unicode %s)" % (VERSION, len(self.catalogo.emojis),
                                                                  self.catalogo.version_unicode)), "subtitulo")
        pie.setStyleSheet("font-size:8pt;")
        caja.addWidget(pie)
        self._ultimo_grupo = None
        recientes = datos.leer_recientes()
        self.mostrar_grupo("recientes" if recientes else self.catalogo.grupos[0])

    def icono(self, caracter):
        """El emoji dibujado en una imagen (con la fuente de emojis a color del sistema)."""
        icono = self._iconos.get(caracter)
        if icono is None:
            px = QPixmap(TAM_EMOJI * 2, TAM_EMOJI * 2)        # doble tamaño: nítido en pantallas grandes
            px.fill(Qt.transparent)
            p = QPainter(px)
            p.setRenderHint(QPainter.TextAntialiasing)
            fuente = QFont(FUENTE_EMOJI)
            fuente.setPixelSize(int(TAM_EMOJI * 1.55))
            p.setFont(fuente)
            p.drawText(QRect(0, 0, px.width(), px.height()), Qt.AlignCenter, caracter)
            p.end()
            icono = QIcon(px)
            self._iconos[caracter] = icono
        return icono

    def _poner(self, emojis):
        self.lista.clear()
        for e in emojis:
            item = QListWidgetItem(self.icono(e.caracter), "")
            item.setToolTip("%s  %s" % (e.caracter, e.nombre))
            item.setData(Qt.UserRole, e.caracter)
            self.lista.addItem(item)

    def mostrar_grupo(self, clave):
        self._ultimo_grupo = clave
        for c, b in self.botones.items():
            b.setChecked(c == clave)
        if clave == "recientes":
            emojis = [self.catalogo.por_caracter(c) for c in datos.leer_recientes()]
            emojis = [e for e in emojis if e]
            self.titulo.setText("Recientes" if emojis else "Recientes (todavía ninguno)")
        else:
            emojis = self.catalogo.del_grupo(clave)
            self.titulo.setText("%s · %d" % (clave, len(emojis)))
        self._poner(emojis)

    def _buscar(self, texto):
        if not texto.strip():
            self.mostrar_grupo(self._ultimo_grupo or self.catalogo.grupos[0])
            return
        for b in self.botones.values():
            b.setChecked(False)
        hallados = self.catalogo.buscar(texto)
        self.titulo.setText("%d resultado%s para «%s»" % (len(hallados), "" if len(hallados) == 1 else "s", texto.strip())
                            if hallados else "Ningún emoji con «%s»" % texto.strip())
        self._poner(hallados)

    def copiar(self, item):
        caracter = item.data(Qt.UserRole)
        QGuiApplication.clipboard().setText(caracter)
        datos.agregar_reciente(caracter)
        e = self.catalogo.por_caracter(caracter)
        self.estado.setStyleSheet("color:%s;" % COLORES["ok"])
        self.estado.setText("✔ Copiado %s %s — pégalo con Ctrl+V" % (caracter, e.nombre if e else ""))
        QTimer.singleShot(2500, lambda: self.estado.setStyleSheet(""))
