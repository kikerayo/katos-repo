"""KatMoji: buscar y copiar emojis, con sus nombres en español.

Datos: emojis.json, generado de las fuentes oficiales de Unicode
(emoji-test.txt + CLDR en español) con herramientas/generar_datos.py.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.KatMoji"
