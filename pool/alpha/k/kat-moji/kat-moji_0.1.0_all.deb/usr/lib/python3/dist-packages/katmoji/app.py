"""Punto de entrada de KatMoji.  Uso: kat-moji [buscar texto]"""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaKatMoji

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("KatMoji")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaKatMoji()
    texto = " ".join(a for a in argv if not a.startswith("-"))
    if texto:
        v.buscador.setText(texto)
    v.show()
    return app.exec()
