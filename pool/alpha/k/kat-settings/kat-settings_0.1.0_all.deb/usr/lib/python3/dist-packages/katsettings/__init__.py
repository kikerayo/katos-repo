"""Kat Settings: el panel de ajustes de Kat OS.

Cada sección vive en su propio módulo (pantalla, sonido, red, energia,
hora, acerca) con dos tipos de funciones:
  - leer_*: devuelven el estado actual, o None si aquí no se puede saber.
  - cambiar_* / poner_*: aplican el cambio y devuelven un Resultado.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Settings"
