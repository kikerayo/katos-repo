"""Red: conexiones activas, Wi-Fi encendido/apagado y conectarse a una red, con nmcli."""

import subprocess

from katui import acciones, plataforma

TIPOS = {"802-3-ethernet": "Cable", "802-11-wireless": "Wi-Fi", "vpn": "VPN", "loopback": "Interna",
         "bridge": "Puente", "wireguard": "VPN"}


def campos(linea):
    """Separa una línea de 'nmcli -t' respetando los ':' escapados (\\:)."""
    partes, actual, i = [], "", 0
    while i < len(linea):
        c = linea[i]
        if c == "\\" and i + 1 < len(linea):
            actual += linea[i + 1]
            i += 2
            continue
        if c == ":":
            partes.append(actual)
            actual = ""
        else:
            actual += c
        i += 1
    partes.append(actual)
    return partes


def interpretar_conexiones(texto):
    """'NOMBRE:TIPO:DISPOSITIVO' por línea -> [(nombre, tipo legible, dispositivo)] sin la interna."""
    salida = []
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        nombre, tipo, disp = (campos(linea) + ["", "", ""])[:3]
        if tipo == "loopback":
            continue
        salida.append((nombre, TIPOS.get(tipo, tipo), disp))
    return salida


def interpretar_wifi(texto):
    """'EN-USO:SSID:SEÑAL:SEGURIDAD' -> [(ssid, señal, segura, en_uso)] sin repetidos, mejor señal primero."""
    redes = {}
    for linea in texto.splitlines():
        if not linea.strip():
            continue
        uso, ssid, senal, seg = (campos(linea) + ["", "", "", ""])[:4]
        if not ssid:
            continue
        senal = int(senal or 0)
        previa = redes.get(ssid)
        if previa is None or senal > previa[1]:
            redes[ssid] = (ssid, senal, bool(seg and seg != "--"), uso.strip() == "*")
    return sorted(redes.values(), key=lambda r: (not r[3], -r[1]))


def _nmcli(*args, tiempo=20):
    r = subprocess.run(["nmcli", "-t"] + list(args), capture_output=True, text=True, timeout=tiempo)
    return r.stdout if r.returncode == 0 else None


def leer_conexiones():
    if not plataforma.tiene("nmcli"):
        return None
    texto = _nmcli("-f", "NAME,TYPE,DEVICE", "connection", "show", "--active")
    return None if texto is None else interpretar_conexiones(texto)


def leer_wifi_encendido():
    if not plataforma.tiene("nmcli"):
        return None
    texto = _nmcli("radio", "wifi")
    return None if texto is None else texto.strip() == "enabled"


def leer_redes_wifi():
    if not plataforma.tiene("nmcli"):
        return None
    texto = _nmcli("-f", "IN-USE,SSID,SIGNAL,SECURITY", "device", "wifi", "list", "--rescan", "yes", tiempo=40)
    return None if texto is None else interpretar_wifi(texto)


def poner_wifi(encendido):
    if not plataforma.tiene("nmcli"):
        return acciones.no_disponible("El Wi-Fi se controla en Kat OS")
    r = acciones.ejecutar(["nmcli", "radio", "wifi", "on" if encendido else "off"])
    return acciones.hecho("Wi-Fi %s" % ("encendido" if encendido else "apagado")) if r.ok else r


def conectar_wifi(ssid, contrasena=""):
    if not plataforma.tiene("nmcli"):
        return acciones.no_disponible("Las redes se conectan en Kat OS")
    cmd = ["nmcli", "device", "wifi", "connect", ssid]
    if contrasena:
        cmd += ["password", contrasena]
    r = acciones.ejecutar(cmd, tiempo=60)
    return acciones.hecho("conectado a %s" % ssid) if r.ok else r
