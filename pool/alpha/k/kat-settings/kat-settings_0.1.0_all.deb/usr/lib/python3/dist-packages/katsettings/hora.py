"""Fecha y hora: zona horaria y hora automática por internet, con timedatectl.

Cambiar la zona o la hora automática lo autoriza polkit (pide contraseña si hace falta).
"""

import subprocess

from katui import acciones, plataforma

ZONAS_COMUNES = [
    "America/Tegucigalpa", "America/Mexico_City", "America/Guatemala", "America/El_Salvador",
    "America/Managua", "America/Costa_Rica", "America/Panama", "America/Bogota", "America/Lima",
    "America/Caracas", "America/Santiago", "America/Argentina/Buenos_Aires", "America/New_York",
    "America/Los_Angeles", "Europe/Madrid", "UTC",
]


def _leer(prop):
    r = subprocess.run(["timedatectl", "show", "-p", prop, "--value"], capture_output=True, text=True, timeout=10)
    return r.stdout.strip() if r.returncode == 0 else None


def leer_zona():
    return _leer("Timezone") if plataforma.tiene("timedatectl") else None


def leer_hora_automatica():
    if not plataforma.tiene("timedatectl"):
        return None
    v = _leer("NTP")
    return None if v is None else v == "yes"


def leer_zonas():
    if not plataforma.tiene("timedatectl"):
        return list(ZONAS_COMUNES)
    r = subprocess.run(["timedatectl", "list-timezones"], capture_output=True, text=True, timeout=10)
    return r.stdout.split() if r.returncode == 0 else list(ZONAS_COMUNES)


def poner_zona(zona):
    if not zona or "/" not in zona and zona != "UTC":
        return acciones.fallo("Zona horaria no válida")
    if not plataforma.tiene("timedatectl"):
        return acciones.no_disponible("La hora se ajusta en Kat OS")
    r = acciones.ejecutar(["timedatectl", "set-timezone", zona], tiempo=120)
    return acciones.hecho("zona %s" % zona) if r.ok else r


def poner_hora_automatica(si):
    if not plataforma.tiene("timedatectl"):
        return acciones.no_disponible("La hora se ajusta en Kat OS")
    r = acciones.ejecutar(["timedatectl", "set-ntp", "true" if si else "false"], tiempo=120)
    return acciones.hecho("hora automática %s" % ("activada" if si else "desactivada")) if r.ok else r
