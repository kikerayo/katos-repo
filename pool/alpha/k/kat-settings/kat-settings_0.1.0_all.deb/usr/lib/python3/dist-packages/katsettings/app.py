"""Punto de entrada de Kat Settings."""

import sys

from . import APP_ID, VERSION


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if "--version" in argv:
        print(VERSION)
        return 0
    from PySide6.QtWidgets import QApplication

    from katui import estilo

    from .ventana import VentanaSettings

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("Kat Settings")
    app.setApplicationVersion(VERSION)
    app.setDesktopFileName(APP_ID)
    estilo.aplicar(app)
    v = VentanaSettings()
    # kat-settings --seccion seguridad   (lo usa el icono "Kat Security" del escritorio)
    if "--seccion" in argv and argv.index("--seccion") + 1 < len(argv):
        v.abrir_seccion(argv[argv.index("--seccion") + 1])
    v.show()
    try:
        from katcore.cliente import KatCoreCliente
        KatCoreCliente().registrar_app(APP_ID, VERSION)
    except Exception:
        pass
    return app.exec()
