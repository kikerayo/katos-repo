"""Acerca de este equipo: datos reales del sistema (Linux o Windows)."""

import os
import platform
import shutil

from katui import plataforma


def _os_release():
    datos = {}
    try:
        with open("/etc/os-release", encoding="utf-8") as f:
            for linea in f:
                k, igual, v = linea.strip().partition("=")
                if igual:
                    datos[k] = v.strip('"')
    except OSError:
        pass
    return datos


def _memoria_gb():
    try:
        with open("/proc/meminfo", encoding="utf-8") as f:
            for linea in f:
                if linea.startswith("MemTotal:"):
                    return int(linea.split()[1]) / 1024 ** 2
    except OSError:
        pass
    if plataforma.ES_WINDOWS:
        import ctypes

        class Estado(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        e = Estado()
        e.dwLength = ctypes.sizeof(Estado)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(e)):
            return e.ullTotalPhys / 1024 ** 3
    return None


def _procesador():
    try:
        with open("/proc/cpuinfo", encoding="utf-8") as f:
            for linea in f:
                if linea.startswith("model name"):
                    return linea.split(":", 1)[1].strip()
    except OSError:
        pass
    return platform.processor() or platform.machine()


def leer():
    """Lista de (etiqueta, valor) para mostrar."""
    rel = _os_release()
    if plataforma.ES_KATOS:
        sistema = rel.get("PRETTY_NAME", "Kat OS Desktop")
    elif plataforma.ES_WINDOWS:
        sistema = "Windows %s (vista previa de Kat Settings)" % platform.release()
    else:
        sistema = "%s (vista previa)" % rel.get("PRETTY_NAME", platform.system())
    raiz = os.path.abspath(os.sep)
    disco = shutil.disk_usage(raiz)
    mem = _memoria_gb()
    return [
        ("Sistema", sistema),
        ("Nombre del equipo", platform.node()),
        ("Procesador", _procesador()),
        ("Núcleos", str(os.cpu_count() or 1)),
        ("Memoria RAM", "%.1f GB" % mem if mem else "desconocida"),
        ("Disco del sistema", "%.0f GB libres de %.0f GB" % (disco.free / 1024 ** 3, disco.total / 1024 ** 3)),
        ("Núcleo (kernel)", platform.release() if plataforma.ES_LINUX else "—"),
    ]
