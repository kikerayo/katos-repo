"""Energía: perfil de rendimiento (ahorro / equilibrado / máximo), con powerprofilesctl."""

import re
import subprocess

from katui import acciones, plataforma

NOMBRES = {"power-saver": "Ahorro de energía", "balanced": "Equilibrado", "performance": "Máximo rendimiento"}


def interpretar_lista(texto):
    """Salida de 'powerprofilesctl list' -> (perfiles disponibles, perfil activo)."""
    perfiles, activo = [], None
    for linea in texto.splitlines():
        m = re.match(r"^(\*?)\s*([a-z-]+):\s*$", linea)
        if m:
            perfiles.append(m.group(2))
            if m.group(1) == "*":
                activo = m.group(2)
    return perfiles, activo


def leer_perfiles():
    """(disponibles, activo) o None."""
    if not plataforma.tiene("powerprofilesctl"):
        return None
    r = subprocess.run(["powerprofilesctl", "list"], capture_output=True, text=True, timeout=10)
    return interpretar_lista(r.stdout) if r.returncode == 0 else None


def poner_perfil(perfil):
    if perfil not in NOMBRES:
        return acciones.fallo("Perfil desconocido")
    if not plataforma.tiene("powerprofilesctl"):
        return acciones.no_disponible("La energía se ajusta en Kat OS")
    r = acciones.ejecutar(["powerprofilesctl", "set", perfil])
    return acciones.hecho(NOMBRES[perfil]) if r.ok else r
