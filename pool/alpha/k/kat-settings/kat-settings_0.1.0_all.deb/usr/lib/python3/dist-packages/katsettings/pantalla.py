"""Pantallas: resolución y escala, con kscreen-doctor (KDE)."""

import json
import subprocess

from katui import acciones, plataforma

ESCALAS = (1.0, 1.25, 1.5, 1.75, 2.0)


class Pantalla:
    def __init__(self, nombre, modo_actual, modos, escala):
        self.nombre = nombre
        self.modo_actual = modo_actual      # "1920x1080@60"
        self.modos = modos                  # ["1920x1080@60", ...] sin repetir, mayor primero
        self.escala = escala

    def __repr__(self):
        return "Pantalla(%s %s x%s)" % (self.nombre, self.modo_actual, self.escala)


def _nombre_modo(m):
    w, h = m["size"]["width"], m["size"]["height"]
    return "%dx%d@%d" % (w, h, round(m.get("refreshRate", 60)))


def interpretar(texto):
    """Convierte la salida de 'kscreen-doctor -j' en una lista de Pantalla (solo las encendidas)."""
    datos = json.loads(texto)
    pantallas = []
    for o in datos.get("outputs", []):
        if not (o.get("connected") and o.get("enabled")):
            continue
        modos, actual = [], None
        orden = sorted(o.get("modes", []), key=lambda m: (m["size"]["width"] * m["size"]["height"],
                                                          m.get("refreshRate", 0)), reverse=True)
        for m in orden:
            n = _nombre_modo(m)
            if n not in modos:
                modos.append(n)
            if str(m.get("id")) == str(o.get("currentModeId")):
                actual = n
        pantallas.append(Pantalla(o["name"], actual, modos, float(o.get("scale", 1))))
    return pantallas


def leer_pantallas():
    if not plataforma.tiene("kscreen-doctor"):
        return None
    try:
        r = subprocess.run(["kscreen-doctor", "-j"], capture_output=True, text=True, timeout=15)
        return interpretar(r.stdout) if r.returncode == 0 else None
    except (subprocess.TimeoutExpired, ValueError):
        return None


def cambiar_modo(pantalla, modo):
    if not plataforma.tiene("kscreen-doctor"):
        return acciones.no_disponible("La pantalla se ajusta en Kat OS")
    r = acciones.ejecutar(["kscreen-doctor", "output.%s.mode.%s" % (pantalla, modo)])
    return acciones.hecho("resolución %s" % modo.split("@")[0]) if r.ok else r


def cambiar_escala(pantalla, escala):
    if escala not in ESCALAS:
        return acciones.fallo("Escala no permitida")
    if not plataforma.tiene("kscreen-doctor"):
        return acciones.no_disponible("La pantalla se ajusta en Kat OS")
    r = acciones.ejecutar(["kscreen-doctor", "output.%s.scale.%s" % (pantalla, ("%g" % escala))])
    return acciones.hecho("escala %d %%" % round(escala * 100)) if r.ok else r
