"""Ventana de Kat Settings: lista de secciones a la izquierda (como la
Configuración de Windows) y la sección elegida a la derecha.

Cada cambio se aplica en segundo plano y su resultado real aparece debajo:
✔ hecho, ✖ falló (con el motivo) o ⓘ "solo en Kat OS".
"""

import os

from PySide6.QtCore import QProcess, QSize, Qt, QTimer, QDateTime
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QCompleter, QFileDialog, QFormLayout, QFrame, QHBoxLayout,
    QInputDialog, QLabel, QLineEdit, QListView, QListWidget, QListWidgetItem, QPushButton, QRadioButton,
    QScrollArea, QSlider, QStackedWidget, QVBoxLayout, QWidget,
)

from katui import acciones as res
from katui import cuenta, escritorio, pin, plataforma, recursos, sistema
from katui.estilo import COLORES, rol
from katui.qt import EtiquetaResultado, en_segundo_plano

from . import VERSION, acerca, energia, hora, pantalla, red, sonido


class Seccion(QWidget):
    titulo = ""
    icono = ""
    descripcion = ""

    def __init__(self):
        super().__init__()
        exterior = QVBoxLayout(self)
        exterior.setContentsMargins(0, 0, 0, 0)
        area = QScrollArea()
        area.setWidgetResizable(True)
        interior = QWidget()
        self.caja = QVBoxLayout(interior)
        self.caja.setContentsMargins(32, 28, 32, 24)
        self.caja.addWidget(rol(QLabel(self.titulo), "titulo"))
        if self.descripcion:
            d = rol(QLabel(self.descripcion), "subtitulo")
            d.setWordWrap(True)
            self.caja.addWidget(d)
        self.aviso = rol(QLabel(""), "aviso")
        self.aviso.setWordWrap(True)
        self.aviso.hide()
        self.caja.addWidget(self.aviso)
        self.caja.addSpacing(10)
        self.construir()
        self.resultado = EtiquetaResultado()
        self.caja.addSpacing(8)
        self.caja.addWidget(self.resultado)
        self.caja.addStretch(1)
        area.setWidget(interior)
        exterior.addWidget(area)

    # para las subclases
    def construir(self):
        pass

    def cargar(self):
        """Lee el estado actual. Se llama cada vez que se abre la sección."""

    def avisar(self, texto):
        self.aviso.setText("ⓘ  " + texto)
        self.aviso.setVisible(bool(texto))

    def tarjeta(self, titulo=None):
        t = rol(QFrame(), "tarjeta")
        caja = QVBoxLayout(t)
        caja.setContentsMargins(18, 14, 18, 14)
        if titulo:
            l = QLabel(titulo)
            l.setStyleSheet("font-weight:600;")
            caja.addWidget(l)
        self.caja.addWidget(t)
        return caja

    def aplicar(self, funcion, *args, recargar=True):
        self.resultado.trabajando()

        def fin(r):
            self.resultado.mostrar(r)
            if recargar:
                self.cargar()
        return en_segundo_plano(funcion, *args, al_terminar=fin)


# --- secciones ---------------------------------------------------------------
class SeccionPersonalizacion(Seccion):
    titulo, icono = "Personalización", "kat-settings"
    descripcion = "Modo oscuro o claro, color de acento y fondo de pantalla."

    def construir(self):
        c = self.tarjeta("Tema")
        fila = QHBoxLayout()
        self.modos = QButtonGroup(self)
        for clave, texto in (("oscuro", "Oscuro"), ("claro", "Claro")):
            b = QRadioButton(texto)
            b.setProperty("clave", clave)
            self.modos.addButton(b)
            fila.addWidget(b)
        fila.addStretch(1)
        c.addLayout(fila)
        fila2 = QHBoxLayout()
        self.acentos = QButtonGroup(self)
        for clave, color in escritorio.ACENTOS.items():
            b = QPushButton()
            b.setCheckable(True)
            b.setFixedSize(36, 36)
            b.setToolTip(clave.capitalize())
            b.setProperty("clave", clave)
            b.setStyleSheet("QPushButton{background:%s;border-radius:18px;border:3px solid transparent;}"
                            "QPushButton:checked{border:3px solid white;}" % color)
            self.acentos.addButton(b)
            fila2.addWidget(b)
        fila2.addStretch(1)
        self.boton_tema = rol(QPushButton("Aplicar tema"), "principal")
        self.boton_tema.clicked.connect(self._tema)
        fila2.addWidget(self.boton_tema)
        c.addLayout(fila2)

        c2 = self.tarjeta("Fondo de pantalla (clic para aplicarlo)")
        self.fondos = QListWidget()
        self.fondos.setViewMode(QListView.IconMode)
        self.fondos.setIconSize(QSize(176, 99))
        self.fondos.setGridSize(QSize(196, 132))
        self.fondos.setMovement(QListView.Static)
        self.fondos.setResizeMode(QListView.Adjust)
        self.fondos.setMinimumHeight(300)
        for f in recursos.fondos():
            item = QListWidgetItem(QIcon(f.miniatura), f.nombre)
            item.setData(Qt.UserRole, f.imagen)
            self.fondos.addItem(item)
        self.fondos.itemClicked.connect(lambda it: self.aplicar(escritorio.cambiar_fondo, it.data(Qt.UserRole),
                                                                 recargar=False))
        c2.addWidget(self.fondos)

    def cargar(self):
        modo = escritorio.modo_actual() or "oscuro"
        acento = escritorio.acento_actual() or "violeta"
        for b in self.modos.buttons():
            b.setChecked(b.property("clave") == modo)
        for b in self.acentos.buttons():
            b.setChecked(b.property("clave") == acento)
        self.avisar("" if plataforma.tiene("plasma-apply-colorscheme")
                    else "Aquí puedes elegir, pero el tema y el fondo solo se aplican en Kat OS.")

    def _tema(self):
        self.aplicar(escritorio.cambiar_apariencia, self.modos.checkedButton().property("clave"),
                     self.acentos.checkedButton().property("clave"))


class SeccionCuenta(Seccion):
    titulo, icono = "Tu cuenta", "kat-cuenta"
    descripcion = "Tu nombre y tu foto de perfil (se ven al iniciar sesión)."

    def construir(self):
        c = self.tarjeta("Nombre")
        fila = QHBoxLayout()
        self.nombre = QLineEdit()
        self.nombre.setMaxLength(60)
        guardar = rol(QPushButton("Guardar"), "principal")
        guardar.clicked.connect(lambda: self.aplicar(cuenta.cambiar_nombre, self.nombre.text()))
        fila.addWidget(self.nombre, 1)
        fila.addWidget(guardar)
        c.addLayout(fila)
        self.usuario = rol(QLabel(""), "subtitulo")
        c.addWidget(self.usuario)

        c2 = self.tarjeta("Foto de perfil (clic para usarla)")
        self.fotos = QListWidget()
        self.fotos.setViewMode(QListView.IconMode)
        self.fotos.setIconSize(QSize(72, 72))
        self.fotos.setGridSize(QSize(90, 90))
        self.fotos.setMovement(QListView.Static)
        self.fotos.setResizeMode(QListView.Adjust)
        self.fotos.setMinimumHeight(200)
        for ruta in recursos.avatares():
            item = QListWidgetItem(QIcon(ruta), "")
            item.setData(Qt.UserRole, ruta)
            self.fotos.addItem(item)
        self.fotos.itemClicked.connect(lambda it: self.aplicar(cuenta.cambiar_foto, it.data(Qt.UserRole)))
        c2.addWidget(self.fotos)
        otra = QPushButton("Usar otra imagen…")
        otra.clicked.connect(self._otra)
        c2.addWidget(otra, 0, Qt.AlignLeft)

    def _otra(self):
        ruta, _ = QFileDialog.getOpenFileName(self, "Elegir foto de perfil", os.path.expanduser("~"),
                                              "Imágenes (*.png *.jpg *.jpeg *.webp)")
        if ruta:
            self.aplicar(cuenta.cambiar_foto, ruta)

    def cargar(self):
        self.nombre.setText(cuenta.nombre_actual())
        self.usuario.setText("Usuario: %s" % cuenta.usuario())
        self.avisar("" if plataforma.ES_LINUX else "Tu nombre y foto solo se cambian en Kat OS.")


class SeccionPantalla(Seccion):
    titulo, icono = "Pantalla", "kat-pantalla"
    descripcion = "Resolución y tamaño de los elementos (escala)."

    def construir(self):
        self.contenedor = QVBoxLayout()
        self.caja.addLayout(self.contenedor)
        self.filas = []

    def cargar(self):
        while self.contenedor.count():
            w = self.contenedor.takeAt(0).widget()
            if w:
                w.deleteLater()
        pantallas = pantalla.leer_pantallas()
        if pantallas is None:
            self.avisar("La pantalla solo se ajusta en Kat OS.")
            return
        self.avisar("")
        for p in pantallas:
            t = rol(QFrame(), "tarjeta")
            f = QFormLayout(t)
            f.addRow(QLabel("<b>%s</b>" % p.nombre))
            modos = QComboBox()
            modos.addItems(p.modos)
            if p.modo_actual:
                modos.setCurrentText(p.modo_actual)
            escalas = QComboBox()
            for e in pantalla.ESCALAS:
                escalas.addItem("%d %%" % round(e * 100), e)
            escalas.setCurrentIndex(max(0, escalas.findData(p.escala)))
            aplicar = rol(QPushButton("Aplicar"), "principal")
            aplicar.clicked.connect(lambda _=False, n=p.nombre, m=modos, e=escalas: self._aplicar(n, m, e))
            f.addRow("Resolución:", modos)
            f.addRow("Escala:", escalas)
            f.addRow("", aplicar)
            self.contenedor.addWidget(t)

    def _aplicar(self, nombre, modos, escalas):
        def ambos():
            r = pantalla.cambiar_modo(nombre, modos.currentText())
            if not r.ok:
                return r
            r2 = pantalla.cambiar_escala(nombre, escalas.currentData())
            return res.hecho("%s, %s" % (r.mensaje, r2.mensaje)) if r2.ok else r2
        self.aplicar(ambos)


class SeccionSonido(Seccion):
    titulo, icono = "Sonido", "kat-sonido"
    descripcion = "Volumen de la salida principal."

    def construir(self):
        c = self.tarjeta("Volumen")
        fila = QHBoxLayout()
        self.barra = QSlider(Qt.Horizontal)
        self.barra.setRange(0, 150)
        self.valor = QLabel("–")
        self.valor.setMinimumWidth(50)
        self.barra.valueChanged.connect(lambda v: self.valor.setText("%d %%" % v))
        self.barra.sliderReleased.connect(lambda: self.aplicar(sonido.poner_volumen, self.barra.value(),
                                                               recargar=False))
        fila.addWidget(self.barra, 1)
        fila.addWidget(self.valor)
        c.addLayout(fila)
        self.silencio = QCheckBox("Silenciar")
        self.silencio.clicked.connect(lambda si: self.aplicar(sonido.silenciar, si, recargar=False))
        c.addWidget(self.silencio)

    def cargar(self):
        v = sonido.leer_volumen()
        if v is None:
            self.avisar("El sonido solo se controla en Kat OS.")
            return
        self.avisar("")
        self.barra.blockSignals(True)
        self.barra.setValue(v[0])
        self.barra.blockSignals(False)
        self.valor.setText("%d %%" % v[0])
        self.silencio.setChecked(v[1])


class SeccionRed(Seccion):
    titulo, icono = "Red e internet", "kat-red"
    descripcion = "Conexiones activas y redes Wi-Fi."

    def construir(self):
        c = self.tarjeta("Conectado a")
        self.activas = QLabel("–")
        self.activas.setWordWrap(True)
        c.addWidget(self.activas)
        c2 = self.tarjeta("Wi-Fi")
        self.wifi = QCheckBox("Wi-Fi encendido")
        self.wifi.clicked.connect(lambda si: self.aplicar(red.poner_wifi, si))
        c2.addWidget(self.wifi)
        self.redes = QListWidget()
        self.redes.setMinimumHeight(180)
        self.redes.itemDoubleClicked.connect(self._conectar)
        c2.addWidget(self.redes)
        fila = QHBoxLayout()
        self.buscar = QPushButton("Buscar redes")
        self.buscar.clicked.connect(self._buscar)
        conectar = rol(QPushButton("Conectar"), "principal")
        conectar.clicked.connect(lambda: self._conectar(self.redes.currentItem()))
        fila.addWidget(self.buscar)
        fila.addStretch(1)
        fila.addWidget(conectar)
        c2.addLayout(fila)

    def cargar(self):
        conexiones = red.leer_conexiones()
        if conexiones is None:
            self.avisar("La red solo se controla en Kat OS (aquí lo maneja Windows).")
            self.activas.setText("–")
            return
        self.avisar("")
        self.activas.setText("\n".join("%s  ·  %s (%s)" % (n, t, d) for n, t, d in conexiones)
                             or "Sin conexión")
        encendido = red.leer_wifi_encendido()
        self.wifi.setChecked(bool(encendido))

    def _buscar(self):
        self.buscar.setEnabled(False)
        self.resultado.trabajando("Buscando redes…")

        def fin(redes):
            self.buscar.setEnabled(True)
            self.redes.clear()
            if isinstance(redes, res.Resultado):
                self.resultado.mostrar(redes)
                return
            if redes is None:
                self.resultado.mostrar(res.no_disponible("Las redes Wi-Fi se buscan en Kat OS"))
                return
            for ssid, senal, segura, en_uso in redes:
                item = QListWidgetItem("%s%s   %d %%%s" % ("● " if en_uso else "", ssid, senal,
                                                          "  🔒" if segura else ""))
                item.setData(Qt.UserRole, (ssid, segura))
                self.redes.addItem(item)
            self.resultado.mostrar(res.hecho("%d redes encontradas" % len(redes)))
        en_segundo_plano(red.leer_redes_wifi, al_terminar=fin)

    def _conectar(self, item):
        if item is None:
            self.resultado.mostrar(res.fallo("Elige una red de la lista"))
            return
        ssid, segura = item.data(Qt.UserRole)
        clave = ""
        if segura:
            clave, ok = QInputDialog.getText(self, "Conectar a %s" % ssid, "Contraseña del Wi-Fi:",
                                             QLineEdit.Password)
            if not ok:
                return
        self.aplicar(red.conectar_wifi, ssid, clave)


class SeccionEnergia(Seccion):
    titulo, icono = "Energía", "kat-energia"
    descripcion = "Elige entre ahorrar batería o tener más rendimiento."

    def construir(self):
        self.c = self.tarjeta("Modo de energía")
        self.grupo = QButtonGroup(self)
        self.grupo.buttonClicked.connect(lambda b: self.aplicar(energia.poner_perfil, b.property("clave")))
        self.botones = {}
        for clave, nombre in energia.NOMBRES.items():
            b = QRadioButton(nombre)
            b.setProperty("clave", clave)
            self.grupo.addButton(b)
            self.c.addWidget(b)
            self.botones[clave] = b

    def cargar(self):
        datos = energia.leer_perfiles()
        if datos is None:
            self.avisar("La energía solo se ajusta en Kat OS.")
            return
        self.avisar("")
        disponibles, activo = datos
        for clave, b in self.botones.items():
            b.setVisible(clave in disponibles)
            b.setChecked(clave == activo)


class SeccionHora(Seccion):
    titulo, icono = "Fecha y hora", "kat-hora"
    descripcion = "Zona horaria y hora automática por internet."

    def construir(self):
        c = self.tarjeta()
        self.reloj = QLabel("")
        self.reloj.setStyleSheet("font-size:22pt;font-weight:600;")
        c.addWidget(self.reloj)
        self._tic = QTimer(self)
        self._tic.timeout.connect(lambda: self.reloj.setText(
            QDateTime.currentDateTime().toString("dddd d 'de' MMMM, HH:mm:ss")))
        self._tic.start(1000)
        f = QFormLayout()
        self.zona = QComboBox()
        self.zona.setEditable(True)
        self.zona.setInsertPolicy(QComboBox.NoInsert)
        self.zona.completer().setFilterMode(Qt.MatchContains)
        self.zona.completer().setCompletionMode(QCompleter.PopupCompletion)
        cambiar = rol(QPushButton("Cambiar zona"), "principal")
        cambiar.clicked.connect(lambda: self.aplicar(hora.poner_zona, self.zona.currentText()))
        fila = QHBoxLayout()
        fila.addWidget(self.zona, 1)
        fila.addWidget(cambiar)
        f.addRow("Zona horaria:", fila)
        c.addLayout(f)
        self.auto = QCheckBox("Poner la hora automáticamente (por internet)")
        self.auto.clicked.connect(lambda si: self.aplicar(hora.poner_hora_automatica, si))
        c.addWidget(self.auto)

    def cargar(self):
        if self.zona.count() == 0:
            self.zona.addItems(hora.leer_zonas())
        zona = hora.leer_zona()
        if zona is None:
            self.avisar("La hora del sistema solo se cambia en Kat OS.")
        else:
            self.avisar("")
            self.zona.setCurrentText(zona)
        auto = hora.leer_hora_automatica()
        self.auto.setChecked(bool(auto))


class SeccionSeguridad(Seccion):
    titulo, icono = "Seguridad", "kat-security"
    descripcion = "Cortafuegos y actualizaciones de seguridad. Te pedirá tu contraseña para cambiarlos."

    def construir(self):
        c = self.tarjeta()
        self.firewall = QCheckBox("Cortafuegos activado")
        self.firewall.clicked.connect(lambda si: self.aplicar(sistema.cambiar_firewall, si))
        self.auto = QCheckBox("Actualizaciones de seguridad automáticas")
        self.auto.clicked.connect(lambda si: self.aplicar(sistema.cambiar_actualizaciones, si))
        c.addWidget(self.firewall)
        c.addWidget(self.auto)
        nota = rol(QLabel("Kat OS no envía tus datos ni informes de fallos a nadie."), "subtitulo")
        c.addWidget(nota)

        c2 = self.tarjeta("PIN de desbloqueo (KatLock)")
        explica = rol(QLabel("Desbloquea la pantalla con un PIN de %d a %d números, escribiéndolo en la misma "
                             "casilla de la contraseña. Tu contraseña sigue funcionando. Tras %d intentos "
                             "fallidos el PIN se bloquea un rato y solo entra la contraseña."
                             % (pin.LARGO_MIN, pin.LARGO_MAX, pin.MAX_FALLOS)), "subtitulo")
        explica.setWordWrap(True)
        c2.addWidget(explica)
        self.pin_estado = QLabel("")
        c2.addWidget(self.pin_estado)
        fila = QHBoxLayout()
        self.pin_crear = rol(QPushButton("Crear PIN"), "principal")
        self.pin_crear.clicked.connect(self._crear_pin)
        self.pin_quitar = QPushButton("Quitar PIN")
        self.pin_quitar.clicked.connect(self._quitar_pin)
        fila.addWidget(self.pin_crear)
        fila.addWidget(self.pin_quitar)
        fila.addStretch(1)
        c2.addLayout(fila)

        c3 = self.tarjeta("Desbloqueo con tu cara (Kat Rostro)")
        explica = rol(QLabel("Opcional: al despertar la pantalla de bloqueo, Kat mira la cámara unos segundos "
                             "y, si eres tú, entra solo. Solo se guarda una huella numérica de tu cara, "
                             "nunca fotos, y nada sale del equipo."), "subtitulo")
        explica.setWordWrap(True)
        c3.addWidget(explica)
        aviso = rol(QLabel("⚠ Con una cámara normal (sin sensor 3D) una foto nítida de tu cara podría engañarlo. "
                           "Tu PIN y tu contraseña siguen funcionando siempre."), "aviso")
        aviso.setWordWrap(True)
        c3.addWidget(aviso)
        self.rostro_estado = QLabel("")
        c3.addWidget(self.rostro_estado)
        fila = QHBoxLayout()
        b = rol(QPushButton("Configurar rostro"), "principal")
        b.clicked.connect(self._abrir_rostro)
        fila.addWidget(b)
        fila.addStretch(1)
        c3.addLayout(fila)

    def cargar(self):
        fw, au = sistema.firewall_activo(), sistema.actualizaciones_automaticas()
        if fw is None:
            self.avisar("La seguridad del sistema solo se controla en Kat OS. (El PIN se guarda aquí para "
                        "probar, pero desbloquear con él funciona en Kat OS.)")
        else:
            self.avisar("")
        self.firewall.setChecked(bool(fw))
        self.auto.setChecked(bool(au))
        e = pin.estado()
        if e == "sin_pin":
            self.pin_estado.setText("Sin PIN")
        elif e == "activo":
            self.pin_estado.setText("✔ PIN activado")
        else:
            self.pin_estado.setText("⏳ PIN bloqueado por intentos fallidos (%d s); usa tu contraseña" % e[1])
        self.pin_crear.setText("Cambiar PIN" if e != "sin_pin" else "Crear PIN")
        self.pin_quitar.setEnabled(e != "sin_pin")
        hay = os.path.isfile(os.path.join(plataforma.carpeta_config("katlock"), "rostro.json"))
        self.rostro_estado.setText("✔ Cara registrada" if hay else "Sin cara registrada")

    def _abrir_rostro(self):
        import shutil
        import sys
        if shutil.which("kat-rostro"):
            ok = QProcess.startDetached("kat-rostro", [])
        else:                                     # vista previa en Windows: desde el proyecto
            ok = QProcess.startDetached(sys.executable, ["-m", "katrostro.app"])
        ok = ok[0] if isinstance(ok, tuple) else ok
        self.resultado.mostrar(res.hecho("Abriendo Kat Rostro…") if ok
                               else res.no_disponible("Kat Rostro no está instalado"))
        QTimer.singleShot(4000, self.cargar)

    def _crear_pin(self):
        nuevo, ok = QInputDialog.getText(self, "PIN de desbloqueo", "Escribe tu PIN (%d a %d números):"
                                         % (pin.LARGO_MIN, pin.LARGO_MAX), QLineEdit.Password)
        if not ok:
            return
        try:
            pin.validar(nuevo)
        except pin.ErrorPin as e:
            self.resultado.mostrar(res.fallo(str(e)))
            return
        otra, ok = QInputDialog.getText(self, "PIN de desbloqueo", "Escríbelo otra vez:", QLineEdit.Password)
        if not ok:
            return
        if otra != nuevo:
            self.resultado.mostrar(res.fallo("Los dos PIN no coinciden"))
            return
        pin.crear(nuevo)
        self.resultado.mostrar(res.hecho("PIN guardado (solo se guarda su huella cifrada)"))
        self.cargar()

    def _quitar_pin(self):
        pin.quitar()
        self.resultado.mostrar(res.hecho("PIN quitado: solo se desbloquea con la contraseña"))
        self.cargar()


class SeccionAcerca(Seccion):
    titulo, icono = "Acerca de", "kat-acerca"
    descripcion = "Información de este equipo."

    def construir(self):
        self.form = QFormLayout()
        c = self.tarjeta()
        c.addLayout(self.form)

    def cargar(self):
        while self.form.rowCount():
            self.form.removeRow(0)
        for etiqueta, valor in acerca.leer():
            v = QLabel(valor)
            v.setTextInteractionFlags(Qt.TextSelectableByMouse)
            v.setWordWrap(True)
            self.form.addRow(etiqueta + ":", v)
        self.form.addRow("Kat Settings:", QLabel(VERSION))


SECCIONES = [SeccionPersonalizacion, SeccionCuenta, SeccionPantalla, SeccionSonido, SeccionRed,
             SeccionEnergia, SeccionHora, SeccionSeguridad, SeccionAcerca]


# --- ventana -----------------------------------------------------------------
def _icono(nombre):
    ruta = recursos.icono(nombre)
    return QIcon(ruta) if ruta else QIcon.fromTheme(nombre)


class VentanaSettings(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Kat Settings")
        self.setWindowIcon(_icono("kat-settings"))
        self.resize(1040, 700)
        raiz = QHBoxLayout(self)
        raiz.setContentsMargins(0, 0, 0, 0)
        raiz.setSpacing(0)

        lateral = rol(QFrame(), "lateral")
        lateral.setFixedWidth(240)
        lat = QVBoxLayout(lateral)
        lat.setContentsMargins(14, 20, 14, 14)
        marca = QLabel("Kat Settings")
        marca.setStyleSheet("font-size:15pt;font-weight:700;color:%s;padding-left:6px;" % COLORES["violeta_claro"])
        lat.addWidget(marca)
        self.buscador = QLineEdit()
        self.buscador.setPlaceholderText("Buscar un ajuste…")
        self.buscador.textChanged.connect(self._filtrar)
        lat.addWidget(self.buscador)
        self.lista = QListWidget()
        self.lista.setIconSize(QSize(22, 22))
        self.lista.setSpacing(2)
        lat.addWidget(self.lista, 1)
        # Regla Kat: las apps Kat no abren apps de Plasma; lo que falte se hace en Kat.
        if plataforma.VISTA_PREVIA:
            v = rol(QLabel("Vista previa en %s" % plataforma.nombre()), "aviso")
            v.setWordWrap(True)
            lat.addWidget(v)
        raiz.addWidget(lateral)

        self.pila = QStackedWidget()
        self.secciones = []
        for clase in SECCIONES:
            s = clase()
            self.secciones.append(s)
            self.pila.addWidget(s)
            item = QListWidgetItem(_icono(s.icono), s.titulo)
            item.setSizeHint(QSize(0, 40))
            self.lista.addItem(item)
        raiz.addWidget(self.pila, 1)
        self.lista.currentRowChanged.connect(self.abrir)
        self.lista.setCurrentRow(0)

    def abrir_seccion(self, clave):
        """Abre la sección cuyo título empieza por 'clave' (p. ej. 'seguridad'). Devuelve True si existe."""
        clave = clave.lower()
        for i, s in enumerate(self.secciones):
            if s.titulo.lower().startswith(clave) or clave in s.titulo.lower():
                self.lista.setCurrentRow(i)
                return True
        return False

    def abrir(self, i):
        if i < 0:
            return
        self.pila.setCurrentIndex(i)
        s = self.secciones[i]
        s.resultado.mostrar(None)
        s.cargar()

    def _filtrar(self, texto):
        texto = texto.strip().lower()
        for i, s in enumerate(self.secciones):
            visible = not texto or texto in (s.titulo + " " + s.descripcion).lower()
            self.lista.item(i).setHidden(not visible)
