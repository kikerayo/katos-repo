"""Sonido: volumen y silencio de la salida principal, con wpctl (PipeWire)."""

import re
import subprocess

from katui import acciones, plataforma

SALIDA = "@DEFAULT_AUDIO_SINK@"


def interpretar(texto):
    """'Volume: 0.40 [MUTED]' -> (40, True)."""
    m = re.search(r"Volume:\s*([\d.]+)", texto)
    if not m:
        return None
    return round(float(m.group(1)) * 100), "[MUTED]" in texto


def leer_volumen():
    """(porcentaje, silenciado) o None."""
    if not plataforma.tiene("wpctl"):
        return None
    r = subprocess.run(["wpctl", "get-volume", SALIDA], capture_output=True, text=True, timeout=10)
    return interpretar(r.stdout) if r.returncode == 0 else None


def poner_volumen(porcentaje):
    porcentaje = max(0, min(150, int(porcentaje)))
    if not plataforma.tiene("wpctl"):
        return acciones.no_disponible("El volumen se cambia en Kat OS")
    r = acciones.ejecutar(["wpctl", "set-volume", "-l", "1.5", SALIDA, "%.2f" % (porcentaje / 100)])
    return acciones.hecho("volumen %d %%" % porcentaje) if r.ok else r


def silenciar(si):
    if not plataforma.tiene("wpctl"):
        return acciones.no_disponible("El sonido se controla en Kat OS")
    r = acciones.ejecutar(["wpctl", "set-mute", SALIDA, "1" if si else "0"])
    return acciones.hecho("silenciado" if si else "sonido activado") if r.ok else r
