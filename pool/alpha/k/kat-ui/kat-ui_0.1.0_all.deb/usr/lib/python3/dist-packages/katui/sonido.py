"""Reproducir los sonidos de Kat OS (WAV) sin bloquear la app.

- Kat OS: /usr/share/sounds/katos/<nombre>.wav (paquete kat-artwork), con
  pw-play (PipeWire), paplay o aplay.
- Windows (vista previa): artwork/sonidos/wav/ del proyecto, con winsound.
Si no se puede sonar, no pasa nada (el sonido es un adorno, nunca un requisito).
"""

import os
import shutil
import subprocess

from . import plataforma

_PROYECTO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CARPETAS = ["/usr/share/sounds/katos", os.path.join(_PROYECTO, "artwork", "sonidos", "wav")]


def ruta(nombre):
    for c in CARPETAS:
        r = os.path.join(c, nombre + ".wav")
        if os.path.isfile(r):
            return r
    return None


def reproducir(nombre):
    """Suena el sonido 'nombre' (p. ej. 'kat-aceptar'). Devuelve True si se pudo lanzar."""
    archivo = ruta(nombre)
    if archivo is None:
        return False
    try:
        if plataforma.ES_WINDOWS:
            import winsound
            winsound.PlaySound(archivo, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            return True
        for programa in ("pw-play", "paplay", "aplay"):
            if shutil.which(programa):
                subprocess.Popen([programa, archivo], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
    except Exception:
        return False
    return False
