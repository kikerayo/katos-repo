"""Dibujos de vista previa de los estilos de escritorio (para Bienvenida y Settings).

Se dibujan con QPainter: una pantalla en miniatura con sus barras, dock e
iconos, en los colores Kat. No son capturas inventadas: representan lo que
crea el guion de cada estilo (katui/estilos.py).
"""

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QLinearGradient, QPainter
from PySide6.QtWidgets import QSizePolicy, QWidget

FONDO_A, FONDO_B = QColor("#2a1846"), QColor("#100d19")
BARRA = QColor(27, 21, 40, 235)
ICONOS = [QColor("#8b5cf6"), QColor("#f97316"), QColor("#3b82f6"), QColor("#22c55e")]
CLARO = QColor("#e8dfff")


class VistaEstilo(QWidget):
    def __init__(self, clave):
        super().__init__()
        self.clave = clave
        self.setMinimumSize(160, 150)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def heightForWidth(self, w):
        return int(w * 9 / 16)

    def _iconos(self, p, x, y, tam, vertical=False, n=4, paso=None):
        paso = paso or tam * 1.35
        for i in range(n):
            p.setBrush(ICONOS[i % len(ICONOS)])
            dx, dy = (0, i * paso) if vertical else (i * paso, 0)
            p.drawRoundedRect(QRectF(x + dx, y + dy, tam, tam), tam * 0.25, tam * 0.25)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        r = QRectF(1, 1, w - 2, h - 2)
        g = QLinearGradient(0, 0, w, h)
        g.setColorAt(0, FONDO_A)
        g.setColorAt(1, FONDO_B)
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawRoundedRect(r, 8, 8)
        b = h * 0.11          # alto de barra
        t = b * 0.62          # tamaño de icono
        p.setBrush(BARRA)
        if self.clave == "windows":
            p.drawRect(QRectF(1, h - b - 1, w - 2, b))
            p.setBrush(QColor("#a78bfa"))
            p.drawEllipse(QRectF(b * 0.25, h - b * 0.85 - 1, t, t))
            self._iconos(p, b * 1.4, h - b * 0.82 - 1, t)
            p.setBrush(CLARO)
            p.drawRoundedRect(QRectF(w - b * 2.4, h - b * 0.7 - 1, b * 1.6, b * 0.4), 2, 2)
        elif self.clave == "mac":
            barra = b * 0.6
            p.drawRect(QRectF(1, 1, w - 2, barra))
            p.setBrush(CLARO)
            p.drawEllipse(QRectF(barra * 0.3, barra * 0.2, barra * 0.6, barra * 0.6))
            p.drawRoundedRect(QRectF(barra * 1.3, barra * 0.3, w * 0.18, barra * 0.4), 2, 2)
            p.drawRoundedRect(QRectF(w - w * 0.13, barra * 0.3, w * 0.1, barra * 0.4), 2, 2)
            dock_w, dock_h = t * 1.35 * 4 + t * 0.6, b * 1.15
            p.setBrush(BARRA)
            p.drawRoundedRect(QRectF((w - dock_w) / 2, h - dock_h - h * 0.05, dock_w, dock_h), 8, 8)
            self._iconos(p, (w - dock_w) / 2 + t * 0.4, h - dock_h - h * 0.05 + (dock_h - t) / 2, t)
        else:  # linux
            barra = b * 0.6
            p.drawRect(QRectF(1, 1, w - 2, barra))
            p.setBrush(CLARO)
            p.drawEllipse(QRectF(barra * 0.3, barra * 0.2, barra * 0.6, barra * 0.6))
            p.drawRoundedRect(QRectF(w / 2 - w * 0.06, barra * 0.3, w * 0.12, barra * 0.4), 2, 2)
            p.drawRoundedRect(QRectF(w - w * 0.1, barra * 0.3, w * 0.07, barra * 0.4), 2, 2)
            dock = b * 1.05
            p.setBrush(BARRA)
            p.drawRect(QRectF(1, barra + 1, dock, h - barra - 2))
            self._iconos(p, (dock - t) / 2 + 1, barra + t * 0.6, t, vertical=True)
        p.end()
