"""Música de fondo para las apps Kat (p. ej. Kat Bienvenida), en bucle y sin bloquear.

- Kat OS: /usr/share/katos/musica/<nombre>.mp3 (kat-artwork), con pw-play
  (PipeWire lee MP3 con libsndfile) o ffplay; se repite al terminar.
- Windows (vista previa): artwork/musica/ del proyecto, con el reproductor
  MCI de Windows (winmm), que ya viene en el sistema.
Si no se puede sonar, no pasa nada: la música es un adorno.
"""

import os
import shutil
import subprocess
import threading

from . import plataforma

_PROYECTO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CARPETAS = ["/usr/share/katos/musica", os.path.join(_PROYECTO, "artwork", "musica")]


def ruta(nombre):
    for c in CARPETAS:
        r = os.path.join(c, nombre + ".mp3")
        if os.path.isfile(r):
            return r
    return None


class Musica:
    """Musica("kat-bienvenida").empezar() ... .parar()"""

    def __init__(self, nombre, volumen=0.45):
        self.archivo = ruta(nombre)
        self.volumen = volumen
        self.sonando = False
        self._proceso = None
        self._hilo = None
        self._mci = None

    # --- Windows ------------------------------------------------------------------
    def _orden_mci(self, orden):
        import ctypes
        if self._mci is None:
            self._mci = ctypes.windll.winmm.mciSendStringW
        return self._mci(orden, None, 0, None) == 0

    # --- comunes ---------------------------------------------------------------------
    def empezar(self):
        if self.sonando or not self.archivo:
            return False
        if os.environ.get("QT_QPA_PLATFORM") == "offscreen":     # sin pantalla (pruebas): en silencio
            return False
        try:
            if plataforma.ES_WINDOWS:
                self._orden_mci('open "%s" type mpegvideo alias katmusica' % self.archivo)
                self._orden_mci("setaudio katmusica volume to %d" % int(self.volumen * 1000))
                if not self._orden_mci("play katmusica repeat"):
                    self._orden_mci("close katmusica")
                    return False
                self.sonando = True
                return True
            orden = self._orden_linux()
            if not orden:
                return False
            self.sonando = True
            self._hilo = threading.Thread(target=self._bucle, args=(orden,), daemon=True)
            self._hilo.start()
            return True
        except Exception:
            self.sonando = False
            return False

    def _orden_linux(self):
        if shutil.which("pw-play"):
            return ["pw-play", "--volume", "%.2f" % self.volumen, self.archivo]
        if shutil.which("ffplay"):
            return ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                    "-volume", str(int(self.volumen * 100)), self.archivo]
        return None

    def _bucle(self, orden):
        while self.sonando:
            try:
                self._proceso = subprocess.Popen(orden, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if self._proceso.wait() != 0 and self.sonando:
                    break                       # no se puede reproducir: no insistir
            except OSError:
                break
        self.sonando = False

    def parar(self):
        if not self.sonando:
            return
        self.sonando = False
        try:
            if plataforma.ES_WINDOWS:
                self._orden_mci("stop katmusica")
                self._orden_mci("close katmusica")
            elif self._proceso and self._proceso.poll() is None:
                self._proceso.terminate()
        except Exception:
            pass
