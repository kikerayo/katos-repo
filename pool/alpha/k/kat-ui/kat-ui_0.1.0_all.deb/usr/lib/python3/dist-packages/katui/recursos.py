"""Dónde están los fondos, fotos de perfil e iconos Kat.

- En Kat OS: instalados por el paquete kat-artwork en /usr/share.
- En Windows o en desarrollo: en artwork/exportado/ del proyecto
  (lo crea artwork/exportar.sh), o donde diga la variable KAT_ARTE.
"""

import glob
import json
import os

_PROYECTO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _arte_desarrollo():
    return os.environ.get("KAT_ARTE") or os.path.join(_PROYECTO, "artwork", "exportado")


class Fondo:
    def __init__(self, id_, nombre, imagen, miniatura):
        self.id, self.nombre, self.imagen, self.miniatura = id_, nombre, imagen, miniatura

    def __repr__(self):
        return "Fondo(%s)" % self.id


def fondos():
    """Fondos Kat disponibles, el predeterminado (Nebulosa) primero."""
    lista = []
    # Kat OS: paquetes de fondo de Plasma /usr/share/wallpapers/Kat*/
    for carpeta in sorted(glob.glob("/usr/share/wallpapers/Kat*")):
        imgs = sorted(glob.glob(os.path.join(carpeta, "contents", "images", "*.png")))
        if not imgs:
            continue
        nombre = os.path.basename(carpeta)
        try:
            with open(os.path.join(carpeta, "metadata.json"), encoding="utf-8") as f:
                nombre = json.load(f)["KPlugin"]["Name"]
        except (OSError, KeyError, ValueError):
            pass
        grande = next((i for i in imgs if "1920x1080" in i), imgs[0])
        mini = os.path.join(carpeta, "contents", "screenshot.png")
        lista.append(Fondo(os.path.basename(carpeta), nombre, grande, mini if os.path.exists(mini) else grande))
    if not lista:
        base = os.path.join(_arte_desarrollo(), "fondos")
        try:
            with open(os.path.join(base, "titulos.json"), encoding="utf-8") as f:
                titulos = json.load(f)
        except (OSError, ValueError):
            titulos = {}
        for img in sorted(glob.glob(os.path.join(base, "*-1920x1080.png"))):
            id_ = os.path.basename(img).replace("-1920x1080.png", "")
            mini = img.replace("-1920x1080.png", "-mini.png")
            lista.append(Fondo(id_, titulos.get(id_, _titulo(id_)), img, mini if os.path.exists(mini) else img))
    lista.sort(key=lambda f: (0 if "nebulosa" in f.id.lower() else 1, f.nombre))
    return lista


def avatares():
    """Rutas a las fotos de perfil Kat (PNG)."""
    rutas = sorted(glob.glob("/usr/share/plasma/avatars/kat-*.png"))
    if not rutas:
        rutas = sorted(glob.glob(os.path.join(_arte_desarrollo(), "avatares", "kat-*.png")))
    # El clásico violeta primero: es el predeterminado.
    rutas.sort(key=lambda r: (0 if os.path.basename(r) == "kat-violeta.png" else 1, r))
    return rutas


def icono(nombre):
    """Ruta al icono Kat (SVG) o None."""
    for ruta in ("/usr/share/icons/hicolor/scalable/apps/%s.svg" % nombre,
                 os.path.join(_PROYECTO, "artwork", "iconos", "svg", "%s.svg" % nombre)):
        if os.path.exists(ruta):
            return ruta
    return None


def _titulo(id_):
    return " ".join(p.capitalize() for p in id_.split("-"))
