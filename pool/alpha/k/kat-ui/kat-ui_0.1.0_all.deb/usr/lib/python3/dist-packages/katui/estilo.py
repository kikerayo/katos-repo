"""Colores y hoja de estilo Kat para las apps en PySide6.

En Kat OS la app ya hereda los colores KatOS del sistema; esta hoja añade
lo propio de Kat (botón principal violeta, tarjetas, títulos) y hace que en
Windows se vea igual que en Kat OS.
"""

COLORES = {
    "fondo": "#100d19",
    "panel": "#1b1528",
    "tarjeta": "#251b37",
    "borde": "#3a2d55",
    "texto": "#e8dfff",
    "texto_suave": "#a094be",
    "violeta": "#8b5cf6",
    "violeta_claro": "#cba4ff",
    "ok": "#22c55e",
    "aviso": "#f59e0b",
    "error": "#ef4444",
}

HOJA = """
QWidget { background: %(fondo)s; color: %(texto)s; font-size: 10.5pt; }
QLabel { background: transparent; }
QLabel[rol="titulo"] { font-size: 20pt; font-weight: 600; }
QLabel[rol="subtitulo"] { color: %(texto_suave)s; font-size: 11pt; }
QLabel[rol="aviso"] { color: %(aviso)s; }
QLabel[rol="ok"] { color: %(ok)s; }
QLabel[rol="error"] { color: %(error)s; }
QFrame[rol="tarjeta"] { background: %(tarjeta)s; border: 1px solid %(borde)s; border-radius: 12px; }
QFrame[rol="lateral"] { background: %(panel)s; }
QPushButton { background: %(tarjeta)s; border: 1px solid %(borde)s; border-radius: 8px; padding: 8px 18px; }
QPushButton:hover { border-color: %(violeta)s; }
QPushButton:disabled { color: %(texto_suave)s; }
QPushButton[rol="principal"] { background: %(violeta)s; border: none; color: white; font-weight: 600; }
QPushButton[rol="principal"]:hover { background: #7c4ef0; }
QLineEdit { background: %(tarjeta)s; border: 1px solid %(borde)s; border-radius: 8px; padding: 8px; }
QLineEdit:focus { border-color: %(violeta)s; }
QCheckBox, QRadioButton { spacing: 8px; background: transparent; }
QListWidget { background: transparent; border: none; }
QListWidget::item { border-radius: 10px; padding: 4px; }
QListWidget::item:selected { background: %(borde)s; border: 2px solid %(violeta)s; }
QProgressBar { background: %(tarjeta)s; border: none; border-radius: 6px; height: 12px; text-align: center; }
QProgressBar::chunk { background: %(violeta)s; border-radius: 6px; }
QScrollArea { border: none; }
""" % COLORES


def aplicar(app):
    app.setStyleSheet(HOJA)


def rol(widget, nombre):
    """Marca un widget con un rol de la hoja de estilo (titulo, principal, tarjeta...)."""
    widget.setProperty("rol", nombre)
    return widget
