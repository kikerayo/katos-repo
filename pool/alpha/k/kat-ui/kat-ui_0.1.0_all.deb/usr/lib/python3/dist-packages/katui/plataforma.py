"""¿Dónde se está ejecutando la app?

En Windows las apps Kat funcionan en "vista previa": se ve y se usa toda la
interfaz, pero lo que solo existe en Kat OS (firewall, cuentas de usuario,
temas de Plasma...) se marca como "solo funciona en Kat OS" en lugar de
fingir que se aplicó.
"""

import os
import platform
import shutil
import sys

ES_WINDOWS = sys.platform.startswith("win")
ES_LINUX = sys.platform.startswith("linux")


def _os_release():
    datos = {}
    for ruta in ("/etc/os-release", "/usr/lib/os-release"):
        try:
            with open(ruta, encoding="utf-8") as f:
                for linea in f:
                    k, igual, v = linea.strip().partition("=")
                    if igual:
                        datos[k] = v.strip('"')
            break
        except OSError:
            continue
    return datos


ES_KATOS = ES_LINUX and _os_release().get("ID") == "katos"
VISTA_PREVIA = not ES_KATOS


def nombre():
    if ES_KATOS:
        return "Kat OS"
    if ES_WINDOWS:
        return "Windows (vista previa)"
    return "%s (vista previa)" % (_os_release().get("PRETTY_NAME") or platform.system())


def tiene(programa):
    """¿Existe este programa en el sistema? (p. ej. 'plasma-apply-colorscheme')."""
    return shutil.which(programa) is not None


def carpeta_config(app):
    """Configuración de la app: ~/.config/katos/<app> o %APPDATA%\\KatOS\\<app>."""
    if ES_WINDOWS:
        base = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "KatOS")
    else:
        base = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config"),
                            "katos")
    ruta = os.path.join(base, app)
    os.makedirs(ruta, exist_ok=True)
    return ruta
