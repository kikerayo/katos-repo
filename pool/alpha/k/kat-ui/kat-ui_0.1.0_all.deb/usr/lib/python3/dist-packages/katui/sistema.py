"""Ajustes del sistema compartidos por varias apps Kat (Bienvenida, Settings, Security).

Leer el estado no necesita permisos. Cambiarlo pasa por
'pkexec /usr/lib/katos/kat-ayudante', que pide la contraseña.
"""

import os
import re

from . import acciones, plataforma

AYUDANTE = "/usr/lib/katos/kat-ayudante"
UFW_CONF = "/etc/ufw/ufw.conf"
AUTO_UPGRADES = "/etc/apt/apt.conf.d/20auto-upgrades"


def _leer(ruta):
    try:
        with open(ruta, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def firewall_activo(texto=None):
    """True/False según /etc/ufw/ufw.conf; None si no se sabe (p. ej. en Windows)."""
    texto = _leer(UFW_CONF) if texto is None else texto
    if texto is None:
        return None
    m = re.search(r"^\s*ENABLED\s*=\s*(\w+)", texto, re.M)
    return bool(m and m.group(1).lower() == "yes")


def actualizaciones_automaticas(texto=None):
    texto = _leer(AUTO_UPGRADES) if texto is None else texto
    if texto is None:
        return None
    m = re.search(r'Unattended-Upgrade\s+"(\d+)"', texto)
    return bool(m and m.group(1) != "0")


def _ayudante(que, activar):
    if not plataforma.ES_LINUX or not os.path.exists(AYUDANTE):
        return acciones.no_disponible("Solo se puede cambiar en Kat OS")
    accion = "activar" if activar else "desactivar"
    r = acciones.ejecutar(["pkexec", AYUDANTE, que, accion], tiempo=300)
    texto = r.mensaje.lower()
    if r.estado == acciones.FALLO and ("dismissed" in texto or "not authorized" in texto):
        return acciones.fallo("No se dio la contraseña de administrador")
    return r


def cambiar_firewall(activar):
    actual = firewall_activo()
    if actual is None:
        return acciones.no_disponible("El cortafuegos solo se controla en Kat OS")
    if actual == activar:
        return acciones.hecho("ya estaba %s" % ("activado" if activar else "desactivado"))
    r = _ayudante("firewall", activar)
    return acciones.hecho("cortafuegos %s" % ("activado" if activar else "desactivado")) if r.ok else r


def cambiar_actualizaciones(activar):
    actual = actualizaciones_automaticas()
    if actual is None and not plataforma.ES_LINUX:
        return acciones.no_disponible("Las actualizaciones solo se controlan en Kat OS")
    if actual == activar:
        return acciones.hecho("ya estaban %s" % ("activadas" if activar else "desactivadas"))
    r = _ayudante("actualizaciones", activar)
    return acciones.hecho("actualizaciones automáticas %s" % ("activadas" if activar else "desactivadas")) if r.ok else r


def en_modo_live():
    """Kat OS arrancado desde la ISO sin instalar: lo que se instala va a la RAM."""
    if os.path.isdir("/run/live/medium"):
        return True
    cmd = _leer("/proc/cmdline") or ""
    return "boot=live" in cmd
