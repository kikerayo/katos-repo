"""Tu cuenta: nombre y foto de perfil, vía AccountsService (D-Bus del sistema).

Lo usan Kat Bienvenida y Kat Settings.
"""

import getpass
import os
import shutil

from . import acciones, plataforma


def nombre_actual():
    if plataforma.ES_LINUX:
        import pwd
        entrada = pwd.getpwuid(os.getuid())
        completo = entrada.pw_gecos.split(",")[0].strip()
        return completo or entrada.pw_name
    return os.environ.get("USERNAME") or getpass.getuser()


def usuario():
    return getpass.getuser()


def foto_actual():
    """Ruta a la foto de perfil actual, o None."""
    if not plataforma.ES_LINUX:
        return None
    for ruta in ("/var/lib/AccountsService/icons/%s" % usuario(),
                 os.path.join(os.path.expanduser("~"), ".face.icon"),
                 os.path.join(os.path.expanduser("~"), ".face")):
        if os.path.isfile(ruta):
            return ruta
    return None


def _llamar_usuario(metodo, valor):
    from gi.repository import Gio, GLib
    con = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
    ruta = con.call_sync("org.freedesktop.Accounts", "/org/freedesktop/Accounts",
                         "org.freedesktop.Accounts", "FindUserById",
                         GLib.Variant("(x)", (os.getuid(),)), None,
                         Gio.DBusCallFlags.NONE, 10000, None).unpack()[0]
    con.call_sync("org.freedesktop.Accounts", ruta, "org.freedesktop.Accounts.User", metodo,
                  GLib.Variant("(s)", (valor,)), None, Gio.DBusCallFlags.ALLOW_INTERACTIVE_AUTHORIZATION,
                  60000, None)


def cambiar_nombre(nombre):
    nombre = (nombre or "").strip()
    if not nombre:
        return acciones.fallo("El nombre está vacío")
    if not plataforma.ES_LINUX:
        return acciones.no_disponible("Tu nombre se cambia en Kat OS")
    if nombre == nombre_actual():
        return acciones.hecho("sin cambios")
    try:
        _llamar_usuario("SetRealName", nombre)
    except Exception as e:  # GLib.Error u otros
        return acciones.fallo("No se pudo cambiar el nombre: %s" % getattr(e, "message", e))
    return acciones.hecho("nombre: %s" % nombre)


def cambiar_foto(ruta):
    if not ruta:
        return acciones.hecho("sin cambios")
    if not os.path.isfile(ruta):
        return acciones.fallo("No existe la imagen %s" % ruta)
    if not plataforma.ES_LINUX:
        return acciones.no_disponible("La foto de perfil se cambia en Kat OS")
    try:
        _llamar_usuario("SetIconFile", os.path.abspath(ruta))
    except Exception as e:
        return acciones.fallo("No se pudo cambiar la foto: %s" % getattr(e, "message", e))
    try:  # Plasma también lee ~/.face.icon
        shutil.copyfile(ruta, os.path.join(os.path.expanduser("~"), ".face.icon"))
    except OSError:
        pass
    return acciones.hecho("foto: %s" % os.path.basename(ruta))
