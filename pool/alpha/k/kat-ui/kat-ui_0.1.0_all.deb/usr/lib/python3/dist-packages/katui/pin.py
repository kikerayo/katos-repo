"""KatLock: PIN de desbloqueo.

- El PIN nunca se guarda: se guarda su huella con scrypt (sal aleatoria),
  en ~/.config/katos/pin.json con permisos solo para el usuario.
- Tras MAX_FALLOS intentos fallidos el PIN se bloquea un tiempo que crece
  con cada fallo; mientras tanto solo sirve la contraseña.
- La contraseña SIEMPRE sigue funcionando: el PIN es un atajo, no la única llave.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import time

from . import plataforma

LARGO_MIN, LARGO_MAX = 4, 8
MAX_FALLOS = 5
ESPERA_BASE = 60             # segundos de bloqueo tras el 5.º fallo (se duplica con cada fallo más)
_SCRYPT = {"n": 2 ** 14, "r": 8, "p": 1, "dklen": 32}


class ErrorPin(ValueError):
    pass


def archivo(carpeta_config=None):
    base = carpeta_config or plataforma.carpeta_config("katlock")
    return os.path.join(base, "pin.json")


def _huella(pin, sal):
    return hashlib.scrypt(pin.encode("utf-8"), salt=sal, **_SCRYPT)


def validar(pin):
    if not re.fullmatch(r"\d{%d,%d}" % (LARGO_MIN, LARGO_MAX), pin or ""):
        raise ErrorPin("El PIN debe tener de %d a %d números" % (LARGO_MIN, LARGO_MAX))
    if len(set(pin)) == 1 or pin in "0123456789" or pin in "9876543210":
        raise ErrorPin("Ese PIN es muy fácil de adivinar (números iguales o seguidos)")


def _leer(ruta):
    try:
        with open(ruta, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _escribir(ruta, datos):
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    temporal = ruta + ".tmp"
    with open(temporal, "w", encoding="utf-8") as f:
        json.dump(datos, f)
    try:
        os.chmod(temporal, 0o600)
    except OSError:
        pass
    os.replace(temporal, ruta)


def crear(pin, ruta=None):
    validar(pin)
    sal = secrets.token_bytes(16)
    _escribir(ruta or archivo(), {"version": 1, "sal": base64.b64encode(sal).decode(),
                                  "huella": base64.b64encode(_huella(pin, sal)).decode(),
                                  "fallos": 0, "bloqueado_hasta": 0})


def tiene(ruta=None):
    d = _leer(ruta or archivo())
    return bool(d and d.get("huella"))


def quitar(ruta=None):
    try:
        os.remove(ruta or archivo())
    except FileNotFoundError:
        pass


def estado(ruta=None, ahora=None):
    """'sin_pin', 'activo' o ('bloqueado', segundos_restantes)."""
    d = _leer(ruta or archivo())
    if not d or not d.get("huella"):
        return "sin_pin"
    falta = d.get("bloqueado_hasta", 0) - (ahora or time.time())
    return ("bloqueado", int(falta) + 1) if falta > 0 else "activo"


def verificar(pin, ruta=None, ahora=None):
    """True solo si hay PIN, no está bloqueado y coincide. Cuenta los fallos."""
    ruta = ruta or archivo()
    ahora = ahora or time.time()
    d = _leer(ruta)
    if not d or not d.get("huella"):
        return False
    if d.get("bloqueado_hasta", 0) > ahora:
        return False
    try:
        sal = base64.b64decode(d["sal"])
        correcto = hmac.compare_digest(_huella(pin or "", sal), base64.b64decode(d["huella"]))
    except (KeyError, ValueError):
        return False
    if correcto:
        d["fallos"], d["bloqueado_hasta"] = 0, 0
    else:
        d["fallos"] = d.get("fallos", 0) + 1
        if d["fallos"] >= MAX_FALLOS:
            d["bloqueado_hasta"] = ahora + ESPERA_BASE * 2 ** (d["fallos"] - MAX_FALLOS)
    _escribir(ruta, d)
    return correcto
