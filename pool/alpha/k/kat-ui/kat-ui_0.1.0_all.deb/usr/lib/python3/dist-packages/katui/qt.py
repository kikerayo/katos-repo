"""Piezas de interfaz (PySide6) que reutilizan todas las apps Kat."""

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QLabel

from . import acciones
from .estilo import COLORES

SIMBOLOS = {acciones.HECHO: ("✔", COLORES["ok"]), acciones.FALLO: ("✖", COLORES["error"]),
            acciones.NO_DISPONIBLE: ("ⓘ", COLORES["aviso"])}

_vivas = set()   # tareas en marcha: evita que Python las borre antes de terminar


class Tarea(QThread):
    """Ejecuta una función en segundo plano y entrega su resultado a 'al_terminar'."""

    listo = Signal(object)

    def __init__(self, funcion, *args, al_terminar=None):
        super().__init__()
        self.funcion, self.args = funcion, args
        if al_terminar:
            self.listo.connect(al_terminar)
        self.finished.connect(lambda: _vivas.discard(self))

    def run(self):
        try:
            r = self.funcion(*self.args)
        except Exception as e:  # el error se muestra, no se esconde
            r = acciones.fallo("error inesperado: %s" % e)
        self.listo.emit(r)


def en_segundo_plano(funcion, *args, al_terminar=None):
    t = Tarea(funcion, *args, al_terminar=al_terminar)
    _vivas.add(t)
    t.start()
    return t


class EtiquetaResultado(QLabel):
    """Muestra un Resultado: ✔ hecho / ✖ falló / ⓘ no disponible aquí."""

    def __init__(self):
        super().__init__("")
        self.setWordWrap(True)

    def mostrar(self, r):
        if r is None:
            self.setText("")
            return
        simbolo, color = SIMBOLOS[r.estado]
        self.setStyleSheet("color:%s;" % color)
        self.setText("%s  %s" % (simbolo, r.mensaje or {"hecho": "Hecho"}.get(r.estado, "")))

    def trabajando(self, texto="Aplicando…"):
        self.setStyleSheet("color:%s;" % COLORES["texto_suave"])
        self.setText(texto)
