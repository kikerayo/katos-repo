"""Resultado común de cualquier acción de una app Kat.

Tres casos, y la interfaz muestra cada uno de forma distinta:
  HECHO          se aplicó de verdad
  FALLO          se intentó y falló (se muestra el motivo)
  NO_DISPONIBLE  aquí no se puede (p. ej. en Windows); nada se fingió
"""

import subprocess

HECHO = "hecho"
FALLO = "fallo"
NO_DISPONIBLE = "no_disponible"


class Resultado:
    def __init__(self, estado, mensaje=""):
        self.estado = estado
        self.mensaje = mensaje

    @property
    def ok(self):
        return self.estado == HECHO

    def __repr__(self):
        return "Resultado(%s, %r)" % (self.estado, self.mensaje)


def hecho(mensaje=""):
    return Resultado(HECHO, mensaje)


def fallo(mensaje):
    return Resultado(FALLO, mensaje)


def no_disponible(mensaje="Solo funciona en Kat OS"):
    return Resultado(NO_DISPONIBLE, mensaje)


def ejecutar(cmd, exito="", tiempo=120, entrada=None):
    """Ejecuta un comando y lo convierte en Resultado (con el error real si falla)."""
    try:
        # utf-8 explícito: en Windows el predeterminado es cp1252 y rompe los acentos.
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace",
                           timeout=tiempo, input=entrada)
    except FileNotFoundError:
        return no_disponible("Falta el programa '%s'" % cmd[0])
    except subprocess.TimeoutExpired:
        return fallo("'%s' tardó demasiado" % cmd[0])
    if r.returncode == 0:
        return hecho(exito)
    detalle = (r.stderr or r.stdout).strip().splitlines()
    return fallo(detalle[-1] if detalle else "'%s' terminó con código %d" % (cmd[0], r.returncode))
