"""Apariencia del escritorio Kat (Plasma): tema oscuro/claro, color de acento y fondo.

Lo usan Kat Bienvenida y Kat Settings.
"""

import os
import re

from . import acciones, plataforma

ESQUEMAS = {"oscuro": "KatOS", "claro": "KatOSClaro"}
ACENTOS = {
    "violeta": "#8b5cf6",
    "rosa": "#ec4899",
    "azul": "#3b82f6",
    "verde": "#22c55e",
    "naranja": "#f97316",
}


def _kdeglobals():
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    try:
        with open(os.path.join(base, "kdeglobals"), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def modo_actual(texto=None):
    """'oscuro' / 'claro' según el esquema de color del usuario; None si no se sabe."""
    texto = _kdeglobals() if texto is None else texto
    m = re.search(r"^ColorScheme=(\S+)", texto, re.M)
    if not m:
        return "oscuro" if plataforma.ES_KATOS else None
    return "claro" if m.group(1) == ESQUEMAS["claro"] else "oscuro"


def acento_actual(texto=None):
    """Nombre del acento Kat que coincide con AccentColor (r,g,b) del usuario, o None."""
    texto = _kdeglobals() if texto is None else texto
    m = re.search(r"^AccentColor=(\d+),(\d+),(\d+)", texto, re.M)
    if not m:
        return "violeta" if plataforma.ES_KATOS else None
    rgb = "#%02x%02x%02x" % tuple(int(x) for x in m.groups())
    for nombre, color in ACENTOS.items():
        if color == rgb:
            return nombre
    return None


def cambiar_apariencia(modo, acento):
    if modo not in ESQUEMAS or acento not in ACENTOS:
        return acciones.fallo("Opción de apariencia desconocida")
    if not plataforma.tiene("plasma-apply-colorscheme"):
        return acciones.no_disponible("Los temas se aplican en Kat OS")
    r = acciones.ejecutar(["plasma-apply-colorscheme", ESQUEMAS[modo], "--accent-color", ACENTOS[acento]])
    return acciones.hecho("tema %s, color %s" % (modo, acento)) if r.ok else r


def cambiar_fondo(imagen):
    if not imagen:
        return acciones.hecho("sin cambios")
    if not plataforma.tiene("plasma-apply-wallpaperimage"):
        return acciones.no_disponible("El fondo se cambia en Kat OS")
    r = acciones.ejecutar(["plasma-apply-wallpaperimage", imagen])
    if not r.ok:
        return r
    # Mismo fondo en la pantalla de bloqueo.
    if plataforma.tiene("kwriteconfig6"):
        acciones.ejecutar(["kwriteconfig6", "--file", "kscreenlockerrc", "--group", "Greeter",
                           "--group", "Wallpaper", "--group", "org.kde.image", "--group", "General",
                           "--key", "Image", "file://" + imagen])
    if "/usr/share/wallpapers/" in imagen:
        return acciones.hecho("fondo: %s" % imagen.split("/usr/share/wallpapers/")[1].split("/")[0])
    return acciones.hecho("fondo aplicado")
