"""Estilos de escritorio de Kat OS: Windows, Mac o Linux común.

Cada estilo es un guion de Plasma (JavaScript de "Plasma scripting") que
quita los paneles y crea los nuevos. Se aplica en vivo pidiéndoselo a
plasmashell por D-Bus (org.kde.PlasmaShell.evaluateScript): no hace falta
reiniciar la sesión. Lo usan Kat Bienvenida y Kat Settings.
"""

import json

from . import acciones

LANZADORES = [
    "applications:org.katos.Files.desktop",
    "applications:firefox-esr.desktop",
    "applications:org.katos.Store.desktop",
    "applications:org.katos.Settings.desktop",
]
ICONO_MENU = "/usr/share/icons/hicolor/scalable/apps/katos.svg"

_COMUN = """
var lanzadores = %s;
panels().forEach(function (p) { p.remove(); });
function menuKat(panel) {
    var m = panel.addWidget("org.kde.plasma.kickoff");
    m.currentConfigGroup = ["General"];
    m.writeConfig("icon", "%s");
    return m;
}
function tareas(panel, soloIconos) {
    var t = panel.addWidget("org.kde.plasma.icontasks");
    t.currentConfigGroup = ["General"];
    t.writeConfig("launchers", lanzadores);
    if (soloIconos) { t.writeConfig("showOnlyCurrentDesktop", false); }
    return t;
}
function intentar(f) { try { f(); } catch (e) {} }
""" % (json.dumps(LANZADORES), ICONO_MENU)

ESTILOS = {
    "windows": {
        "nombre": "Windows",
        "descripcion": "Barra abajo con el menú a la izquierda, tus apps y el reloj a la derecha.",
        "js": _COMUN + """
var p = new Panel;
p.location = "bottom";
p.height = 2 * Math.floor(gridUnit * 2.6 / 2);
menuKat(p);
tareas(p, false);
p.addWidget("org.kde.plasma.marginsseparator");
p.addWidget("org.kde.plasma.systemtray");
var reloj = p.addWidget("org.kde.plasma.digitalclock");
reloj.currentConfigGroup = ["Appearance"];
reloj.writeConfig("dateDisplayFormat", "BelowTime");
p.addWidget("org.kde.plasma.showdesktop");
""",
    },
    "mac": {
        "nombre": "Mac",
        "descripcion": "Barra fina arriba con el menú de la app y el reloj; dock flotante abajo en el centro.",
        "js": _COMUN + """
var arriba = new Panel;
arriba.location = "top";
arriba.height = 2 * Math.floor(gridUnit * 1.6 / 2);
menuKat(arriba);
arriba.addWidget("org.kde.plasma.appmenu");
arriba.addWidget("org.kde.plasma.panelspacer");
arriba.addWidget("org.kde.plasma.systemtray");
arriba.addWidget("org.kde.plasma.digitalclock");
var dock = new Panel;
dock.location = "bottom";
dock.height = 2 * Math.floor(gridUnit * 3.2 / 2);
intentar(function () { dock.alignment = "center"; });
intentar(function () { dock.lengthMode = "fit"; });
intentar(function () { dock.floating = true; });
tareas(dock, true);
""",
    },
    "linux": {
        "nombre": "Linux común",
        "descripcion": "Barra arriba con el reloj al centro y un dock vertical a la izquierda (como GNOME/Ubuntu).",
        "js": _COMUN + """
var arriba = new Panel;
arriba.location = "top";
arriba.height = 2 * Math.floor(gridUnit * 1.6 / 2);
menuKat(arriba);
arriba.addWidget("org.kde.plasma.panelspacer");
arriba.addWidget("org.kde.plasma.digitalclock");
arriba.addWidget("org.kde.plasma.panelspacer");
arriba.addWidget("org.kde.plasma.systemtray");
var dock = new Panel;
dock.location = "left";
dock.height = 2 * Math.floor(gridUnit * 3.0 / 2);
tareas(dock, true);
""",
    },
}


def _evaluar(js):
    """Pide a plasmashell que ejecute el guion. Lanza RuntimeError si no hay Plasma."""
    try:
        from gi.repository import Gio, GLib
    except ImportError as e:
        raise RuntimeError("sin D-Bus") from e
    con = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    con.call_sync("org.kde.plasmashell", "/PlasmaShell", "org.kde.PlasmaShell", "evaluateScript",
                  GLib.Variant("(s)", (js,)), None, Gio.DBusCallFlags.NONE, 30000, None)


def aplicar(clave, evaluar=None):
    if clave not in ESTILOS:
        return acciones.fallo("Estilo de escritorio desconocido")
    try:
        (evaluar or _evaluar)(ESTILOS[clave]["js"])
    except RuntimeError:
        return acciones.no_disponible("El estilo de escritorio se aplica en Kat OS")
    except Exception as e:  # GLib.Error: plasmashell no está o el guion falló
        mensaje = getattr(e, "message", str(e))
        if "ServiceUnknown" in mensaje or "not provided" in mensaje:
            return acciones.no_disponible("El estilo de escritorio se aplica en Kat OS")
        return acciones.fallo("Plasma no pudo cambiar el escritorio: %s" % mensaje)
    return acciones.hecho("escritorio estilo %s" % ESTILOS[clave]["nombre"])
