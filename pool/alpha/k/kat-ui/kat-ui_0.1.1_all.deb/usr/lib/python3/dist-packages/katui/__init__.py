"""Kat UI: lo que comparten todas las apps Kat.

- plataforma: saber si estamos en Kat OS, en otro Linux o en Windows.
- recursos:   dónde están los fondos, fotos de perfil e iconos Kat.
- estilo:     colores y hoja de estilo Kat para PySide6.
- acciones:   resultado común de una acción (hecha / falló / no disponible aquí).
"""

VERSION = "0.1.1"
