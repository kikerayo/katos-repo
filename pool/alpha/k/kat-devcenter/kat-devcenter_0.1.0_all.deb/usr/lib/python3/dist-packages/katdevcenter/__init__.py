"""Kat Developer Center: herramienta para ver y probar Kat OS por dentro.

Muestra el estado de Kat Core (katd), los eventos de todas las apps Kat,
las apps registradas y permite reiniciar el servicio.
"""

VERSION = "0.1.0"
APP_ID = "org.katos.DevCenter"
