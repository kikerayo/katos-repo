"""Ventana principal de Kat Developer Center (PySide6)."""

from PySide6.QtCore import QProcess, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QIcon
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMainWindow, QPlainTextEdit, QProgressBar, QPushButton, QTableWidget,
    QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from . import VERSION
from .datos import Datos, KatCoreNoDisponible, formato_duracion, formato_gb, formato_hora

INTERVALO_MS = 2000
VIOLETA = "#8b5cf6"
COLOR_NIVEL = {"info": None, "warning": QColor("#f59e0b"), "error": QColor("#ef4444")}
NOMBRE_NIVEL = {"info": "Info", "warning": "Aviso", "error": "Error"}

ESTILO = """
QProgressBar { border: none; border-radius: 5px; background: rgba(255,255,255,0.10);
               height: 10px; text-align: right; }
QProgressBar::chunk { border-radius: 5px; background: %s; }
""" % VIOLETA
ESTADO_OK = "color: #22c55e; font-weight: bold;"
ESTADO_MAL = "color: #ef4444; font-weight: bold;"


def _tabla(columnas):
    t = QTableWidget(0, len(columnas))
    t.setHorizontalHeaderLabels(columnas)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.verticalHeader().setVisible(False)
    t.horizontalHeader().setSectionResizeMode(len(columnas) - 1, QHeaderView.Stretch)
    return t


class PestanaEstado(QWidget):
    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        self.estado = QLabel("Conectando con Kat Core…")
        caja.addWidget(self.estado)

        self.form = QFormLayout()
        self.campos = {}
        for clave, titulo in (("version_katd", "Versión de Kat Core"), ("nombre_completo", "Sistema"),
                              ("kernel", "Kernel"), ("equipo", "Nombre del equipo"),
                              ("cpu", "Procesador"), ("nucleos", "Núcleos"), ("encendido", "Encendido")):
            etiqueta = QLabel("–")
            etiqueta.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.campos[clave] = etiqueta
            self.form.addRow(titulo + ":", etiqueta)
        caja.addLayout(self.form)

        self.barras = {}
        for clave, titulo in (("cpu", "CPU"), ("mem", "Memoria"), ("disco", "Disco del sistema")):
            fila = QHBoxLayout()
            nombre = QLabel(titulo)
            nombre.setMinimumWidth(130)
            barra = QProgressBar()
            barra.setRange(0, 1000)
            barra.setTextVisible(False)
            detalle = QLabel("–")
            detalle.setMinimumWidth(150)
            fila.addWidget(nombre)
            fila.addWidget(barra, 1)
            fila.addWidget(detalle)
            caja.addLayout(fila)
            self.barras[clave] = (barra, detalle)
        caja.addStretch(1)

    def mostrar_error(self, mensaje):
        self.estado.setStyleSheet(ESTADO_MAL)
        self.estado.setText("● Kat Core no responde: " + mensaje)

    def actualizar(self, version, info, stats):
        self.estado.setStyleSheet(ESTADO_OK)
        self.estado.setText("● Kat Core funcionando")
        self.campos["version_katd"].setText(version)
        for clave in ("nombre_completo", "kernel", "equipo", "cpu", "nucleos"):
            self.campos[clave].setText(info.get(clave, "–"))
        self.campos["encendido"].setText(formato_duracion(stats["uptime"]))

        def poner(clave, fraccion, texto):
            barra, detalle = self.barras[clave]
            barra.setValue(int(max(0.0, min(1.0, fraccion)) * 1000))
            detalle.setText(texto)

        poner("cpu", stats["cpu_percent"] / 100, "%.0f %%" % stats["cpu_percent"])
        poner("mem", stats["mem_used"] / max(1, stats["mem_total"]),
              "%s de %s" % (formato_gb(stats["mem_used"]), formato_gb(stats["mem_total"])))
        poner("disco", stats["disk_used"] / max(1, stats["disk_total"]),
              "%s de %s" % (formato_gb(stats["disk_used"]), formato_gb(stats["disk_total"])))


class PestanaEventos(QWidget):
    def __init__(self, datos):
        super().__init__()
        self.datos = datos
        caja = QVBoxLayout(self)

        filtros = QHBoxLayout()
        filtros.addWidget(QLabel("App:"))
        self.filtro_app = QComboBox()
        self.filtro_app.addItem("Todas", "")
        self.filtro_app.currentIndexChanged.connect(self.recargar)
        filtros.addWidget(self.filtro_app, 1)
        filtros.addWidget(QLabel("Nivel:"))
        self.filtro_nivel = QComboBox()
        self.filtro_nivel.addItem("Todos", "")
        for n in ("info", "warning", "error"):
            self.filtro_nivel.addItem(NOMBRE_NIVEL[n], n)
        self.filtro_nivel.currentIndexChanged.connect(self.recargar)
        filtros.addWidget(self.filtro_nivel)
        caja.addLayout(filtros)

        self.tabla = _tabla(["Hora", "App", "Nivel", "Mensaje"])
        caja.addWidget(self.tabla, 1)

        prueba = QHBoxLayout()
        self.texto_prueba = QLineEdit()
        self.texto_prueba.setPlaceholderText("Mensaje de prueba para el registro de Kat Core")
        self.nivel_prueba = QComboBox()
        for n in ("info", "warning", "error"):
            self.nivel_prueba.addItem(NOMBRE_NIVEL[n], n)
        self.boton_enviar = QPushButton("Enviar evento")
        self.boton_enviar.clicked.connect(self.enviar)
        self.texto_prueba.returnPressed.connect(self.enviar)
        prueba.addWidget(self.texto_prueba, 1)
        prueba.addWidget(self.nivel_prueba)
        prueba.addWidget(self.boton_enviar)
        caja.addLayout(prueba)
        self.aviso = QLabel("")
        caja.addWidget(self.aviso)
        self._ultimo_id = None

    def poner_apps(self, ids):
        actual = self.filtro_app.currentData()
        existentes = {self.filtro_app.itemData(i) for i in range(self.filtro_app.count())}
        for app_id in ids:
            if app_id not in existentes:
                self.filtro_app.addItem(app_id, app_id)
        if actual is not None:
            self.filtro_app.setCurrentIndex(max(0, self.filtro_app.findData(actual)))

    def recargar(self):
        try:
            eventos = self.datos.eventos(200, self.filtro_app.currentData() or "")
        except KatCoreNoDisponible as e:
            self.aviso.setText("No se pudieron leer los eventos: " + str(e))
            return
        nivel = self.filtro_nivel.currentData() or ""
        if nivel:
            eventos = [e for e in eventos if e[3] == nivel]
        clave = (eventos[0][0] if eventos else None, len(eventos), nivel, self.filtro_app.currentData())
        if clave == self._ultimo_id:
            return  # nada nuevo: no redibujar (no pierde la selección)
        self._ultimo_id = clave
        self.tabla.setRowCount(len(eventos))
        for fila, (_id, t, app, niv, msg) in enumerate(eventos):
            celdas = [formato_hora(t), app, NOMBRE_NIVEL.get(niv, niv), msg]
            for col, texto in enumerate(celdas):
                item = QTableWidgetItem(texto)
                color = COLOR_NIVEL.get(niv)
                if color is not None:
                    item.setForeground(color)
                self.tabla.setItem(fila, col, item)
        self.tabla.resizeColumnsToContents()
        self.tabla.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)

    def enviar(self):
        texto = self.texto_prueba.text().strip()
        if not texto:
            self.aviso.setText("Escribe un mensaje primero.")
            return
        try:
            nuevo_id = self.datos.enviar_evento(self.nivel_prueba.currentData(), texto)
        except KatCoreNoDisponible as e:
            self.aviso.setText("No se pudo enviar: " + str(e))
            return
        self.aviso.setText("Evento #%d guardado en Kat Core." % nuevo_id)
        self.texto_prueba.clear()
        self.recargar()


class PestanaApps(QWidget):
    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addWidget(QLabel("Apps Kat que se han registrado en Kat Core:"))
        self.tabla = _tabla(["App", "Versión", "Vista por última vez"])
        caja.addWidget(self.tabla, 1)

    def actualizar(self, apps):
        self.tabla.setRowCount(len(apps))
        for fila, (app_id, version, visto) in enumerate(apps):
            for col, texto in enumerate((app_id, version, formato_hora(visto))):
                self.tabla.setItem(fila, col, QTableWidgetItem(texto))
        self.tabla.resizeColumnsToContents()


class PestanaServicio(QWidget):
    """Estado real del servicio systemd de usuario katd.service."""

    def __init__(self):
        super().__init__()
        caja = QVBoxLayout(self)
        caja.addWidget(QLabel("Servicio de usuario katd.service (systemd):"))
        self.salida = QPlainTextEdit()
        self.salida.setReadOnly(True)
        self.salida.setFont(QFont("monospace"))
        caja.addWidget(self.salida, 1)
        botones = QHBoxLayout()
        self.boton_estado = QPushButton("Actualizar estado")
        self.boton_reiniciar = QPushButton("Reiniciar Kat Core")
        self.boton_estado.clicked.connect(self.ver_estado)
        self.boton_reiniciar.clicked.connect(self.reiniciar)
        botones.addWidget(self.boton_estado)
        botones.addWidget(self.boton_reiniciar)
        botones.addStretch(1)
        caja.addLayout(botones)
        self.proceso = None

    def _ejecutar(self, argumentos, despues=None):
        if self.proceso is not None and self.proceso.state() != QProcess.NotRunning:
            return
        p = QProcess(self)
        p.setProcessChannelMode(QProcess.MergedChannels)
        self.proceso = p

        def terminado(codigo, _estado):
            texto = bytes(p.readAll()).decode("utf-8", "replace")
            if despues:
                despues(codigo, texto)
            else:
                self.salida.setPlainText(texto or "(sin salida, código %d)" % codigo)

        def fallo(error):
            if error == QProcess.FailedToStart:
                self.salida.setPlainText("No se pudo ejecutar systemctl: " + p.errorString())

        p.finished.connect(terminado)
        p.errorOccurred.connect(fallo)
        p.start("systemctl", argumentos)

    def detener(self):
        """Al cerrar la ventana: no dejar systemctl huérfano."""
        p, self.proceso = self.proceso, None
        if p is not None and p.state() != QProcess.NotRunning:
            p.finished.disconnect()
            p.errorOccurred.disconnect()
            p.kill()
            p.waitForFinished(1000)

    def ver_estado(self):
        self._ejecutar(["--user", "status", "katd.service", "--no-pager", "-n", "20"])

    def reiniciar(self):
        def listo(codigo, texto):
            if codigo == 0:
                self.salida.setPlainText("Kat Core reiniciado.\n")
                QTimer.singleShot(500, self.ver_estado)
            else:
                self.salida.setPlainText("No se pudo reiniciar (código %d):\n%s" % (codigo, texto))
        self._ejecutar(["--user", "restart", "katd.service"], listo)


class VentanaDevCenter(QMainWindow):
    def __init__(self, datos=None):
        super().__init__()
        self.datos = datos or Datos()
        self.setWindowTitle("Kat Developer Center")
        self.setWindowIcon(QIcon.fromTheme("org.katos.DevCenter", QIcon.fromTheme("applications-development")))
        self.resize(900, 600)
        self.setStyleSheet(ESTILO)

        self.pestanas = QTabWidget()
        self.estado = PestanaEstado()
        self.eventos = PestanaEventos(self.datos)
        self.apps = PestanaApps()
        self.servicio = PestanaServicio()
        self.pestanas.addTab(self.estado, "Estado")
        self.pestanas.addTab(self.eventos, "Eventos")
        self.pestanas.addTab(self.apps, "Apps Kat")
        self.pestanas.addTab(self.servicio, "Servicio")
        self.setCentralWidget(self.pestanas)
        self.statusBar().showMessage("Kat Developer Center %s" % VERSION)

        self._presentado = False
        self.temporizador = QTimer(self)
        self.temporizador.timeout.connect(self.refrescar)
        self.temporizador.start(INTERVALO_MS)
        self.refrescar()
        self.servicio.ver_estado()

    def closeEvent(self, evento):
        self.temporizador.stop()
        self.servicio.detener()
        super().closeEvent(evento)

    def refrescar(self):
        try:
            if not self._presentado:
                self.datos.presentarse()
                self._presentado = True
            self.estado.actualizar(self.datos.version(), self.datos.info(), self.datos.estadisticas())
            apps = self.datos.apps()
        except KatCoreNoDisponible as e:
            self.estado.mostrar_error(str(e))
            return
        self.apps.actualizar(apps)
        self.eventos.poner_apps([a[0] for a in apps])
        self.eventos.recargar()
