"""Capa de datos de Developer Center: habla con Kat Core y no sabe nada de Qt.

Así se puede probar sin ventanas.
"""

import time

from gi.repository import GLib

from katcore.cliente import KatCoreCliente

from . import APP_ID, VERSION


class KatCoreNoDisponible(RuntimeError):
    """katd no responde (no está instalado, se cayó o no hay sesión D-Bus)."""


def formato_gb(bytes_):
    return "%.1f GB" % (bytes_ / 1024 ** 3)


def formato_hora(t):
    return time.strftime("%d/%m %H:%M:%S", time.localtime(t))


def formato_duracion(segundos):
    segundos = int(segundos)
    d, resto = divmod(segundos, 86400)
    h, resto = divmod(resto, 3600)
    m = resto // 60
    if d:
        return "%d d %d h" % (d, h)
    if h:
        return "%d h %d min" % (h, m)
    return "%d min" % m


class Datos:
    def __init__(self, cliente=None):
        self._cliente = cliente

    def _kc(self):
        if self._cliente is None:
            try:
                self._cliente = KatCoreCliente()
            except GLib.Error as e:
                raise KatCoreNoDisponible(e.message)
        return self._cliente

    def _llamar(self, funcion, *args):
        try:
            return getattr(self._kc(), funcion)(*args)
        except GLib.Error as e:
            raise KatCoreNoDisponible(e.message)

    def presentarse(self):
        """Registra Developer Center en Kat Core y deja constancia en el registro."""
        self._llamar("registrar_app", APP_ID, VERSION)
        self._llamar("evento", APP_ID, "info", "Developer Center abierto")

    def version(self):
        return self._llamar("version")

    def info(self):
        return self._llamar("info")

    def estadisticas(self):
        return self._llamar("estadisticas")

    def eventos(self, limite=200, app=""):
        return self._llamar("eventos", limite, app)

    def apps(self):
        return self._llamar("apps")

    def enviar_evento(self, nivel, mensaje):
        return self._llamar("evento", APP_ID, nivel, mensaje)
