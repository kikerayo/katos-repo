"""Lógica de Kat Compat sin ventanas: qué es el archivo y cómo se abre.

Separado de la interfaz para poder probarlo sin pantalla.
"""

import os
import shutil
import subprocess
import time

TIPOS = {".exe": "exe", ".com": "exe", ".msi": "msi", ".bat": "bat", ".cmd": "bat"}
FALLO_RAPIDO_S = 10   # si termina con error antes de esto, se avisa al usuario


class NoCompatible(ValueError):
    """El archivo no es un programa de Windows que Kat Compat sepa abrir."""


def ruta_datos():
    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    return os.path.join(base, "katos", "compat")


def ruta_prefijo():
    """El 'Windows' del usuario (WINEPREFIX)."""
    return os.path.join(ruta_datos(), "windows")


def ruta_registros():
    base = os.environ.get("XDG_STATE_HOME") or os.path.join(os.path.expanduser("~"), ".local", "state")
    return os.path.join(base, "katos", "compat")


def es_ejecutable_windows(ruta):
    """Los .exe/.com/.msi de verdad empiezan con 'MZ' (exe) o con la firma OLE (msi)."""
    with open(ruta, "rb") as f:
        cabecera = f.read(8)
    return cabecera[:2] == b"MZ" or cabecera == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"


def tipo(ruta):
    if not os.path.isfile(ruta):
        raise NoCompatible("No existe el archivo: %s" % ruta)
    t = TIPOS.get(os.path.splitext(ruta)[1].lower())
    if t is None:
        raise NoCompatible("«%s» no es un programa de Windows (.exe, .msi o .bat)." % os.path.basename(ruta))
    if t in ("exe", "msi") and not es_ejecutable_windows(ruta):
        raise NoCompatible("«%s» tiene extensión de Windows pero no es un programa válido "
                           "(puede estar dañado o incompleto)." % os.path.basename(ruta))
    return t


def orden(ruta, argumentos=()):
    """Comando para abrir el archivo con Wine."""
    ruta = os.path.abspath(ruta)
    t = tipo(ruta)
    if t == "msi":
        return ["wine", "msiexec", "/i", ruta] + list(argumentos)
    if t == "bat":
        return ["wine", "cmd", "/c", ruta] + list(argumentos)
    return ["wine", ruta] + list(argumentos)


def entorno(prefijo=None, base=None):
    env = dict(os.environ if base is None else base)
    env["WINEPREFIX"] = prefijo or ruta_prefijo()
    # Sin ventanas de Wine pidiendo descargar Mono/Gecko la primera vez.
    env["WINEDLLOVERRIDES"] = "mscoree,mshtml="
    env.setdefault("WINEDEBUG", "-all")
    return env


def wine_instalado():
    return shutil.which("wine") is not None


def prefijo_listo(prefijo=None):
    return os.path.isfile(os.path.join(prefijo or ruta_prefijo(), "system.reg"))


def preparar_prefijo(prefijo=None, tiempo_max=600):
    """Crea el 'Windows' del usuario (solo la primera vez). Devuelve True si quedó listo."""
    prefijo = prefijo or ruta_prefijo()
    os.makedirs(os.path.dirname(prefijo), exist_ok=True)
    r = subprocess.run(["wineboot", "--init"], env=entorno(prefijo),
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=tiempo_max)
    subprocess.run(["wineserver", "-w"], env=entorno(prefijo), timeout=tiempo_max)
    return r.returncode == 0 and prefijo_listo(prefijo)


class Resultado:
    def __init__(self, codigo, duracion, registro):
        self.codigo = codigo
        self.duracion = duracion
        self.registro = registro      # archivo con lo que imprimió el programa

    @property
    def fallo(self):
        """Falló de verdad: terminó con error y casi de inmediato."""
        return self.codigo != 0 and self.duracion < FALLO_RAPIDO_S

    def ultimas_lineas(self, n=15):
        try:
            with open(self.registro, encoding="utf-8", errors="replace") as f:
                return "".join(f.readlines()[-n:])
        except OSError:
            return ""


def ejecutar(ruta, argumentos=(), prefijo=None):
    """Abre el programa y espera a que se cierre."""
    cmd = orden(ruta, argumentos)
    os.makedirs(ruta_registros(), exist_ok=True)
    registro = os.path.join(ruta_registros(), os.path.basename(ruta) + ".log")
    inicio = time.monotonic()
    with open(registro, "w", encoding="utf-8") as salida:
        r = subprocess.run(cmd, env=entorno(prefijo), cwd=os.path.dirname(os.path.abspath(ruta)),
                           stdout=salida, stderr=subprocess.STDOUT)
    return Resultado(r.returncode, time.monotonic() - inicio, registro)
