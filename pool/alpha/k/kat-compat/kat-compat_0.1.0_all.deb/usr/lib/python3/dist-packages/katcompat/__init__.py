"""Kat Compat: abre programas de Windows (.exe, .msi, .bat) con doble clic.

Usa Wine por debajo. Cada usuario tiene su propio "Windows" en
~/.local/share/katos/compat/windows (se crea solo la primera vez).
"""

VERSION = "0.1.0"
APP_ID = "org.katos.Compat"
