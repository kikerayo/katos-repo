"""Kat Compat con ventanas: lo que ve el usuario al hacer doble clic en un .exe."""

import os
import sys
import threading

from . import APP_ID, VERSION, lanzador

TITULO = "Kat Compat"


def _registrar(nivel, mensaje):
    """Anota en Kat Core. Si katd no está, no pasa nada: abrir el programa es lo importante."""
    try:
        from katcore.cliente import KatCoreCliente
        kc = KatCoreCliente()
        kc.registrar_app(APP_ID, VERSION)
        kc.evento(APP_ID, nivel, mensaje)
    except Exception:
        pass


def _qt():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(TITULO)
    app.setDesktopFileName(APP_ID)
    return app


def _aviso(texto, detalles="", error=True):
    from PySide6.QtWidgets import QMessageBox
    _qt()
    caja = QMessageBox()
    caja.setWindowTitle(TITULO)
    caja.setIcon(QMessageBox.Warning if error else QMessageBox.Information)
    caja.setText(texto)
    if detalles:
        caja.setDetailedText(detalles)
    caja.exec()


def _preparar_con_ventana():
    """Primera vez: crea el 'Windows' del usuario mostrando que se está trabajando."""
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QProgressDialog
    app = _qt()
    dialogo = QProgressDialog("Preparando la compatibilidad con Windows…\n"
                              "Solo pasa la primera vez y tarda alrededor de un minuto.",
                              None, 0, 0)
    dialogo.setWindowTitle(TITULO)
    dialogo.setMinimumDuration(0)
    dialogo.show()

    resultado = {}

    def trabajo():
        try:
            resultado["ok"] = lanzador.preparar_prefijo()
        except Exception as e:  # noqa: BLE001 - se muestra al usuario
            resultado["ok"] = False
            resultado["error"] = str(e)

    hilo = threading.Thread(target=trabajo, daemon=True)
    hilo.start()
    temporizador = QTimer()
    temporizador.timeout.connect(lambda: (not hilo.is_alive()) and app.quit())
    temporizador.start(200)
    app.exec()
    temporizador.stop()
    dialogo.close()
    return resultado.get("ok", False), resultado.get("error", "")


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] in ("-h", "--help"):
        print("Uso: kat-compat PROGRAMA.exe|.msi|.bat [argumentos]")
        return 0 if argv else 2
    if argv[0] == "--version":
        print(VERSION)
        return 0

    archivo, argumentos = argv[0], argv[1:]
    nombre = os.path.basename(archivo)

    try:
        lanzador.tipo(archivo)
    except lanzador.NoCompatible as e:
        _aviso(str(e))
        return 2

    if not lanzador.wine_instalado():
        _aviso("La compatibilidad con Windows no está instalada en este equipo.",
               "Falta el programa 'wine'. Instálalo con: sudo apt install wine wine64 wine32:i386")
        _registrar("error", "wine no está instalado; no se pudo abrir %s" % nombre)
        return 1

    if not lanzador.prefijo_listo():
        ok, error = _preparar_con_ventana()
        if not ok:
            _aviso("No se pudo preparar la compatibilidad con Windows.", error)
            _registrar("error", "falló la preparación del prefijo: %s" % error)
            return 1
        _registrar("info", "compatibilidad con Windows preparada")

    _registrar("info", "abriendo %s" % nombre)
    resultado = lanzador.ejecutar(archivo, argumentos)

    if resultado.fallo:
        _registrar("warning", "%s se cerró con error (código %d)" % (nombre, resultado.codigo))
        _aviso("«%s» no se pudo abrir.\n\n"
               "Algunos programas de Windows no funcionan en Kat OS, por ejemplo los que "
               "usan antitrampas o controladores propios. También puede faltarle algo "
               "que el programa necesita." % nombre,
               "Código de salida: %d\nRegistro: %s\n\n%s"
               % (resultado.codigo, resultado.registro, resultado.ultimas_lineas()))
        return resultado.codigo
    _registrar("info", "%s se cerró (código %d)" % (nombre, resultado.codigo))
    return 0
