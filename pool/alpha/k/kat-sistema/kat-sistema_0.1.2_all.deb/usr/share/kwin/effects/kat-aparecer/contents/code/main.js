/*
 * Kat OS — efecto de KWin "kat-aparecer"
 *
 * Al abrirse, cada ventana sale de su icono en la barra de tareas: empieza
 * pequeña sobre el icono, viaja a su sitio creciendo y llega con un brillo
 * que se apaga suave. Al cerrarse, vuelve hacia la barra y se desvanece.
 * Si la ventana no tiene icono en la barra, sale desde el lado de la barra.
 *
 * Basado en la forma del efecto "scale" de KWin (GPL). Licencia: GPL-3.0-or-later.
 */
"use strict";

var KatAparecer = {
    duracionEntrada: 420,
    duracionBrillo: 650,
    duracionSalida: 240,

    cargarAjustes: function () {
        KatAparecer.duracionEntrada = animationTime(420);
        KatAparecer.duracionBrillo = animationTime(650);
        KatAparecer.duracionSalida = animationTime(240);
    },

    // Solo ventanas normales y diálogos (nada de menús, avisos, el bloqueo...).
    seAnima: function (w) {
        if (effects.hasActiveFullScreenEffect) return false;
        if (!w || w.lockScreen || w.outline || w.popupWindow) return false;
        var clase = String(w.windowClass || "");
        if (clase.indexOf("plasmashell") !== -1 || clase.indexOf("ksplash") !== -1 ||
            clase.indexOf("ksmserver") !== -1 || clase.indexOf("kscreenlocker") !== -1 ||
            clase.indexOf("kat-asistente") !== -1) {      // Kat ya tiene su propia animación
            return w.hasDecoration === true && clase.indexOf("kat-asistente") === -1;
        }
        if (!w.managed) return false;
        return w.normalWindow === true || w.dialog === true;
    },

    // Centro de donde sale la ventana: su icono en la barra, o el borde donde está la barra.
    origen: function (w) {
        var g = w.geometry || { x: 0, y: 0, width: 0, height: 0 };
        var icono = w.iconGeometry;
        if (icono && icono.width > 0 && icono.height > 0) {
            return { x: icono.x + icono.width / 2, y: icono.y + icono.height / 2 };
        }
        var p = (w.screen && w.screen.geometry) ? w.screen.geometry : null;
        if (!p) return { x: g.x + g.width / 2, y: g.y + g.height };
        return { x: p.x + p.width / 2, y: p.y + p.height };      // desde abajo, al centro
    },

    desplazamiento: function (w) {
        var g = w.geometry || { x: 0, y: 0, width: 0, height: 0 };
        var o = KatAparecer.origen(w);
        return { value1: o.x - (g.x + g.width / 2), value2: o.y - (g.y + g.height / 2) };
    },

    alAbrir: function (w) {
        if (!KatAparecer.seAnima(w) || !w.visible) return;
        if (!effect.grab(w, Effect.WindowAddedGrabRole)) return;
        w.katEntrada = animate({
            window: w,
            curve: QEasingCurve.OutQuint,
            duration: KatAparecer.duracionEntrada,
            animations: [
                { type: Effect.Translation, from: KatAparecer.desplazamiento(w), to: { value1: 0, value2: 0 } },
                { type: Effect.Scale, from: 0.18, to: 1.0 },
                { type: Effect.Opacity, from: 0.0, to: 1.0 }
            ]
        });
        // el brillo: llega más clara y se apaga con suavidad
        w.katBrillo = animate({
            window: w,
            curve: QEasingCurve.InOutSine,
            duration: KatAparecer.duracionBrillo,
            animations: [{ type: Effect.Brightness, from: 1.7, to: 1.0 }]
        });
    },

    alCerrar: function (w) {
        if (!KatAparecer.seAnima(w) || !w.visible || w.skipsCloseAnimation) return;
        if (!effect.grab(w, Effect.WindowClosedGrabRole)) return;
        KatAparecer.cancelarEntrada(w);
        w.katSalida = animate({
            window: w,
            curve: QEasingCurve.InCubic,
            duration: KatAparecer.duracionSalida,
            animations: [
                { type: Effect.Translation, to: KatAparecer.desplazamiento(w) },
                { type: Effect.Scale, to: 0.35 },
                { type: Effect.Opacity, to: 0.0 }
            ]
        });
    },

    cancelarEntrada: function (w) {
        if (w.katEntrada) { cancel(w.katEntrada); delete w.katEntrada; }
        if (w.katBrillo) { cancel(w.katBrillo); delete w.katBrillo; }
    },

    // Si otro efecto toma la ventana, no pelear con él.
    alCambiarDatos: function (w, rol) {
        if (rol === Effect.WindowAddedGrabRole) {
            if (effect.isGrabbed(w, rol)) KatAparecer.cancelarEntrada(w);
        } else if (rol === Effect.WindowClosedGrabRole) {
            if (effect.isGrabbed(w, rol) && w.katSalida) { cancel(w.katSalida); delete w.katSalida; }
        }
    },

    iniciar: function () {
        effect.configChanged.connect(KatAparecer.cargarAjustes);
        effects.windowAdded.connect(KatAparecer.alAbrir);
        effects.windowClosed.connect(KatAparecer.alCerrar);
        effects.windowDataChanged.connect(KatAparecer.alCambiarDatos);
        KatAparecer.cargarAjustes();
    }
};

KatAparecer.iniciar();
