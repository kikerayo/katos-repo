// Kat OS Desktop — disposición inicial del escritorio (Plasma 6).
// Plasma ejecuta este script UNA vez, cuando un usuario entra por primera vez.
// Referencia de la API: https://develop.kde.org/docs/plasma/scripting/

var pantalla = screenGeometry(0);

// ---------- Escritorio: fondo Kat + widgets de la derecha ----------
var escritorios = desktopsForActivity(currentActivity());
for (var i = 0; i < escritorios.length; i++) {
    var d = escritorios[i];
    d.wallpaperPlugin = "org.kde.image";
    d.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    d.writeConfig("Image", "file:///usr/share/wallpapers/KatOS/");
    d.currentConfigGroup = [];

    // Widgets Kat (paquete kat-widgets), con datos reales de Kat Core.
    var ancho = 320;
    var x = Math.max(0, pantalla.width - ancho - 24);
    d.addWidget("org.katos.rendimiento",    x,  24, ancho, 170);
    d.addWidget("org.katos.almacenamiento", x, 210, ancho, 130);
}

// ---------- Barra inferior ----------
var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.floor(gridUnit * 2.6 / 2);

// Menú Kat (tecla Windows/Meta lo abre)
var menu = panel.addWidget("org.kde.plasma.kickoff");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "/usr/share/icons/hicolor/scalable/apps/katos.svg");

// Apps fijadas
var tareas = panel.addWidget("org.kde.plasma.icontasks");
tareas.currentConfigGroup = ["General"];
tareas.writeConfig("launchers", [
    "applications:org.katos.Files.desktop",
    "applications:firefox-esr.desktop",
    "applications:org.katos.Store.desktop",
    "applications:org.katos.Settings.desktop"
]);

panel.addWidget("org.kde.plasma.marginsseparator");

// Bandeja (Wi-Fi, Bluetooth, volumen, notificaciones) y reloj con fecha
panel.addWidget("org.kde.plasma.systemtray");
var reloj = panel.addWidget("org.kde.plasma.digitalclock");
reloj.currentConfigGroup = ["Appearance"];
reloj.writeConfig("dateDisplayFormat", "BelowTime");

panel.addWidget("org.kde.plasma.showdesktop");
