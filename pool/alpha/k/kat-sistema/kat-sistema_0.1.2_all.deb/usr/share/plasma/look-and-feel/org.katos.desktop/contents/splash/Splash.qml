// Kat OS — pantalla de carga al entrar al escritorio (sustituye a la de KDE).
// La muestra ksplashqml: va cambiando "stage" (1..6) mientras Plasma arranca
// y la cierra solo cuando el escritorio está listo.
// Solo usa QtQuick, así también se puede ver en Windows (scripts/windows/ver-splash.py).
import QtQuick

Rectangle {
    id: root
    property int stage: 0
    readonly property int etapas: 6

    width: 1920
    height: 1080
    gradient: Gradient {
        GradientStop { position: 0.0; color: "#100d19" }
        GradientStop { position: 1.0; color: "#2a1846" }
    }

    // Halo violeta que respira
    Rectangle {
        id: halo
        anchors.centerIn: orbe
        width: orbe.width * 2.4
        height: width
        radius: width / 2
        color: "#8b5cf6"
        opacity: 0.14
        SequentialAnimation on scale {
            loops: Animation.Infinite
            NumberAnimation { from: 0.85; to: 1.08; duration: 1400; easing.type: Easing.InOutSine }
            NumberAnimation { from: 1.08; to: 0.85; duration: 1400; easing.type: Easing.InOutSine }
        }
    }

    // Logo del gato Kat
    Image {
        id: orbe
        source: "images/kat.svg"
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -Math.round(root.height * 0.05)
        width: Math.round(Math.min(root.width, root.height) * 0.16)
        height: width
        sourceSize.width: width
        sourceSize.height: height
        smooth: true
        opacity: 0
        Component.onCompleted: aparecer.start()
        NumberAnimation on opacity { id: aparecer; running: false; to: 1; duration: 700; easing.type: Easing.OutCubic }
    }

    Text {
        id: nombre
        text: "Kat OS"
        color: "#e8dfff"
        font.pixelSize: Math.round(orbe.width * 0.32)
        font.weight: Font.DemiBold
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: orbe.bottom
        anchors.topMargin: Math.round(orbe.width * 0.22)
    }

    // Progreso: un punto por etapa de arranque de Plasma
    Row {
        id: puntos
        spacing: Math.round(orbe.width * 0.09)
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: nombre.bottom
        anchors.topMargin: Math.round(orbe.width * 0.3)
        Repeater {
            model: root.etapas
            Rectangle {
                width: Math.round(orbe.width * 0.07)
                height: width
                radius: width / 2
                color: index < root.stage ? "#a78bfa" : "#3a2d55"
                Behavior on color { ColorAnimation { duration: 300 } }
            }
        }
    }

    Text {
        text: root.stage >= root.etapas ? "Listo" : "Preparando tu escritorio…"
        color: "#a094be"
        font.pixelSize: Math.round(orbe.width * 0.11)
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: puntos.bottom
        anchors.topMargin: Math.round(orbe.width * 0.18)
    }
}
