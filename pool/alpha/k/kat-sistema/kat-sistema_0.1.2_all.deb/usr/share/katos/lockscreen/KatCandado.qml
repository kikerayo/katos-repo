/*
    Kat OS — candado de la pantalla de bloqueo.
    Cerrado mientras está bloqueado; al desbloquear se abre (el arco sube y gira),
    sale un destello violeta y avisa con "terminado" para entrar al escritorio.
    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick 2.15

Item {
    id: candado
    width: 46
    height: 60
    signal terminado()

    function abrir() {
        if (!animAbrir.running) {
            animAbrir.start();
        }
    }

    // destello que sale del candado al abrirse
    Rectangle {
        id: halo
        anchors.centerIn: cuerpo
        width: 96
        height: 96
        radius: 48
        color: "#8b5cf6"
        opacity: 0
        scale: 0.5
    }

    // arco (se dibuja detrás del cuerpo: sus "patas" entran en él)
    Item {
        id: arco
        width: 30
        height: 40
        x: (candado.width - width) / 2
        y: 2
        transform: [
            Translate { id: subir; y: 0 },
            Rotation { id: girar; origin.x: arco.width - 2.5; origin.y: arco.height; angle: 0 }
        ]
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "transparent"
            border.width: 5
            border.color: "white"
            antialiasing: true
        }
    }

    Rectangle {
        id: cuerpo
        width: candado.width
        height: 34
        y: candado.height - height
        radius: 9
        color: "white"
        antialiasing: true
        // cerradura
        Rectangle {
            width: 7
            height: 7
            radius: 3.5
            color: "#3b2a6b"
            anchors.horizontalCenter: parent.horizontalCenter
            y: 10
        }
        Rectangle {
            width: 3
            height: 9
            radius: 1.5
            color: "#3b2a6b"
            anchors.horizontalCenter: parent.horizontalCenter
            y: 15
        }
    }

    SequentialAnimation {
        id: animAbrir
        ParallelAnimation {
            NumberAnimation { target: subir; property: "y"; to: -10; duration: 280; easing.type: Easing.OutBack }
            NumberAnimation { target: girar; property: "angle"; to: -30; duration: 320; easing.type: Easing.OutCubic }
            NumberAnimation { target: halo; property: "opacity"; from: 0; to: 0.55; duration: 220 }
            NumberAnimation { target: halo; property: "scale"; from: 0.5; to: 1.7; duration: 520; easing.type: Easing.OutCubic }
        }
        ParallelAnimation {
            NumberAnimation { target: halo; property: "opacity"; to: 0; duration: 260 }
            NumberAnimation { target: candado; property: "scale"; to: 1.18; duration: 300; easing.type: Easing.OutCubic }
        }
        ScriptAction { script: candado.terminado() }
    }
}
