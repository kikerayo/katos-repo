// Kat OS — reloj grande de la pantalla de bloqueo (estilo Mac): fecha arriba, hora enorme debajo.
// Solo usa QtQuick, así también se ve en la vista previa de Windows.
import QtQuick

Item {
    id: reloj
    property date ahora: new Date()
    readonly property string familia: Qt.platform.os === "windows" ? "Georgia" : "Noto Serif"
    implicitWidth: hora.implicitWidth
    implicitHeight: fecha.implicitHeight + hora.implicitHeight

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: reloj.ahora = new Date()
    }

    Text {
        id: fecha
        anchors.horizontalCenter: parent.horizontalCenter
        text: {
            const t = reloj.ahora.toLocaleDateString(Qt.locale("es_ES"), "dddd d 'de' MMMM")
            return t.charAt(0).toUpperCase() + t.slice(1)
        }
        color: "#e8dfff"
        font.family: reloj.familia
        font.pixelSize: Math.round(hora.font.pixelSize * 0.19)
        font.weight: Font.DemiBold
        style: Text.Raised
        styleColor: "#40000000"
    }

    Text {
        id: hora
        anchors.top: fecha.bottom
        anchors.horizontalCenter: parent.horizontalCenter
        text: reloj.ahora.toLocaleTimeString(Qt.locale("es_ES"), "H:mm")
        color: "#ede9fe"
        opacity: 0.92
        font.family: reloj.familia
        font.pixelSize: Math.round(Math.min(reloj.parent ? reloj.parent.width : 1280, 2400) * 0.105)
        font.weight: Font.Bold
        style: Text.Raised
        styleColor: "#50000000"
    }
}
