#!/bin/sh
# Kat OS Desktop — aplica el aspecto Kat la primera vez que un usuario entra.
# Lo lanza /etc/xdg/autostart/kat-primer-inicio.desktop.
# Después de ejecutarse crea una marca y no vuelve a tocar nada,
# así el usuario puede cambiar su tema libremente.

MARCA="${XDG_CONFIG_HOME:-$HOME/.config}/katos/primer-inicio-hecho"
FONDO="/usr/share/wallpapers/KatOS/contents/images/1920x1080.png"   # Kat Nebulosa (paquete kat-artwork)
PLANTILLAS="/usr/share/katos/escritorio"
REGISTRO="${XDG_STATE_HOME:-$HOME/.local/state}/katos/primer-inicio.log"

[ -e "$MARCA" ] && exit 0

mkdir -p "$(dirname "$MARCA")" "$(dirname "$REGISTRO")"
exec >>"$REGISTRO" 2>&1
echo "== $(date '+%F %T') primer inicio de Kat OS =="

# Esperar a que el escritorio (plasmashell) esté listo, máximo 60 segundos.
i=0
until busctl --user status org.kde.plasmashell >/dev/null 2>&1; do
	i=$((i + 1))
	if [ "$i" -ge 60 ]; then
		echo "ERROR: plasmashell no respondió en 60 s; se reintentará en el próximo inicio"
		exit 1
	fi
	sleep 1
done

fallos=0
# El panel y los widgets ya los crea Plasma desde org.katos.desktop
# (LookAndFeelPackage en /etc/xdg/kdeglobals). Aquí solo se aseguran
# colores, iconos y fondo, sin reiniciar la disposición.
plasma-apply-lookandfeel -a org.katos.desktop || fallos=$((fallos + 1))
plasma-apply-colorscheme KatOS                || fallos=$((fallos + 1))
plasma-apply-wallpaperimage "$FONDO"          || fallos=$((fallos + 1))

# Iconos del escritorio (en español la carpeta se llama "Escritorio").
ESCRITORIO="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Desktop")"
mkdir -p "$ESCRITORIO"
for f in "$PLANTILLAS"/*.desktop; do
	[ -e "$f" ] || continue
	destino="$ESCRITORIO/$(basename "$f")"
	[ -e "$destino" ] || install -m 755 "$f" "$destino" || fallos=$((fallos + 1))
done

if [ "$fallos" -eq 0 ]; then
	touch "$MARCA"
	echo "OK: aspecto Kat aplicado"
else
	echo "ERROR: $fallos paso(s) fallaron; se reintentará en el próximo inicio"
	exit 1
fi
